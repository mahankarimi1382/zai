// Prepare Bale data for analysis: index chats + filter unit/warehouse-relevant messages
import fs from "node:fs";
import path from "node:path";

const DIR = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_data";
const OUT = path.join(DIR, "filtered");
fs.mkdirSync(OUT, { recursive: true });

const GROUPS = new Set(["8339623","96342159","184347948","231181343","351194861","517632817","729401255","785878952","786128402","1007814392","1048230922","1067330875","1195001957","1206812704","1265656539","1342929147","1358671243","1365646822","1396994789","1703520267","1729376405","1737503770","1762947819","1917376212","1918042926","1948954274","1986682312","2011482672","2048354559","2061599862","2085953014","2113853239","2139039927","2141244797","2145164056"]);

const RE = /(یونیت|انبار|مرجوع|برگشت|برگشتی|خراب|تعویض|نصب|سالم|معیوب|فالت|فالوت|fault|replace|RMA|RRU|RUS|BBU|DSP|UPEU|HUB|MBTS|آنتن|انتن|فیدر|فیوز|باتری|دیزل|ژنراتور|SFP|ODU|برد|کارت|ماژول|تعمیر|گارانتی|ریاستارت|ریستارت|crash|سوئیچ|السوییچ|GPS|پاور|power|منبع|تغذیه|هیتر|فن|خنک‌کننده|کولر|چک\s*کن|check|تعویض|جابجایی|حمل|ارسال|تحویل\s*انبار|مصرف)/i;

const normalize = (s) => s
  .replace(/[۰-۹]/g, d => "۰۱۲۳۴۵۶۷۸۹".indexOf(d))
  .replace(/[٠-٩]/g, d => "٠١٢٣٤٥٦٧٨٩".indexOf(d));

const codeRe = /\b[A-Za-z]{1,6}[-_ ][A-Za-z]?\d{3,}\b|\b[A-Za-z]{1,4}\d{3,5}\b|\b(?:RRU|RUS|BBU|DSP|UPEU|HUB|MBTS|SFP|ODU|BTS)\b|\b\d{4,5}\b\s*(?:Access|اکسس)|Access\s*\d|\bT\d{4}\b|\bE\d{4}\b|\bR\d{4}\b/;

const files = fs.readdirSync(DIR).filter(f => f.endsWith(".json") && f !== "_users.json");
const index = [];
let totalMsgs = 0, totalRel = 0;

for (const f of files) {
  const id = f.split("_")[0];
  const name = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  const rows = JSON.parse(fs.readFileSync(path.join(DIR, f), "utf8"));
  const kind = GROUPS.has(id) ? "group" : "personal";
  const dates = rows.map(r => r.d).filter(Boolean);
  const rel = [];
  for (const r of rows) {
    const txt = (r.x || "").trim();
    if (!txt) continue;
    const norm = normalize(txt);
    const hasKw = RE.test(norm);
    const hasCode = codeRe.test(norm);
    if (hasKw || hasCode) rel.push({ ...r, chat: name, chatId: id, kind });
  }
  index.push({ id, name, kind, total: rows.length, relevant: rel.length, from: dates.length ? new Date(Math.min(...dates)).toISOString().slice(0, 10) : "", to: dates.length ? new Date(Math.max(...dates)).toISOString().slice(0, 10) : "" });
  if (rel.length) {
    fs.writeFileSync(path.join(OUT, `${id}_${name}.jsonl`), rel.map(r => JSON.stringify(r)).join("\n"), "utf8");
  }
  totalMsgs += rows.length; totalRel += rel.length;
}

fs.writeFileSync(path.join(DIR, "_index.json"), JSON.stringify(index, null, 1));
let csv = "\uFEFFid,name,kind,total_messages,relevant_messages,from_date,to_date\n";
for (const r of index) csv += `${r.id},"${r.name}",${r.kind},${r.total},${r.relevant},${r.from},${r.to}\n`;
fs.writeFileSync(path.join(DIR, "00_chat_index_raw.csv"), csv, "utf8");
console.log("files:", files.length, "| total msgs:", totalMsgs, "| relevant:", totalRel);
for (const r of index.sort((a, b) => b.relevant - a.relevant).slice(0, 20)) console.log(`${r.kind}\t${r.relevant}\t${r.total}\t${r.name}`);
