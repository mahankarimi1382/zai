import fs from "node:fs";
import path from "node:path";
const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const f = fs.readdirSync(MERGED).find(x => x.startsWith("1206812704_"));
const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"));
let n = 0;
for (const m of msgs) {
  const x = (m.x || "").replace(/\s+/g, " ").trim();
  if (/hub\s*mains/i.test(x) && /\d/.test(x)) {
    console.log(new Date(m.d + 3.5 * 3600000).toISOString().slice(0, 10) + " :: " + x.slice(0, 420));
    if (++n >= 10) break;
  }
}
console.log("\n--- 48V-only lines ---");
let k = 0;
for (const m of msgs) {
  const x = (m.x || "").replace(/\s+/g, " ").trim();
  if (/^\s*\d{3,5}\s*(?:[A-Z]\d)?\s*(?:hub\s*)?mains/i.test(x) || /\b48\s*volt/i.test(x)) {
    console.log(new Date(m.d + 3.5 * 3600000).toISOString().slice(0, 10) + " :: " + x.slice(0, 300));
    if (++k >= 12) break;
  }
}