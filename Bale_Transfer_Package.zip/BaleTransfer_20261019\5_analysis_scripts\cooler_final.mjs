import fs from "node:fs";
import path from "node:path";
const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const files = fs.readdirSync(MERGED).filter(f => f.endsWith(".json"));
const FA = 0x06F0;
const norm = s => (s || "")
  .replace(/[۰-۹]/g, d => String(d.charCodeAt(0) - FA))
  .replace(/[٠-٩]/g, d => String(d.charCodeAt(0) - 0x0660))
  .replace(/[يى]/g, 'ی').replace(/ك/g, 'ک')
  .replace(/\u200c|\u200f|\u200e/g, '')
  .replace(/\s+/g, ' ').trim();

// ---------- قالب‌های نهایی ----------
const F = {
  "F1 سایت+عملیات انگلیسی (N4334 Cooler nasb she)": /\b([A-Z]{0,2}\d{3,5})\s+(?:Cooler|Coler|Kooler|cooler|ACU)\s+(?:nasb|cange|chenge|change|fault|fa?u?lt|salem|nist|nadare|ok)/i,
  "F2 کولر فالتی+شماره (مشخصات کولر فالتی 4334)": /(?:کولر|کوالر|coler|cooler)\s*(?:فالتی|فالت|fa?u?lt)\s*(\d{3,5})|(?:فالتی|فالت)\s*(?:کولر|کوالر)\s*(\d{3,5})/i,
  "F3 کولر+شماره (کولر 3517 / کولر ۱۳۶۱)": /(?:کولر|کوالر|cooler|coler)\s*(\d{3,5})(?!\d)/i,
  "F4 کولر+سایت در یک خط (کولر 550 سایت 6913)": /(?:کولر|cooler|coler)\s+\d{3,4}\s*(?:سایت|site)?\s*\d{3,5}|(?:سایت|site)\s*\d{3,5}.*(?:کولر|cooler|coler)|(?:کولر|cooler|coler).*?(?:سایت|site)\s*\d{3,5}/i,
  "F5 انبار (کولر فالتی سایت NNNN ارسال شد انبار)": /(?:کولر|کوالر|cooler|coler|NAC)\s*(?:فالتی|فالت|fa?u?lt)?\s*(?:سایت\s*)?(\d{3,5})?.*(?:ارسال|تحویل|عودت).*(?:انبار|اسنپ|snap)|(?:NAC|NCR48U)\s*\d{3,5}.*(?:انبار|warehouse)/i,
  "F6 آلارم تیکتی NIAN (Cooling Failure)": /(?:NIAN|Nian)\s*(?:Main\s*(?:or\s*Battery)?\s*)?Cooling\s*(?:System\s*)?Failure|Cooling\s*Failure|Battery\s*Cooling\s*Failure/i,
  "F7 MBTS+آلارم (MBTS_T3585X,NIAN Battery Cooling Failure)": /MBTS[_-]?([A-Z]{1,3}\d{3,5})X?\s*[,،]?\s*(?:NIAN|Nian).{0,40}Cooling/i,
  "F8 KEY Delivery AEC (سایت tXXXX به آقای X نفر aec جهت)": /سایت\s*t?\s*(\d{3,5})\s*به\s*آقای\s*.{1,30}نفر\s*aec|به\s*آقای\s*.{1,30}نفر\s*aec\s*جهت/i,
  "F9 activity_zon_D (CODE SITE / ISSUES cooler)": /CODE SITE\s*:?\s*(\d{3,5}).{0,200}?(?:cooler|cooler fault|fan noise|fan fualt|hitex|temp)/is,
  "F10 FLM (Code site:E7662 ... Activity Type : cooling fault)": /Code site\s*:?\s*([A-Za-z]{0,2}\d{3,5}).{0,200}?Activity Typ[^\n]*:?\s*[^\n]*cooling/i,
  "F11 درخواست (req cooler / درخواست کولر)": /req\s*(?:cooler|2\s*fan|fan|acu)|(?:درخواست|درخاست)\s*(?:کولر|فن|کولر ?و ?فن)|darkhast\s*(?:cooler|ACU)/i,
  "F12 تعویض (Cooler change / تعویض کولر)": /(?:تعویض|change|chenge|changing|عوض)\s*(?:کولر|cooler|coler|ACU|acu)|(?:کولر|cooler|coler)\s*(?:change|chenge|تعویض)|Cooler\s*&\s*NCU\s*changing/i,
  "F13 نصب (Cooler nasb she / نصب کولر)": /(?:کولر|cooler|coler|ACU)\s*(?:جدید\s*)?(?:نصب|nasb)|(?:نصب|nasb)\s*(?:کولر|cooler|coler)|nasbe?\s*cooler|cooler\s*nasb/i,
  "F14 کنسل": /کولر\s*ها?\s*کنسل|cooler\s*cansel|cooler\s*cancel|کنسل\s*کولر|cansell?\s*\?/i,
  "F15 تمپ مرتبط با کولر (co-tag)": /(?:تمپ\s*(?:شدید|دان|اور|میاره|داره)|high\s*temp|temp\s*on|با\s*تمپ|hightemp)/i,
};

const per = {}; for (const k of Object.keys(F)) per[k] = { n: 0, chats: new Set(), sites: new Set(), samples: [] };

for (const f of files) {
  const name = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"));
  for (const m of msgs) {
    const raw = (m.x || "");
    if (!raw.trim() || raw === "[object Object]") continue;
    const x = norm(raw);
    for (const [k, re] of Object.entries(F)) {
      const mm = x.match(re);
      if (mm) {
        per[k].n++; per[k].chats.add(name);
        const site = mm[1] || mm[2];
        if (site && /^\d{3,5}$/.test(site)) per[k].sites.add(site);
        if (per[k].samples.length < 4) per[k].samples.push(`[${name}] ${x.slice(0, 170)}`);
      }
    }
  }
}

console.log("=== قالب‌های نهایی: شمارش + نمونه ===");
for (const [k, v] of Object.entries(per)) {
  console.log(`\n### ${k}\n  n=${v.n} | chats=${v.chats.size} | sites=${v.sites.size}`);
  for (const s of v.samples) console.log("   " + s);
}
