import fs from "node:fs";
import path from "node:path";
const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const kw = new RegExp(process.argv[2] || "battery|باتری|باطری|batt", "i");
const limit = Number(process.argv[3] || 60);
const files = fs.readdirSync(MERGED).filter(f => f.endsWith(".json"));
let shown = 0;
const perChat = new Map();
for (const f of files) {
  const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"));
  let n = 0;
  for (const m of msgs) {
    const x = (m.x || "").replace(/\s+/g, " ").trim();
    if (!x || x === "[object Object]") continue;
    if (!kw.test(x)) continue;
    n++;
    if (shown < limit) {
      console.log(`[${f.replace(/^\d+_/, "").replace(/\.json$/, "")}] ${new Date(m.d + 3.5 * 3600000).toISOString().slice(0, 10)} | ${x.slice(0, 190)}`);
      shown++;
    }
  }
  if (n) perChat.set(f.replace(/^\d+_/, "").replace(/\.json$/, ""), n);
}
console.log("\n--- hits per chat ---");
for (const [k, v] of [...perChat.entries()].sort((a, b) => b[1] - a[1])) console.log(String(v).padStart(6), k);
console.log("TOTAL:", [...perChat.values()].reduce((a, b) => a + b, 0));