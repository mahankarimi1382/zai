# ============================================================
#  Token Watcher — منتظر بسته شدن ZCode می‌ماند و توکن بله را خودکار استخراج می‌کند
#  اجرا: powershell -File watch_and_extract.ps1
#  وقتی پیام "TOKEN-SAVED" دیدی، می‌توانی ZCode را دوباره باز کنی.
# ============================================================
$part = "C:\Users\someBody\AppData\Roaming\zcode\session\Partitions\zcode-embedded-browser"
$bak  = "C:\Users\someBody\.zcode\workspace\default\bale_session_iab_backup"
$tools = "C:\Users\someBody\.zcode\workspace\default\bale_session_tools"
$log = "$tools\watcher.log"

"[$(Get-Date -Format 'HH:mm:ss')] watcher started - waiting for ZCode to close..." | Out-File $log -Encoding utf8

$deadline = (Get-Date).AddHours(12)
while ((Get-Date) -lt $deadline) {
    $running = Get-Process | Where-Object { $_.ProcessName -match '^(zcode|ZCode)$' }
    if (-not $running) {
        Start-Sleep -Seconds 3   # let file handles flush
        "[$(Get-Date -Format 'HH:mm:ss')] ZCode closed - copying cookies..." | Out-File $log -Append -Encoding utf8
        try {
            Copy-Item "$part\Network\Cookies" "$bak\Cookies_snapshot" -Force
            $sz = (Get-Item "$bak\Cookies_snapshot").Length
            "[$(Get-Date -Format 'HH:mm:ss')] cookies copied: $sz bytes" | Out-File $log -Append -Encoding utf8
            Push-Location "C:\Users\someBody\.zcode\workspace\default"
            $out = node "bale_session_tools\bale_token.mjs" extract 2>&1 | Out-String
            Pop-Location
            $out | Out-File $log -Append -Encoding utf8
            if (Test-Path "$tools\token.json") {
                $j = Get-Content "$tools\token.json" -Raw | ConvertFrom-Json
                $at = $j.cookies | Where-Object { $_.name -eq "access_token" }
                if ($at) {
                    "[$(Get-Date -Format 'HH:mm:ss')] TOKEN-SAVED access_token len=$($at.value.Length)" | Out-File $log -Append -Encoding utf8
                    Write-Output "TOKEN-SAVED"
                    exit 0
                }
            }
            "[$(Get-Date -Format 'HH:mm:ss')] extract finished but token missing - retrying in 30s" | Out-File $log -Append -Encoding utf8
            Start-Sleep -Seconds 30
        } catch {
            "[$(Get-Date -Format 'HH:mm:ss')] error: $($_.Exception.Message)" | Out-File $log -Append -Encoding utf8
            Start-Sleep -Seconds 10
        }
    }
    Start-Sleep -Seconds 2
}
"[$(Get-Date -Format 'HH:mm:ss')] watcher timed out (12h)" | Out-File $log -Append -Encoding utf8
Write-Output "WATCHER-TIMEOUT"