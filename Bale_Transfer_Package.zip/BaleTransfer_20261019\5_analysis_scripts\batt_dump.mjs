import fs from "node:fs";
import path from "node:path";
const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const kw = new RegExp(process.argv[2] || "باتری|باطری|battery|batt|esm", "i");
const chat = process.argv[3]; // chatId substring or chat name substring; if absent => all
const limit = Number(process.argv[4] || 40);
const maxLen = Number(process.argv[5] || 700);
const files = fs.readdirSync(MERGED).filter(f => f.endsWith(".json"));
let shown = 0;
outer:
for (const f of files) {
  if (chat && !f.includes(chat)) continue;
  const name = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"));
  for (const m of msgs) {
    let x = (m.x || "").replace(/\r/g, "").trim();
    if (!x || x === "[object Object]") continue;
    if (!kw.test(x)) continue;
    shown++;
    console.log(`### [${name}] ${new Date(m.d + 3.5 * 3600000).toISOString().slice(0, 16)}\n${x.slice(0, maxLen)}\n`);
    if (shown >= limit) break outer;
  }
}