import fs from "node:fs";
import path from "node:path";
const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const files = process.argv[2] ? [process.argv[2]] : ["1737503770_R7_Return_Material.json", "1206812704_R7_DS_Follow_UP.json", "226526641_chat_226526641.json"];
const freq = new Map();
const ctx = new Map();
for (const f of files) {
  const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"));
  for (const m of msgs) {
    if (!m.x || typeof m.x !== "string" || m.x.includes("[object Object]")) continue;
    const s = m.x.replace(/\u200c/g, "");
    // unit family tokens: 2-6 letters then optional digits
    const re = /\b(rru|rrus?|rrh|rnrh|rhub|rhn|rus|rusb|sfp|sfb|sr1|sfcc|ncr|ncu|npu|ncr|mmu|odu|duw|dug|dus|dus|dub|pbc|pbu|psu|vpsu|upsu|fpfc|flatpack|flat ?pk|flt ?pk|rectif|rectifier|rct|rbs|bb|baseband|nhr|dhr|fsfmfa|fsmfa|isp3|isv3|tcu|fcu|fan|fans|sistem|sistemcooling|cooler|koler|coler|cooling|ubbp|bbu|gps|antn|anten|antenna|ans|lte|telecom|zbs|esc|zce|znce|btl|btm|tde|hss|nce|fpfc|tdd|ntdd|cr|lte|epb|epc|swb|swich|switch)\b/gi;
    let mm;
    while ((mm = re.exec(s))) {
      const k = mm[1].toLowerCase();
      freq.set(k, (freq.get(k) || 0) + 1);
      if (!ctx.has(k)) ctx.set(k, m.x.replace(/\s+/g, " ").slice(0, 120));
    }
  }
}
const arr = [...freq.entries()].sort((a, b) => b[1] - a[1]);
console.log("=== token freq ===");
for (const [k, v] of arr.slice(0, 90)) console.log(`${v.toString().padStart(6)}  ${k}   | ${ctx.get(k)}`);