import fs from "node:fs";
import path from "node:path";
const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const files = fs.readdirSync(MERGED).filter(f => f.endsWith(".json"));
const RE = /(?:نمی?ر(?:فته|فت|و|میره)|نبرد|نمیبرد)/;
const BATT = /(?:ب(?:ا|أ)?طری|باتری)/;
const groups = { "battery_not_transfer": 0, "battery_transfer_ok": 0, "battery_charge": 0, "battery_dan": 0, "batt_out_of_circuit": 0, "fuse_batt": 0 };
const samp = {};
const G = {
  "battery_not_transfer": /(?:رو|روی|به)\s*(?:ب(?:ا|أ)?طری|باتری)[^.\n]{0,25}?(?:نمی?ر(?:فته|فت|و|میره)|نمیره|نبرد|نمیبرد|نرفت)/,
  "battery_transfer_ok": /(?:میره\s*(?:رو|روی)\s*(?:ب(?:ا|أ)?طری|باتری)|(?:ب(?:ا|أ)?طری|باتری)[^.\n]{0,20}?(?:اپ|بالا|اوکی|سالم))/,
  "battery_charge": /(?:شارژ|دشارژ|discharge)/i,
  "battery_dan": /(?:ب(?:ا|أ)?طری|باتری)[^.\n]{0,25}دان|دان[^.\n]{0,15}(?:ب(?:ا|أ)?طری|باتری)/,
  "batt_out_of_circuit": /(?:ب(?:ا|أ)?طری|باتری)[^.\n]{0,25}?(?:از\s*مدار\s*(?:خارج|بیرون)|خارج\s*(?:کردن|شده|از\s*مدار)|بیرون\s*از\s*مدار|لاک|قفل)/,
  "fuse_batt": /(?:فیوز|فیوس|fuse|کلید)[^.\n]{0,20}(?:ب(?:ا|أ)?طری|باتری)|(?:ب(?:ا|أ)?طری|باتری)[^.\n]{0,20}(?:فیوز|فیوس|fuse|دیپ)/i,
};
for (const f of files) {
  const name = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"));
  for (const m of msgs) {
    const x = (m.x || "").replace(/\s+/g, " ").trim();
    if (!x || x === "[object Object]") continue;
    for (const [k, re] of Object.entries(G)) {
      if (re.test(x)) {
        groups[k]++;
        (samp[k] = samp[k] || []);
        if (samp[k].length < 10) samp[k].push(`[${name}] ${new Date(m.d + 3.5*3600000).toISOString().slice(0,10)} :: ${x.slice(0,190)}`);
      }
    }
  }
}
for (const k of Object.keys(groups)) {
  console.log(`\n### ${k} = ${groups[k]}`);
  (samp[k]||[]).forEach(s => console.log("  " + s));
}