# Fresh full backup of Bale session - ZCode in-app browser (2026-10-15)
$ErrorActionPreference = "Continue"
$part = "C:\Users\someBody\AppData\Roaming\zcode\session\Partitions\zcode-embedded-browser"
$bak  = "C:\Users\someBody\.zcode\workspace\default\bale_session_iab_backup"
$stamp = Get-Date -Format "yyyyMMdd_HHmm"

Write-Output "=== 1) fresh hardlinks for live cookies ==="
foreach ($name in @("Cookies", "Cookies-journal")) {
    try {
        $dst = "$bak\${name}_hardlink"
        if (Test-Path $dst) { Remove-Item $dst -Force }
        New-Item -ItemType HardLink -Path $dst -Target "$part\Network\$name" -ErrorAction Stop | Out-Null
        Write-Output "OK: $name -> hardlink ($((Get-Item $dst).Length) bytes)"
    } catch {
        Write-Output "FAIL: $name -> $($_.Exception.Message)"
    }
}

Write-Output "=== 2) full partition copy (unlocked files) ==="
$dstAll = "$bak\full_session_copy"
robocopy $part $dstAll /E /R:0 /W:0 /NFL /NDL /NJH /NJS | Out-Null
$n = (Get-ChildItem -Recurse $dstAll -File | Measure-Object).Count
$sz = [math]::Round((Get-ChildItem -Recurse $dstAll -File | Measure-Object -Property Length -Sum).Sum / 1MB, 1)
Write-Output "full copy: $n files, $sz MB"

Write-Output "=== 3) fresh copy of Bale IndexedDB ==="
$idbSrc = "$part\IndexedDB\https_web.bale.ai_0.indexeddb.leveldb"
$idbDst = "$bak\bale_idb"
if (Test-Path $idbSrc) {
    if (Test-Path $idbDst) { Remove-Item $idbDst -Recurse -Force -ErrorAction SilentlyContinue }
    Copy-Item $idbSrc $idbDst -Recurse -Force -ErrorAction SilentlyContinue
    $idbN = (Get-ChildItem $idbDst -File -ErrorAction SilentlyContinue | Measure-Object).Count
    Write-Output "bale IDB: $idbN files"
} else { Write-Output "bale IDB not found" }

Write-Output "=== 4) Local State (encryption key) ==="
Copy-Item "$part\Local State" "$bak\Local State" -Force -ErrorAction SilentlyContinue
Write-Output "Local State copied"

Write-Output "=== 5) backup dir listing ==="
Get-ChildItem $bak | Select-Object Name, Length, LastWriteTime | Format-Table -AutoSize | Out-String -Width 200

Write-Output "=== 6) live file status ==="
Write-Output ("Cookies live size: " + (Get-Item "$part\Network\Cookies").Length + " bytes")
Write-Output "DONE - $stamp"
