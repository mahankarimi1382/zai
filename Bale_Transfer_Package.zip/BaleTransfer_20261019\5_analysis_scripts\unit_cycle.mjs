// ===== Unit lifecycle engine for Irancell R7 Bale chats =====
// Extracts (site, unit, event) with proper Persian normalization, then pairs
// demand -> supply to answer: worst failures, slowest supply, unmet demand.
import fs from "node:fs";
import path from "node:path";

const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const OUT    = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_analysis";
fs.mkdirSync(OUT, { recursive: true });

// ---------- normalization ----------
const PRE = (s) => String(s)
  .replace(/[۰-۹]/g, d => String(d.charCodeAt(0) - 0x06F0))
  .replace(/[٠-٩]/g, d => String(d.charCodeAt(0) - 0x0660))
  .replace(/[يى]/g, "ی").replace(/[كک]/g, "ک").replace(/[أإآ]/g, "ا").replace(/[ۀة]/g, "ه")
  .replace(/[-]/g, " ")
  .replace(/[ً-ْ]/g, "")
  .replace(/\s+/g, " ").toLowerCase().trim();

const isFileMsg = (x) => !x || x.includes("[object Object]") && !/[a-z]{3}/i.test(x.replace(/\[object Object\]/g, ""));

// ---------- site codes (letter prefix is meaningful) ----------
// site codes: letter prefix + 4 digits (T1631, mmU 1478, TDD3635, LUT1219)
const siteRe = /([a-z]{1,5})\s?-?\s?(\d{4})\b/g;
// Valid site prefixes observed in the data. "GOOD5269"/"ADAD1893" are status words glued
// to numbers, not sites, so a whitelist is required rather than any letter run.
const SITE_PREFIXES = new Set(["t","e","n","b","h","d","l","f","g","k","c","m","s","v","w","a","r","j","x","y",
  "dt","lt","lut","dl","dlut","dd","th","tu","tn","te","teb","ter","kr","tr","ha","haye","tw","pk"]);
function isSitePrefix(p) {
  const w = String(p).toLowerCase().replace(/\s|-/g, "");
  if (isUnitWord(w)) return false;
  if (SITE_PREFIXES.has(w)) return true;
  return /^[a-z]{2,5}$/.test(w) && /[tlscbrd]$/.test(w) && !/(good|bad|fault|falt|down|add|rem|req|ok|new|old|noa|site|cell|unit|pack|esm|adu)/.test(w);
}
function findSites(t) {
  const out = new Set();
  let m;
  siteRe.lastIndex = 0;
  while ((m = siteRe.exec(t))) {
    if (!isSitePrefix(m[1])) continue;
    out.add(m[1].toUpperCase().replace(/\s|-/g, "") + m[2]);
  }
  if (out.size === 0) {
    const bare = /\b(\d{4})\b/g;
    while ((m = bare.exec(t))) {
      const ctx = t.slice(Math.max(0, m.index - 26), m.index + 16);
      if (/(سایت|site id|سلول|cell|آنتن|anten|انبار|\badd\b|\bremove\b)/i.test(ctx)) out.add(m[1]);
    }
  }
  return [...out];
}
const UNIT_WORD_SET = new Set(["ncr","cr","psu","vpsu","upsu","pbc","fpfc","rru","rrh","rrus","rus","rusb","mmu","dug","duw","dus","dub","ubbp","npu","ncu","bbu","fbba","rbs","bb","sfp","sfb","odu","epb","fsmfa","isv3","fiber","fibr","lan","jumper","cooler","koler","coler","fan","tcu","fcu","flatpack","flatpack","smartpack","anten","antn","gps","fuse","fiuz","batt","batry","esm","ladder","switch","swich","sowiche","relay","umpt","pfu"]);
function isUnitWord(w) { return UNIT_WORD_SET.has(String(w).toLowerCase()); }

// ---------- unit families ----------
const FAMILIES = [
  ["رادیویی", /\b(rru|rrh|rrus|rus|rusb?|mmu|dug|duw|dus|dub|ubbp|npu|ncu|bbu|fbba|rbs|bb)\b/],
  ["برق", /\b(ncr|psu|vpsu|upsu|pbc|rectifier|fpfc)\b/],
  ["اپتیک", /\b(sfp|sfb|odu|epb|fsmfa|isv3|fiber|fibr|lan|jumper|جمر|فیبر)\b/],
  ["مکانیکی", /\b(cooler|koler|coler|fan|tcu|fcu|flatpack|smart ?pack|کولر|فن|فلت ?بک|اسمارت ?بک|anten|antn|آنتن|انتن|gps)\b/],
  ["مصرفی", /\b(fuse|fiuz|فیوز|batt|batry|esm|ladder|باطری|نردبون)\b/],
  ["متفرقه", /\b(switch|swich|sowiche|سوئیچ|uplink|relay|umpt)\b/],
];
const UNIT_TOKENS = /\b(ncr|cr|psu|vpsu|upsu|pbc|fpfc|rru|rrh|rrus|rusb?|mmu|dug|duw|dus|dub|ubbp|npu|ncu|bbu|fbba|rbs|bb|sfp|sfb|odu|epb|fsmfa|isv3|fiber|fibr|lan|jumper|cooler|koler|coler|fan|tcu|fcu|flatpack|flat\s?pack|smartpack|anten|antn|gps|fuse|fiuz|batt|batry|esm|ladder|switch|swich|sowiche|relay|umpt|pfu)\b/;
// A unit token glued to digits is a SITE (e.g. MMU1478, NCR5004), not a unit model
const SITE_LIKE = /\d{3,}/;
function cleanUnits(raw) {
  const out = new Set();
  for (const u of raw) {
    if (SITE_LIKE.test(u)) continue;   // "ncr5004" -> site NCR5004
    out.add(u);
  }
  return [...out];
}
function unitFamily(u) {
  for (const [name, re] of FAMILIES) if (re.test(u)) return name;
  return "متفرقه";
}

// ---------- event detection ----------
// Order matters: RETURN must beat SUPPLY in warehouse chats ("تحویل انبار شد" = returning a faulty unit)
const EV = {
  FAULT: [
    /\b(fault|faulty|falte|fualt|falt|down|damage|damaged|burn|burnt|sookhte|broken|trip|busted|bad|alarm)\b/,
    /(فالت|فالتی|خراب|خرابی|سوخته|سوختگی|شکسته|شکستگی|دمیج|آب خورده|زنگ زده|قطع|پرید|تریپ|تعمیر|ایراد|خرابی دارد|مشکل دارد)/,
  ],
  REQUEST: [
    /\b(request|need|required|order|shortage|out of stock|pending|waiting)\b/,
    /(درخواست|نیاز|تقاضا|سفارش|کمبود|موجود نیست|موجودی ندارد|در انتظار|پیگیری|نداریم|نیست|باید تهیه|تأمین|تامین)/,
  ],
  SUPPLY: [   // انبار -> سایت
    /\b(sent to site|supplied|dispatched|installed on|delivered to site|replaced with new|send to)\b/,
    /(ارسال شد|ارسالی|فرستاد|فرستاده شد|تحویل سایت|تحویل شد به سایت|رفت سایت|نصب شد|نصب روی سایت|تعویض شد با|جایگزین شد|دمیج شده|دمیج شد|تأمین شد|تامین شد|ارسال انبار)/,
  ],
  RETURN: [   // سایت -> انبار (مرجوعی)
    /\b(return|rma|returned to warehouse|back to stock|returned)\b/,
    /(برگشت|برگشتی|عودت|مرجوع|مرجوعی|رفت انبار|برگشت به انبار|تحویل انبار شد|عودت به انبار|به انبار|انبار شد)/,
  ],
  SWAP: [ /\b(swap|replaced)\b/, /(تعویض|جایگزینی|جایگزین)/ ],
  RESTORE: [ /\b(recovered|restored|back online|cleared|resolved|fixed)\b/, /(رفع شد|راه ?انداز|راهانداز|بالا آمد|ok شد|سالم|ریکاور|برطرف|پاک شد)/ ],
  REPAIR: [ /\b(repair|repaired|fix|fixed|technician)\b/, /(تعمیر|تعمیرکار|رفع عیب)/ ],
};
function detectEvents(t, chatName) {
  const hits = [];
  for (const [k, pats] of Object.entries(EV)) {
    for (const p of pats) {
      if (p.test(t)) { hits.push(k); break; }
    }
  }
  if (!hits.length) return [];
  // In the returns warehouse group, "تحویل انبار شد" is a RETURN not a SUPPLY
  if (hits.includes("SUPPLY") && hits.includes("RETURN")) {
    if (/(تحویل انبار شد|برگشت|عودت|مرجوع|رفت انبار)/.test(t)) return hits.filter(h => h !== "SUPPLY");
  }
  // "تعمیر" appears inside fault sentences often; keep REPAIR only if no FAULT
  if (hits.includes("FAULT") && hits.includes("REPAIR") && !/(تعمیر\s?(?:شد|گردید|کار|شده)|در حال تعمیر|فرستاده.*تعمیر|تعمیرکار)/.test(t)) {
    return hits.filter(h => h !== "REPAIR");
  }
  return hits;
}

const hasUnit = (t) => UNIT_TOKENS.test(t) || /\b([tehnbfdlucgkm]{1,3})\s?-?\s?(\d{4})\b/.test(t);

// ---------- pass 1: events ----------
const events = [];   // {site, unit, ev, t(ms), chat}
const files = fs.readdirSync(MERGED).filter(f => f.endsWith(".json"));
let scanned = 0, textMsgs = 0;
for (const f of files) {
  const chatName = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"));
  for (const m of msgs) {
    scanned++;
    const raw = m.x || "";
    if (!raw || raw === "[object Object]") continue;
    const t = PRE(raw);
    if (t.length < 4) continue;
    textMsgs++;
    const units = cleanUnits(t.match(new RegExp(UNIT_TOKENS.source, "g")) || []);
    const sites = findSites(t);
    if (!units.length && !sites.length) continue;
    const evs = detectEvents(t, chatName);
    if (!evs.length) continue;
    const isSnapshot = t.length > 420 || /^(total|site id|zone|comment|activity)\b/.test(t);
    // site-only events go to a separate stream (site level faults, no unit model)
    if (!units.length) {
      for (const ev of evs) {
        for (const s of sites) {
          events.push({ site: s, sites: s, unit: "", family: "", ev, t: m.d, chat: chatName, text: raw.replace(/\s+/g, " ").slice(0, 160) });
        }
      }
      continue;
    }
    for (const ev of evs) {
      if (isSnapshot && sites.length === 0) continue;
      for (const u of units) {
        events.push({
          site: sites[0] || "",
          sites: sites.join("|"),
          unit: u.toUpperCase(),
          family: unitFamily(u),
          ev, t: m.d, chat: chatName, text: raw.replace(/\s+/g, " ").slice(0, 160),
        });
      }
    }
  }
}
events.sort((a, b) => a.t - b.t);
console.log(`scanned msgs: ${scanned} | text msgs: ${textMsgs} | events: ${events.length}`);
const byEv = {}; for (const e of events) byEv[e.ev] = (byEv[e.ev] || 0) + 1;
console.log("event mix:", JSON.stringify(byEv));

// ---------- pass 2: pair demand -> supply ----------
// key = site|unit (fallback to unit when site missing)
const key = (e) => `${e.site || "?"}|${e.unit || "?"}`;
// demands: FAULT (needs a spare) + explicit REQUEST
const demands = events.filter(e => e.ev === "FAULT" || e.ev === "REQUEST");
const supplies = events.filter(e => e.ev === "SUPPLY" || e.ev === "SWAP" || e.ev === "RESTORE");
// match a supply to a demand by unit model (site-agnostic) — a spare of the same
// family satisfies demand for that model regardless of which site it left from
const demandPool = [];   // open demands, chronological
const unitIdx = new Map();
function openDemand(key, unit, site, family) {
  const o = unitIdx.get(key);
  if (o) return o;
  const d = { key, unit, site, family, faults: 0, requests: 0, firstDemand: Infinity, lastDemand: 0, texts: [], sites: new Set() };
  unitIdx.set(key, d); demandPool.push(d); return d;
}
for (const d of demands) {
  const k = key(d);
  const o = openDemand(k, d.unit, d.site, d.family);
  if (d.ev === "FAULT") o.faults++; else o.requests++;
  o.lastDemand = Math.max(o.lastDemand, d.t);
  o.firstDemand = Math.min(o.firstDemand, d.t);
  if (d.site) o.sites.add(d.site);
  if (o.texts.length < 3) o.texts.push(d.text);
}
const now = Date.now();
for (const s of supplies) {
  const k = key(s);
  const o = unitIdx.get(k);
  if (o && !o.fulfilledAt && s.t >= o.lastDemand - 60000) {
    o.fulfilledAt = s.t; o.fulfilledBy = s.ev; o.fulfillText = s.text;
  }
}
const list = [...unitIdx.values()];
const fmtDays = (ms) => (ms / 86400000);

// 1) worst failures (unit models only)
let c1 = "\uFEFF" + ["unit","family","sites","fault_count","request_count","total_demand","first_fault","last_fault","sample"].map(x => `"${x}"`).join(",") + "\n";
const byUnit = new Map();
for (const o of list) {
  if (!o.unit) continue;                 // site-level demand handled separately
  const k = o.unit;
  if (!byUnit.has(k)) byUnit.set(k, { unit: k, family: o.family, sites: new Set(), faults: 0, requests: 0, first: o.firstDemand, last: o.lastDemand, samples: [] });
  const b = byUnit.get(k);
  b.faults += o.faults; b.requests += o.requests;
  if (o.site) b.sites.add(o.site);
  b.first = Math.min(b.first, o.firstDemand); b.last = Math.max(b.last, o.lastDemand);
  if (b.samples.length < 3) b.samples.push(o.texts[0] || "");
}
const worst = [...byUnit.values()].filter(b => b.faults > 0).sort((a, b) => b.faults - a.faults);
for (const b of worst) {
  c1 += [b.unit, b.family, [...b.sites].join("|"), b.faults, b.requests, b.faults + b.requests,
    new Date(b.first).toISOString().slice(0, 10), new Date(b.last).toISOString().slice(0, 10),
    b.samples.join(" || ").replace(/[";\n]/g, " ")].map(v => `"${String(v ?? "").replace(/"/g, "'")}"`).join(",") + "\n";
}
fs.writeFileSync(path.join(OUT, "1_worst_failed_units.csv"), c1, "utf8");

// 1b) worst sites (site-level faults, no unit model mentioned)
const bySite = new Map();
for (const o of list) {
  if (o.unit || !o.site) continue;
  if (!bySite.has(o.site)) bySite.set(o.site, { site: o.site, faults: 0, requests: 0, first: o.firstDemand, last: o.lastDemand, sample: o.texts[0] || "" });
  const b = bySite.get(o.site);
  b.faults += o.faults; b.requests += o.requests;
  b.first = Math.min(b.first, o.firstDemand); b.last = Math.max(b.last, o.lastDemand);
}
let c1b = "\uFEFF" + ["site","fault_count","request_count","first_fault","last_fault","sample"].map(x => `"${x}"`).join(",") + "\n";
for (const b of [...bySite.values()].sort((x, y) => y.faults - x.faults)) {
  c1b += [b.site, b.faults, b.requests, new Date(b.first).toISOString().slice(0, 10), new Date(b.last).toISOString().slice(0, 10), b.sample.replace(/[";\n]/g, " ")].map(v => `"${String(v ?? "").replace(/"/g, "'")}"`).join(",") + "\n";
}
fs.writeFileSync(path.join(OUT, "1b_worst_failed_sites.csv"), c1b, "utf8");

// 2) slowest supply (fulfilled demands)
const fulfilled = list.filter(o => o.fulfilledAt);
fulfilled.sort((a, b) => (b.fulfilledAt - a.firstDemand) - (a.fulfilledAt - a.firstDemand));
let c2 = "\uFEFF" + ["unit","family","site","fault_count","request_count","demand_date","supply_date","lead_days","supply_type","sample_demand","sample_supply"].map(x => `"${x}"`).join(",") + "\n";
for (const o of fulfilled) {
  c2 += [o.unit, o.family, o.site, o.faults, o.requests,
    new Date(o.firstDemand).toISOString().slice(0, 10), new Date(o.fulfilledAt).toISOString().slice(0, 10),
    fmtDays(o.fulfilledAt - o.firstDemand).toFixed(1), o.fulfilledBy || "",
    (o.texts[0] || "").replace(/[";\n]/g, " "), (o.fulfillText || "").replace(/[";\n]/g, " ")].map(v => `"${String(v ?? "").replace(/"/g, "'")}"`).join(",") + "\n";
}
fs.writeFileSync(path.join(OUT, "2_slowest_supply.csv"), c2, "utf8");

// 3) unmet demand (no supply found)
const unmet = list.filter(o => !o.fulfilledAt).sort((a, b) => (b.faults - a.faults) || (b.lastDemand - a.lastDemand));
let c3 = "\uFEFF" + ["unit","family","site","fault_count","request_count","first_demand","last_demand","days_open","status","sample"].map(x => `"${x}"`).join(",") + "\n";
for (const o of unmet) {
  const days = fmtDays(now - o.lastDemand);
  const status = days > 60 ? "معوق-بیش از ۲ ماه" : days > 30 ? "معوق-بیش از ۱ ماه" : days > 14 ? "در انتظار" : "اخیر";
  c3 += [o.unit, o.family, o.site, o.faults, o.requests,
    new Date(o.firstDemand).toISOString().slice(0, 10), new Date(o.lastDemand).toISOString().slice(0, 10),
    days.toFixed(0), status, (o.texts[0] || "").replace(/[";\n]/g, " ")].map(v => `"${String(v ?? "").replace(/"/g, "'")}"`).join(",") + "\n";
}
fs.writeFileSync(path.join(OUT, "3_unmet_demand.csv"), c3, "utf8");

// 4) warehouse flow: returns OUT and supplies IN, kept strictly separate
const ret = events.filter(e => e.ev === "RETURN");
const sup = events.filter(e => e.ev === "SUPPLY" || e.ev === "SWAP");
let c4 = "\uFEFF" + ["direction","unit","family","site","date","chat","message"].map(x => `"${x}"`).join(",") + "\n";
for (const e of ret) c4 += ["بازگشت به انبار", e.unit, e.family, e.sites || e.site, new Date(e.t).toISOString().slice(0, 10), e.chat, e.text.replace(/[";\n]/g, " ")].map(v => `"${String(v ?? "").replace(/"/g, "'")}"`).join(",") + "\n";
for (const e of sup) c4 += ["ارسال به سایت", e.unit, e.family, e.sites || e.site, new Date(e.t).toISOString().slice(0, 10), e.chat, e.text.replace(/[";\n]/g, " ")].map(v => `"${String(v ?? "").replace(/"/g, "'")}"`).join(",") + "\n";
fs.writeFileSync(path.join(OUT, "4_warehouse_moves.csv"), c4, "utf8");

// 5) event timeline (all classified rows, no aggregation)
let c5 = "\uFEFF" + ["date","event","unit","family","site","chat","message"].map(x => `"${x}"`).join(",") + "\n";
const EV_FA = { FAULT: "خرابی", REQUEST: "درخواست قطعه", SUPPLY: "ارسال به سایت", RETURN: "بازگشت به انبار", SWAP: "تعویض", RESTORE: "رفع خرابی", REPAIR: "تعمیر" };
for (const e of events) c5 += [new Date(e.t).toISOString().slice(0, 19).replace("T", " "), EV_FA[e.ev], e.unit, e.family, e.sites || e.site, e.chat, e.text.replace(/[";\n]/g, " ")].map(v => `"${String(v ?? "").replace(/"/g, "'")}"`).join(",") + "\n";
fs.writeFileSync(path.join(OUT, "5_event_timeline.csv"), c5, "utf8");

console.log(`\nworst-failed units: ${worst.length} | fulfilled: ${fulfilled.length} | unmet: ${unmet.length} | returns: ${ret.length} | supplies: ${sup.length}`);
console.log("\nTOP 10 FAILING UNITS:");
for (const b of worst.slice(0, 10)) console.log(`  ${b.unit}\t${b.family}\tfaults=${b.faults}\trequests=${b.requests}\tsites=${[...b.sites].join(",")}`);
console.log("\nTOP 10 SLOWEST SUPPLY:");
for (const o of fulfilled.slice(0, 10)) console.log(`  ${o.unit}\tsite=${o.site}\t${fmtDays(o.fulfilledAt - o.firstDemand).toFixed(0)}d\tfaults=${o.faults}`);
console.log("\nTOP 10 UNMET:");
for (const o of unmet.slice(0, 10)) console.log(`  ${o.unit}\tsite=${o.site}\tfaults=${o.faults}\topen ${fmtDays(now - o.lastDemand).toFixed(0)}d`);