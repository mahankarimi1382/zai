import fs from "node:fs";
import path from "node:path";
const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const FA = String.fromCharCode(0x06F0);
const norm = s => s.replace(/[۰-۹]/g, d => String(d.charCodeAt(0) - 0x06F0)).replace(/[٠-٩]/g, d => String(d.charCodeAt(0) - 0x0660)).replace(/[يى]/g, "ی").replace(/ك/g, "ک").replace(/‌/g, "").replace(/[ \t]+/g, " ");
const f = fs.readdirSync(MERGED).find(x => x.startsWith("785878952_"));
const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"));
const nb = /(?:فاقد\s*(?:ب(?:ا|أ)?طری|باتری))|(?:(?:ب(?:ا|أ)?طری|باتری)[^.\n]{0,10}?(?:ندارد|ندار|نیست|موجود\s*نیست|نبود))/;
const A = /^\s*([A-Za-z]{0,2})(\d{3,4})\b/;
const B = /^\s*([A-Za-z]{0,2})(\d{3,4})(?![0-9])/;
let hit = 0, a = 0, b = 0; const missA = [];
for (const m of msgs) {
  const x = norm(m.x || "").replace(/\s+/g, " ").trim();
  if (!x || x === "[object Object]" || !nb.test(x)) continue;
  hit++;
  if (A.test(x)) a++; else if (B.test(x)) b++; else missA.push(x.slice(0, 80));
}
console.log("noBattery:", hit, "| A(\\b):", a, "| B(lookahead):", b, "| none:", missA.length);
console.log("examples A:", msgs.filter(m => nb.test(norm(m.x||"")) && A.test(norm(m.x||"").trim())).slice(0,3).map(m => norm(m.x).trim().slice(0,60)).join(" || "));
console.log("misses:", missA.slice(0, 6));