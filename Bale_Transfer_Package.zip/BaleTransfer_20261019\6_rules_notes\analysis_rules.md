# قواعد استخراج چرخهٔ عمر یونیت از پیام‌های چت عملیاتی

دادهٔ مرجع: `bale_report/merged/` — سه گروه اصلی
| فایل | پیام کل | پیام متنی غیربی‌فایل | نقش |
|---|---|---|---|
| `1737503770_R7_Return_Material.json` | 35,434 | 10,959 | انبار / مرجوعی (جریان رفت‌وبرگشت یونیت) |
| `1206812704_R7_DS_Follow_UP.json` | 93,886 | 63,198 | پیگیری آلارم/تجهیز (Zone‑wide، MTTR) |
| `226526641_chat_226526641.json` | 11,901 | 7,673 | VISTA TT R7 NWI — ایمنی/HSE (درخواست کار روی سایت) |

---

## ۰) پیش‌پردازش اجباری (بدون این، قواعد پایین ۵۰٪ خطا می‌دهند)

```js
const PRE = s => s
  .replace(/[۰-۹]/g, d => String(d.charCodeAt(0) - 0x06F0))  // ارقام فارسی → لاتین (۹.۵٪ پیام‌های انبار)
  .replace(/[٠-٩]/g, d => String(d.charCodeAt(0) - 0x0660))  // ارقام عربی
  .replace(/[يى]/g, 'ی').replace(/[كک]/g, 'ک')            // ی/ک عربی
  .replace(/[‌‏‎_]/g, ' ')                      // نیم‌فاصله و RTL marks → فاصله
  .replace(/\u200c/g, '')
  .replace(/\s+/g, ' ')
  .toLowerCase();
```
- **ارقام فارسی**: ۱۰۳۶ از ۱۰۹۵۹ پیام انبار (۹.۵٪) ارقام فارسی دارند. نمونه: «۳۷۱۴ فلت بک ۴۱۰۰ ncu ۱۸۱۲…»، «تعداد 8عدد باطری فالت T3773». بدون نرمال‌سازی، سایت ۱۸۱۲ هرگز با 1812 تطبیق نمی‌خورد.
- **نیم‌فاصله**: در فارسی بین توکن‌ها نیم‌فاصله می‌آید (`می‌رود`, `یونیت‌های`). `barmigarde`/`بarmiگارد` در حروفچینی مجدد.
- **حروفچینی بی‌فاصله**: `sajjad azizi` → `sajjadazizi`. همیشه یک کپی نرمال‌شده + یک کپی بدون فاصله نگه دارید.
- **پیام بی‌فایل**: `x` شامل `"[object Object]"` است → بی‌فایل/عکس. حذف شود (در انبار ~۶۹٪ پیام‌ها بی‌فایل‌اند).

### تطبیق اعدادِ چسبیده و جداشده
سایت کدها همیشه جداشده نیستند: `۱۸۴۲`، `1842`، `T 1482`، `T1482`، `T۱۴۸۲`، `n4119`، `E6053`، `H9024`، `B0352`، `TH0394`، `Th0248`، `DT6593`، `L0191`، `NWG-OPS-TT-20260306-04241`.
رگس کد سایت: `/\b([A-Za-z]{1,4})-?\s?(\d{4})\b/g` — ولی **باید** با فهرست سفید پیشوندها و بدون تداخل با شماره سریال فیلتر شود.

---

## الف) خانواده‌های یونیت/تجهیز

### الف‑۱) کدهای سایت
| الگو | شکل نوشتاری | معنی | نمونهٔ واقعی |
|---|---|---|---|
| تک‌حرفی | `T1234`, `E5206`, `N4258`, `B0352`, `H9024`, `D6593` | کد سایت پایه (۴ رقم). حرف = ناحیه/پیشوند | `T1792 ncr`، `E6057 ubbp`، `N4119` |
| دو‌حرفی | `DT6593`, `TH0394`, `DL3494`, `LU0128`, `GD` | سایت وابسته/سلولی روی سایت مادر | `DT6593` (۸۹۰ رخداد)، `LUT1219`، `TH1971` |
| تیکت آلارم | `NWG-OPS-TT-YYYYMMDD-NNNNN` | شناسهٔ تیکت شبکه | `NWG-OPS-TT-20260306-04241` |
| آلارم سلولی | `TEBSCH13`, `TERCH12`, `KRB SCH4`, `TABSCH6`, `GDLUT1805` | کد آلارم BTK | `KRBSCH4`, `TEBSCH6` |
| سایت غیررادیویی | `0716`, `PKBSC`, `TWBSC`, `HSC` | سایت متفرقه/مرکزی | `vase 0716`، `رکتی فایر سایت pk bsc` |

**نکتهٔ حیاتی**: حرف پیشوند *معنادار* است و باید به تفکیک شمرده شود (`T1792` ≠ `N1792`؛ سایت T و سایت N کاملاً متفاوت‌اند). رگس باید حرف را گروه‌بندی کند، نه فقط عدد را.

### الف‑۲) خانواده‌های یونیت (فرکانس از ۳ فایل اصلی، متنِ غیربی‌فایل)
| # | کد/نام | بسط | معنی | شکل نوشتاری در متن | فرکانس تقریبی |
|---|---|---|---|---|---|
| 1 | **NCR** | Node Control Rectifier / Alarm Panel | یونیت برق/آلارم سایت (هوآوی) | `NCR`, `ncr`, `alarm panel`, `پنل آلارم`, `رکتی‌فایر`, `rectifier` | ۱۵۴۶ |
| 2 | **CR** | Cabinet Rectifier | همان خانوادهٔ NCR (نویسه‌گردانی) | `CR`, `cr ok nashode` | ۱۱۴۱ |
| 3 | **NPU** | Network Processing Unit | یونیت پردازش/بیس‌بند | `NPU`, `npu` | ۷۷۰ |
| 4 | **ESC** | — | ماژول کنترل/اینورتر | `ESC`, `Zb ESC`, `ZNCE`, `ZC ESC` | ۷۱۳ |
| 5 | **RRU** | Remote Radio Unit | یونیت رادیویی دوردست | `RRU`, `rru`, `RRH`, `rrh`, `RRUS`, `RUS`, `rus`, `rusb` | ۷۵۱+ |
| 6 | **PSU** | Power Supply Unit | منبع تغذیه | `PSU`, `psu`, `VPSU`, `UPSU`, `PSU 3-phase` | ۵۰۸+ |
| 7 | **BB** | Baseband | بیس‌بند | `BB`, `bb fault`, `FBBA`, `baseband` | ۴۱۳+۵۱ |
| 8 | **MMU** | — | یونیت مدیریت/پردازش (هم‌خانوادهٔ RRU) | `MMU`, `mmu` | ۳۵۱ |
| 9 | **SFP** | Small Form-factor Pluggable | ماژول نوری | `SFP`, `sfp`, `SFP 100G`, `sfp fault` | ۳۴۳ |
| 10 | **DUG/DUW/DUS/DUB** | Digital Unit (Radio) | یونیت دیجیتال رادیویی (Huawei BBU‑های سری D) | `DUG`, `DUW`, `DUS`, `DUB`, `2add` | ۵۲۸ |
| 11 | **SFB** | — | فیبر/ماژول نوری نسل قدیم | `SFB`, `sfb` | ۳۶ |
| 12 | **NCU** | — | یونیت کنترل (پیش‌از NPU) | `NCU`, `N4100`, `ncu` | ۲۲۸ |
| 13 | **FAN** | Fan | فن خنک‌کننده | `fan`, `fan fualt`, `4fan`, `فن` | ۲۰۳ |
| 14 | **BBU** | Baseband Unit | یونیت بیس‌بند | `BBU`, `bbu` | ۱۸۲ |
| 15 | **NHR/DHR** | — | ماژول برق/رک (هوآوی) | `NHR`, `DHR`, `nhr` | ۱۶۳ |
| 16 | **UBBP** | — | یونیت بیس‌بند قدیمی هوآوی | `UBBP`, `ubbp` | ۱۴۰ |
| 17 | **ODU** | Optical Data Unit | ماژول نوری/مبدل | `ODU`, `odu` | ۱۳۲ |
| 18 | **COOLER** | — | کولر دکل | `cooler`, `koler`, `coler`, `کولر`, `sistem cooling` | ۲۲۹+ |
| 19 | **TCU/FCU** | Temperature/Fan Control Unit | کنترلر دما/فن | `TCU`, `tcu` | ۱۲۵ |
| 20 | **FLATPACK** | Flat Pack | پاور فلت (۳kW/۲kW) | `flatpack`, `flat pack`, `فلت بک`, `فلت پک`, `فلتپک`, `فلبک` | ۶۳+ |
| 21 | **FPFC** | Flat Pack Fan Controller | کنترلر فن فلت‌پک | `Fpfc`, `fpfc` | ۲ |
| 22 | **RBS** | Radio Base Station | یونیت/شاسی رادیویی | `RBS`, `rbs`, `پیش‌از NPU` | ۴۸ |
| 23 | **PBC/PSU-DC** | — | پاور کابینه | `PBC`, `pbc` | ۳۶ |
| 24 | **GPS** | Global Positioning System | آنتن/گیرندهٔ ماهواره‌ای (همراه کابل GPS) | `GPS`, `gps`, `Gps cable` | ۵۴ |
| 25 | **ANT** | Antenna | آنتن | `anten`, `antn`, `آنتن`, `انتن` | ۱۷ |
| 26 | **FSMFA** | — | برد/ماژول | `FSMFA`, `fsmfa` | ۱۷ |
| 27 | **ISV3** | — | برد نسل سوم | `ISV3`, `isv3` | ۹ |
| 28 | **EPB** | — | برد جانبی | `EPB`, `epb` | ۱ |
| 29 | **SWITCH** | — | سوییچ | `switch`, `swich`, `sowiche` | ۱۱ |
| 30 | **FIBER/LAN/FUSE** | Fiber / LAN / Fuse | فیبر، کابل شبکه، فیوز (فیوز سه‌فاز/تک‌فاز) | `fibr`, `fiber`, `lan`, `fuse`, `fiuz`, `فیوز`, `فیبر`, `جمر/جمپر` | ۲۰۰+ |
| 31 | **ANTEN+طناب‌قرقره** | Pulley & Rope | تجهیزات بالابری (`طناب و قرقره`, `طناب قرقره`) | `طناب و قرقره` | ۵۰+ |
| 32 | **FLATPACK SMARTPACK** | Smart Pack | فلت‌پک هوشمند | `smart pack`, `اسمارت بک` | — |
| 33 | **RELAY/DU/UMPT** | Relayout Unit / UMPT | یونیت انتقال/ری‌لوکیشن | `umpt`, `UMPT`, `relay` | ۵۰+ |

### الف‑۳) طبقه‌بندی «خانواده» برای شمارش
همهٔ این‌ها را در **۵ گروه اصلی** جمع کنید تا سؤال «کدام یونیت بیشترین خرابی» معناپیدا کند:

| گروه | شامل |
|---|---|
| **رادیویی (Radio)** | RRU, RRH, RRUS, RUS, RUS/B, MMU, DUG, DUW, DUS, DUB, UBBP, NPU, NCU, BBU, BB/FBBA, RBS |
| **برق (Power)** | NCR, CR, PSU/VPSU/UPSU, PBC, RECTIFIER, FPFC |
| **اپتیک (Optical)** | SFP, SFB, ODU, EPB, FSMFA, ISV3, FIBER, LAN, JUMPER |
| **مکانیک/محیطی (Env)** | COOLER/COLER, FAN, TCU/FCU, ANT, GPS, NHR/DHR, SWITCH |
| **مصرفی (Consumable)** | FUSE/فیوز, BATT/باطری, BATRY, ESM, LADR/نردبون, Ladder |

---

## ب) افعال چرخهٔ یونیت (کلیدواژه + نمونهٔ واقعی)

> قاعده: هر پیام = چند (یونیت × سایت) که هر کدام یک **رویداد** با نوع `event_type` و `polarity` (مثبت/منفی) می‌سازد.

### ۱) خرابی / فالت شدن — `FAULT`
**کلیدواژه‌ها**
- انگلیسی: `fault`, `faulty`, `falte`, `fualt`, `down`, `damage`, `damaged`, `burn`, `burnt`, `sookhte`, `broken`, `trip`, `fiuz trip`, `fius trip`, `alarm`, `bad`
- فارسی: `فالت`, `فالتی`, `فالت شد`, `خراب`, `خرابی`, `سوخته`, `سوختگی`, `شکستگی`, `شکسته`, `دمیج`, `آب خورده`, `زنگ زده`, `قطع`, `قطعی`, `پرید`, `تریپ`, `تعمیر`, `نصب نشده`, `بد`, `مشکل`, `ایراد`, `خرابی دارد`
- قالب ثابت: `<UNIT> fault <SITE>` — «`ESC fault 5030`»، «`ncr fault 5327`»، «`odu faulty 6546`»
- قالب: `T/SITE down site` — «`🆔 Code site: T1795 … Activity Type : down site(llvd fault)`»

**نمونه‌های واقعی**
```
ESC fault 5030  Cable gps fault 4278  Pfu damaged 4240
rus ارسالی انبار دمیج شده
انتن T1631 سریال فالتی ناقص میباشد همچنین انتن فالتی دمیج میباشد
فالتی کولر 3440
Rru 3791فرستادن باز دمیج داره
2 عدد NCR T1792 ارسال شد انبار ((((( گودش هنوز نیومده )))))
این rru 5818 هواوی سوکت پاورش شکسته از داخل در اومده
این برد سوخته این کارتن نداشت بازش کردیم از روی روتر
N4353 fius trip 2ta NHR fault dare
```
- **نفی‌ها**: `good`, `سالم`, `سالمه`, `ok`, `ok shode`, `نرمال`, `بدون مشکل`, `healthe`, `salem` → اینها رخداد خرابی را **ابطال** می‌کنند.
  - «`Sistem cooling 0148 kamelm ersal shod anbar`» (سالم ارسال شد)
  - «`✅ Ncu n4100 good`»
- **توجه:** `نور یا فلش`، `بدنه`، `مشکل اکسز` اشتباه گرفته می‌شوند؛ `دمیج` = damage.

### ۲) درخواست قطعه / تأمین — `REQUEST`
**کلیدواژه‌ها**
- فارسی: `درخواست`, `نیاز به`, `نیازمند`, `میخوام`, `می خوام`, `میخام`, `لازمه`, `بفرستن`, `بفرستید برام`, `تهیه`, `سفارش`, `کمبود`, `موجود نیست`, `موجود ندار`, `نرسیده`, `جامونده`, `مانده`, `در انتظار`, `هنوز ندادن`, `هنوز نیومده`, `با کی هماهنگ`, `هماهنگ کنید بفرستند`
- انگلیسی: `request`, `req `, `req.`, `need`, `need unit`, `unit requested`, `order`, `pending`, `waiting for`, `not available`, `shortage`, `lant پندینگ`
- قالب قالبی: `همکار محترج ... خواهشمند است جهت تامین ... مساعدت فرمایید`
- قالب `req` در ACTIVITY: `ACTIVITY : req mmu` / `req psu & fiuoz` / `req cooler fault`

**نمونه‌های واقعی**
```
۵۰۱۵ سر سایتن. دارن کار میکنن npu فالت ۱۶۶۱ کولر فالت تمپ داره درخواست زدیم هنوز ندادن
T0606 unito request dadin?
T1057+1 ۲۰ ساعت گذشته. هنوز از یونیت هیچ خبری نیست.
اگه این باشه، این همونیه که یونیتی که لازم داره موجود نیست
همکار محترم همراه اول ... خواهشمند است جهت تامین کلید سایت T1134_1080 مساعدت فرمایید
دوربین LOS PSU N4190 Ncr H8026 میخوام لطفا هماهنگ کنید بفرستند
🆔 CODE SITE : 1107 ISSUES : ram fualt  ACTIVITY : check and req mmu
🆔 CODE SITE : 6534 ISSUES : cell down  ACTIVITY : change fibre & sfp & rru fault req rru
۲ عدد ncr T1792 ارسال شد انبار ((((( گودش هنوز نیومده )))))
```
- **نکتهٔ تمایز:** «`درخواست کلید سایت ...`» = درخواست **کلید سایت** (نه یونیت). نباید با `REQUEST_UNIT` یکی شود → کلیدواژهٔ `تامین کلید`/`درخواست کلید` را به کلاس `ACCESS_KEY` بفرستید.

### ۳) ارسال / تحویل از انبار به سایت — `DISPATCH` (و `TO_WAREHOUSE`)
دو مسیر متمایز:

**۳الف) رفت به سایت (`DISPATCH_TO_SITE`)** — «ارسال شد سایت»، «نصب شد روی سایت»
```
ارسال شد انبار / ارسال شد برای انبار / فرستاده شد / تحویل شد / دمیج شد / فرستاده شد / رفت سایت / نصب شد روی سایت / رسید سایت / تحویل اقای ... / ارسالی انبار
```
نمونه: «`۳۷۱۴ فلت بک ۴۱۰۰ ncu ۱۸۱۲ اسمارت بک ارسال شد برای انبار`»، «`Gps 1050 ersal shod anbar`»، «`TCU 1106 (dehdar) Fan hay 1545 (mahdavi) Psu 5029 (lashghari) Oomad samte anbar`».

**۳ب) برگشت/تحویل به انبار (`TO_WAREHOUSE`)** — این گروه «انبار» عمدتاً یعنی **مرجوعی فالتی**
```
تحویل انبار / تحویل انبار شد / تحویل اسنپ / تحویل وانت / فرستاده شد انبار / ارسال شد انبار / برای انبار / رفت انبار / tahvil anbar / ersal shod anbar / tahvil snap / anbar
```
- اکثریت پیام‌های گروه `R7_Return_Material` از این نوع‌اند (۲۷.۹٪ کل پیام‌های متنی صریحاً عبارت تحویل/ارسال دارند). این گروه = **عودت فالتی**، نه تأمین.

### ۴) مرجوعی / عودت به انبار — `RETURN`
```
برگشت / برگشتی / عودت / مرجوع / برگشت داده شد / برگشت به انبار / رفت انبار / returned / oodat / Return Material
```
نمونه:
```
۲ عدد ncr E5458 ۱ عدد فلت پک T1789 برگشت داده شد انبار
2 عدد ncr T1792 فالتی 1 عدد فیبر T1881 فالتی 1 عدد یونیت Tx T1763 برگشتی ارسال شد انبار
جمپر و طناب قرقره و RRU 6599 تحویل اقای جلم شد رفت انبار
از یونیت گود لطفا عکس نزارید این گروه فقط برای برگشت فالتی هست
```
- **هم‌معنا**: `TO_WAREHOUSE` و `RETURN` را در یک کلاس `RETURN_WH` ادغام کنید ولی `polarity=IN` (یونیت به انبار) بگذارید.

### ۵) تعویض با یونیت سالم — `SWAP`
```
تعویض / تعویض شد / جایگزین / جایگزینی / swap / sector swap / sec swap / change / changed / chenge / avaz gardm / جایگزین شد
```
نمونه:
```
قربونت ما میریم سمت 6555 با رضا برای تعویض rrh
8018 تعویض شد rru چک کنید
8234 sector swap
T6977 odu change
T3062 zone S3 recovered by flm , lan BBU to RTN changed
این rru 5818 هواوی ... باید درخواست بزنید بیاییم چنج کنیم
🆔 CODE SITE : 1465 ISSUES : port rus . 1 psu v fan fualt ACTIVITY : change port . Clean hitex . req psu v fan
🆔 CODE SITE : 1361 ISSUES : cell down 3g 4g ACTIVITY : change port power rru . Dug 900 down
🆔 CODE SITE : 6534 ISSUES : cell down ACTIVITY : change fibre & sfp & rru fault req rru
```
- `swap` با `fault`/اکشن ترکیبی: «`cellular down va swap ok shod؟`». `swap` = **هم رویداد تعویض است و هم نشانهٔ تأمین** (یعنی یونیت جایگزین موجود است یا در حال فراهم‌کردن است).

### ۶) نصب / راه‌اندازی موفق — `RESTORE` / `OK`
```
نصب شد / راه‌اندازی / استال / بالا آمد / بالا اومد / ok شد / ok shode / سالم / سالمه / نرمال / up / recovered / recover / ریکاور / ریکاوری / clear / cleared / کانفرم / تایید / تحویل گرفته شد / full up / up shod / bandari
```
نمونه:
```
T6934 Recovered
T8106 recovered , flm on site change LLVD
۵۳۵۳ دیشب ریکاور شد
این ۳۴۳۷ سل دان ریکاور شد با فرزاد چک کردم
T6934 Recovered / swap ok shode ama 1800 numad bala
E5366 full up T6670+1 up power outage
E2150 recovered
E6317 fius trip / ncr fault recover
🆔 CODE SITE : 1100 ACTIVITY : check power . Check bb . Reset bb . ... Req fan
🆔 CODE SITE : 1107 ISSUES : ram fualt ACTIVITY : change ram
```
- **تفکیک مهم:** `clear` به‌تنهایی = «پیگیری بسته شد» (نه لزوماً تعمیر). `recovered`/`ریکاور`/`سالم` = موفقیت قطعی. `✅`/`ok` = تأیید انسانیِ وضعیت فیزیکی یا سریال.
- `tahvil gerefte shod` (تحویل گرفته شد) = **تأیید انبار**، رویداد `WAREHOUSE_ACK`.

### ۷) تعمیر / مراجعه تعمیرکار — `REPAIR`
```
تعمیر / تعمیرکار / تعمیر شد / جهت تعمیر / برای تعمیر / رفت تعمیر / repair / RMA / RMA میگه / برای repair برگشت / تعمیرگاه
```
نمونه:
```
8174 Zb ESC 1165 ZC ESC 1019 ZC ESC لطفا این یونیت ها رو ... بیاد انبار که بفرستیم برای تعمیر
ESC fault T8174 baraye repair bargasht anbar
Mage tahvil anbar nadadi bara repair?!
unite 0678 bara repair tahvil dadaim ... fulte ke bargardondm anbar
اگه نرسید... یونیتی و درخواست نده و پیگیری نکنه
Crane nmire onja RMA mige bayad ba lader berim
age porzhas sare jadton b RMA begid nage flm befrestm
Rma dare peygiri mikone
```
- `RMA` = Return Merchandise Authorization، یعنی **مجوز مرجوعی تعمیر**؛ ترکیبی از RETURN + REPAIR.

---

## ج) قالب‌های تکرارشوندهٔ ساختاری

### قالب ۱ — «لیست انبوه تحویل» (غالب در R7_Return_Material)
یک پیام، چندین (تعداد × یونیت × سایت) را در یک خط یا چند خط فشرده می‌کند:
```
۳۷۱۴ فلت بک ۴۱۰۰ ncu ۱۸۱۲ اسمارت بک ارسال شد برای انبار
پاور شلف ۲۸۰۱ ۲عدد فلت بک ۲۸۰۱ Ncu۶۶۶۱ الارم پنل ۶۶۶۱ Ncr ۱۶۸۸ ارسال شد برای انبار
1add PSU 1463 2add NCR 7877 2add rru 6133 1add coler 1850 1add Nhr good 6191 1add npu 1856 ... Tahvil Vanet Anbar Dade shod
T2873 1 ncr E5466 2 ncr E5243 1 ncr Sfp fault T2872 Rru fault T3778 با اسنپ ارسال شد انبار
```
- پارسر باید **جداکننده** را تشخیص دهد: فاصله، `/`, `،`, `,`, خط جدید، `1add`/`2add`/`1 عدد`/`2ta`/`3عدد`/`1adad`.
- **الگوی تکراری `<UNIT> <SITE>`**: `1 Fibr nokia 6593 fualt 1 mmu 1188 good 1 mmu 3562 fualt 1duw 5216` → سه رکورد. جدانکننده = «فقط/1/2/3… عدد» یا واحد.

### قالب ۲ — «X + N mains» (Zone‑wide، در R7_DS_Follow_UP)
```
T1406+11 mains @kimiyagol
Hub mains : T1485 T1814 T6593
T1593+17 mains @hoseinpour_javad @mosiiiiiiiiiiiii
T3022+7 mains @sanjar84 @z_akbri
NWG-OPS-TT-20260316-03828 4G,DT6593 @mosii @hoseinpour_javad
```
- `+N` = تعداد کل سلول/Depend که down است. `Hub mains` = سایت هاب (والد) که برق ندارد.

### قالب ۳ — HSE Task Card (VISTA TT / R7 NWI)
```
🆔 Code site : T6864 ⛑ FLM Name : Mohsen abdolvand 🦺 Rigger : nader ghadiri 🧰
Activity Type : tdd down 🏘 City : parand 🛣️ Region : R7 🏭 Company : NWI 📸 TT:
```
- پاسخ EHS = `✅` یا `✅tt` یا `✅tt/cr` یا `ریجکت` (کار در ارتفاع ممنوع).
- **مهم برای سؤال ۳:** این گروه «درخواست مجوز کار روی سایت» است، **نه** درخواست یونیت. آن را در `event_type=WORK_PERMIT` بگذارید.

### قالب ۴ — MTTR Report (تیبیک‌ساز، هر ۱ ساعت)
```
Site ID  MTTR  Team Leader  Zone  HUB Info  topology  Number of Depends  Dep ID  Comment
N4267  1mo 3w 4d  #N/A  #N/A  0  0  Contract Expired
E6009  1mo 2w 3d  Javad Hoseinpor  E  MW  0  HW FAULT/ RRU FAULT / LL unhappy
B0352  1mo 1w 4d  #N/A  #N/A  0  0  NOA / Project Responsibility / ESM
T1580  1w 22h 21m  Javad Hoseinpor  E  DP-Router  5  T6592,T1457,T3654,T6579,E5382  TCP Fiber Cut
```
- ستون `Comment` خودش **نوع خرابی** را می‌دهد: `HW FAULT`, `RRU FAULT`, `LL unhappy`, `TCP Fiber Cut`, `Unknown`, `Project responsibility`, `ESM`, `Vandalism`, `Access issue`, `Damage`.
- این جداول **بهترین منبع** برای «کدام یونیت بیشترین خرابی»‌اند، چون `Comment` استاندارد است.
- جدول `Total DS R7:` خلاصهٔ دسته‌ای: `HW Fault: 1`, `Damage Issue: 4`, `Vandalism: 4`.

### قالب ۵ — Zone D Activity Card (`ISSUES` + `ACTIVITY`)
```
🆔 CODE SITE : 1591 👨🏻‍💻 CHECK BY : hamed 🕞 UPTIME : 🎫 TICKET : tch 🔎
ISSUES : sfp fualt . Sec swap . 1 fan fualt . 1 psu fualt
🔧 ACTIVITY : req psu v fan v sfp . Change fibr on moudel
```
- `ISSUES` = لیست خرابی‌ها، `ACTIVITY` = لیست اقدام‌ها (شامل `req` = درخواست قطعه).
- **این قالب بهترین منبع برای سؤال ۱ و ۳ است**، چون خرابی و درخواست را در یک پیام صریح می‌کند.

### قالب ۶ — اسنپ (حمل‌ونقل)
```
اسنپ شما رسید. مشخصات اسنپ: پراید نقره‌ای ... هزینه: 271000 تومان پرداخت‌شده با پنل سازمانی
اسنپ بگیرید بفرستم انبار
```
- اسنپ = تأیید فیزیکی «تحویل به راننده». `tahvil snap` = داده‌شدن به راننده. این `TO_WAREHOUSE` قطعی است.

### قالب ۷ — تحویل کلید سایت (Access)
```
همکار محترم همراه اول ... جهت تامین کلید سایت T1134 _1080 مساعدت فرمایید
```
- **جدا کنید** — این «قطعه» نیست، مانع دسترسی است.

---

## د) نتیجه‌گیری عملیاتی — قواعد دقیق سه سؤال کاربر

### مدل دادهٔ میانی (پیش‌شرط هر سه سؤال)

برای هر پیام، یک لیست **رخداد** بسازید:
```js
Event = {
  ts,            // از m.d (+3.5h برای تبدیل به وقت ایران)
  chat_id, u,    // فرستنده
  site,          // کد سایت نرمال‌شده، مثال "T1792" (حرف بزرگ + ۴ رقم)
  unit_family,   // یکی از ۵ گروه الف‑۳
  unit_token,    // کد اصلی: NCR, RRU, SFP, ...
  unit_serial,   // اگر ذکر شده (معمولاً نیست)
  event_type,    // FAULT | REQUEST | TO_WAREHOUSE | SWAP | RESTORE | REPAIR | WORK_PERMIT | ACCESS_KEY
  polarity,      // + (مثبت/سالم) یا - (خراب) — برای FAULT/RESTORE
  quantity,      // ۱ پیش‌فرض؛ از "2add","۲عدد","4ta" استخراج شود
  state,         // good | fault | unknown (از good/fault/faulty/nashtag)
  raw_text
}
```
**ترتیب مراحل:**
1. `PRE()` روی `m.x`؛ بی‌فایل‌ها را حذف کنید.
2. تشخیص `event_type` با جدول اولویت افعال (بخش ب). اولویت: `FAULT` > `REPAIR` > `SWAP` > `REQUEST` > `RETURN` > `DISPATCH` > `RESTORE`. یک پیام می‌تواند **چند** event بدهد (مثلاً «۲ عدد ncr E5458 ۱ عدد فلت پک T1789 برگشت داده شد انبار» = ۲ رخداد RETURN).
3. استخراج `(unit_token, site, quantity, state)` با پارسر «لیست انبوه» (قالب ۱). جداکننده‌ها: `عدد`، `add`، `عدد/ta`، فاصله بین `<unit> <4digit>`، `/`، `،`.
4. **نرمال‌سازی سایت**: پیشوند ۱‑۴ حرف + ۳‑۴ رقم. حروف را بزرگ کنید. `۱۸۱۲` → `1812`. اگر پیشوند نداشت، آن را با آخرین پیشوندِ پیام قبلی (context) پر کنید یا `UNKNOWN` بگذارید.
5. **تجمیع `site` و `unit` به `unit_key`**: برای شمارش «کدام یونیت»، `unit_key = unit_token` (NCR، RRU، SFP…). برای «کدام نمونه»، `unit_key = site + ":" + unit_token`.

---

### سؤال ۱: «کدام یونیت‌ها بیشترین خرابی را داشته‌اند؟»

**اطلاعات لازم:** `unit_token` + `site` + `ts` + (`event_type=FAULT`).
**منابع داده:** MTTR `Comment=HW FAULT` (بهترین)، Zone‑D `ISSUES`, پیام‌های `fault/faulty/فالت`.

**منطق (شبه‌کد):**
```js
faults = events.filter(e => e.event_type==='FAULT' && e.polarity===-1);
// شمارش به تفکیک خانواده
countByFamily = count(faults, e => e.unit_family);
// شمارش به تفکیک کد یونیت (سؤال «کدام یونیت‌ها»)
countByToken = count(faults, e => e.unit_token);
// شمارش نمونهٔ خاص (site+unit) برای «بدترین یونیت/سایت»
countByInstance = count(faults, e => e.site + ':' + e.unit_token);
rank(countByToken)  // مرتب نزولی
```
**امتیازدهی اختیاری (وزن):** `fault_weight = 3*FAULT + 1*(RETURN_WH) + 0.5*(REPAIR)` — یعنی یونیتی که هم فالت شده هم به تعمیر رفته سنگین‌تر است.

**خروجی:** `[{unit_token:'NCR', faults:1546, sites:412}, {unit_token:'RRU', faults:751}, ...]`

**نکتهٔ رفع نویز:** پیام‌هایی مثل «`سفارشی/فالتی نداره`»، «`که گفته بودین فالتی نداره هرسه فالتی دارن`» حامل داده‌اند اما شمارش را باید روی رخدادهای `FAULT` مثبت محدود کنید، نه هر occurrence واژهٔ `fault`.

---

### سؤال ۲: «کدام یونیت‌ها دیرتر تأمین شدند؟»

**اطلاعات لازم:** `site` + `unit_token` + `ts` در دو نقطه: (الف) رخداد تقاضا (`REQUEST` یا `FAULT`)، (ب) رخداد تأمین (`TO_WAREHOUSE`/`DISPATCH_TO_SITE` یا `SWAP` یا `RESTORE`).

**منطق (شبه‌کد):**
```js
// ۱) برای هر (site, unit) یک صف تقاضا بسازید
demandQueue = {}; // key -> [tsFaultOrRequest...]
for (e of events) {
  key = e.site + ':' + e.unit_token;
  if (e.event_type==='FAULT' || e.event_type==='REQUEST') {
    demandQueue[key] ||= []; demandQueue[key].push(e.ts);
  }
}
// ۲) هر تأمین، نزدیک‌ترین تقاضای باز (FIFO) را می‌بندد
for (e of events.sort(by ts)) {
  if (e.event_type in {TO_WAREHOUSE, DISPATCH_TO_SITE, SWAP, RESTORE, RESTORE_OK}) {
    key = e.site + ':' + e.unit_token;
    if (demandQueue[key]?.length) {
      t0 = demandQueue[key].shift();       // قدیمی‌ترین تقاضای باز
      leadTime[key].push(e.ts - t0);      // ساعت/روز
    }
  }
}
// ۳) دیرترین = بیشترین leadTime
rank(key => mean/median(leadTime[key])) desc
```
**نکات:**
- `RESTORE`/`recover`/`سالم` = تأمین موفق ⇒ leadTime = زمان «فالت → ریکاوری» (سرویس‌پذیری). اگر منظور کاربر «زمان تا رسیدن فیزیکی یونیت» است، فقط `TO_WAREHOUSE/DISPATCH` را بگیرید. **هر دو را جدا گزارش کنید.**
- یک `REQUEST` ممکن است چند روز بعد `SWAP` شود؛ `leadTime` = فاصلهٔ زمانی.
- انحراف: پیام «`۲۰ ساعت گذشته. هنوز از یونیت هیچ خبری نیست`» همان leadTime را **مستقیماً** گزارش می‌کند — این‌ها را به‌عنوان `OVERDUE` استخراج کنید.
- **کلیدواژهٔ تأخیر**: `هنوز نیومده`, `۲۰ ساعت گذشته`, `جامونده`, `در انتظار`, `late`, `pending`, `-۲۰ ساعته` ⇒ `OVERDUE=true`.

**خروجی:** `[{key:'T1057:NCR', leadTimeH:20, status:'OVERDUE'}, ...]`

---

### سؤال ۳: «کدام یونیت‌ها هنوز تأمین نشده‌اند؟»

**اطلاعات لازم:** `site` + `unit_token` + `ts` + `event_type`. منطق: **تقاضای باز بدون تأمین متناظر تا لحظهٔ فعلی**.

**منطق (شبع‌کد):**
```js
// برای هر (site, unit) کلید، آخرین وضعیت را نگه دار
status = {}; // key -> {lastFault, lastSupply, lastRestore, openRequestTs}
for (e of events.sort(by ts)) {
  key = e.site + ':' + e.unit_token;
  if (e.event_type==='FAULT' || e.event_type==='REQUEST') { status[key].openTs = e.ts; status[key].open=true; }
  if (e.event_type in {TO_WAREHOUSE, DISPATCH_TO_SITE, SWAP})       { status[key].open=false; status[key].supplied=e.ts; }
  if (e.event_type==='RESTORE' || good-state)                       { status[key].open=false; status[key].restored=e.ts; }
}
// تأمین‌نشده = open==true تا لحظهٔ فعلی (now)
notSupplied = entries(status).filter(s => s.open && (now - s.openTs) > thresholdHours);
// افزودن به‌روزرسانی‌های زبانی
notSupplied += messages matching /(هنوز ندادن|هنوز نیومده|هنوز نرسیده|در انتظار|جامونده|موجود نیست|درخواست زدیم هنوز|بدهی|بدهکار)/
```
- **نکتهٔ کلیدی:** «تأمین‌نشده» با «مرجوعی‌نشده» فرق دارد. در گروه `R7_Return_Material`، پیام «`تحویل انبار شد`» یعنی فالتی **به انبار برگشته**، نه اینکه یونیت سالم به سایت رفته باشد. برای سؤال «هنوز تأمین نشده»، منظور = «یونیت خراب رفته ولی جایگزین سالمش هنوز نرسیده». پس `TO_WAREHOUSE` را به‌عنوان **تأمین** حساب نکنید؛ آن را بستنِ رخداد `FAULT` با مقصد انبار بدانید. فقط `SWAP/RESTORE/DISPATCH_TO_SITE` تأمین واقعی است.
- **`ACCESS_KEY`** (درخواست کلید سایت) را اگرچه «تأمین» نیست، به‌عنوان بلوکر `notSupplied` جداگانه گزارش کنید (`blocked_by: access`).
- **snapshot برای نمایش:** چون رخدادها تکراری‌اند (همان سایت چند سال)، وضعیت را **برای هر بازهٔ زمانی** (مثلاً ماهانه) محاسبه کنید، نه فقط `now`.

---

## ضمیمهٔ سریع — جدول تصمیم تشخیص `event_type`

| اولویت | کلیدواژهٔ کلیدی (نمونه) | `event_type` |
|---|---|---|
| ۱ | `fault, faulty, falte, fualt, damage, damaged, سوخته, دمیج, شکستگی, خراب, فالت` | `FAULT` |
| ۲ | `برای تعمیر, جهت تعمیر, repair, RMA, تعمیرگاه` | `REPAIR` |
| ۳ | `تعویض, جایگزین, swap, change, chenge, avaz gard` | `SWAP` |
| ۴ | `درخواست, نیاز, میخوام, req, request, تامین کلید` | `REQUEST` / `ACCESS_KEY` |
| ۵ | `برگشت, عودت, مرجوع, بازگشت` | `RETURN_WH` |
| ۶ | `تحویل انبار, فرستاده شد انبار, ارسال شد انبار, tahvil anbar, snap, وانت` | `TO_WAREHOUSE` |
| ۷ | `ارسال شد سایت, رفت سایت, نصب شد, رسید سایت` | `DISPATCH_TO_SITE` |
| ۸ | `recovered, ریکاور, سالم, ok shode, up, clear, full up, ✅` | `RESTORE` |
| ۹ | (در گروه HSE) `Code site / Activity Type / FLM / Rigger` | `WORK_PERMIT` |

---

## استانداردسازی نهایی — توصیه‌های اجرایی

1. **همیشه** `PRE()` (ارقام فارسی + نیم‌فاصله + حروف عربی) را قبل از هر رگس اجرا کنید.
2. **پیشوند سایت را حفظ کنید**؛ `T`/`E`/`N`/`B`/`H`/`D` پیشوند ناحیه‌اند و برای شمارش «بدترین سایت» حیاتی‌اند.
3. یک پیام = چند رخداد. پارسر لیست‌های انبوه (قالب ۱) را حتماً پیاده کنید، وگرنه ۷۰٪ داده‌های انبار از دست می‌رود.
4. برای سؤال ۲، **دو معیار** گزارش کنید: leadTime فیزیکی (تا تحویل) و leadTime سرویس (تا recover).
5. برای سؤال ۳، **مرز گروه** را رعایت کنید: انبار = چرخهٔ مرجوعی، نه تأمین سالم.
6. `time_zone`: داده‌ها `epoch ms` است؛ +3.5h → وقت ایران. برای بازه‌بندی «روز/ماه» از همین استفاده کنید.
7. پیام‌های تکراری سیستمی (`Total DS R7:`, تیکت‌های MTTR) را به‌عنوان **گزارش وضعیت** (snapshot) علامت‌گذاری کنید، نه رخداد مجزا؛ وگرنه شمارش FAULT ده‌ها برابر بیش‌برآورد می‌شود.