import fs from "node:fs";
import path from "node:path";
const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const f = fs.readdirSync(MERGED).find(x => x.startsWith("1206812704_"));
const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"));
let n = 0;
for (const m of msgs) {
  const x = m.x || "";
  if (x.includes("Site ID")) {
    console.log("--- " + new Date(m.d + 3.5 * 3600000).toISOString().slice(0, 10));
    console.log(x.slice(0, 800));
    if (++n >= 3) break;
  }
}