import fs from "node:fs";
import path from "node:path";
const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const files = fs.readdirSync(MERGED).filter(f => f.endsWith(".json"));
const pats = {
  "فاقد باتری": /فاقد\s*(?:ب)?(?:ا|أ)?طری/,
  "فاقد باطری": /فاقد\s*باطری/,
  "باتری ندارد": /(?:ب(?:ا|أ)?طری|باطری)\s*(?:ندارد|ندار|نداشت|نیست|نشد)/,
  "باتری موجود نیست": /(?:ب(?:ا|أ)?طری|باطری)\s*موجود\s*(?:نیست|نبود)/,
  "باتری خراب": /(?:ب(?:ا|أ)?طری|باطری)[^.\n]{0,25}?(?:خراب|معیوب|خسته|بیس|بی‌س|فاسد|سوخته|فرسوده)/,
  "باتری سالم": /(?:ب(?:ا|أ)?طری|باطری)[^.\n]{0,25}?(?:سالم|درست|سالمه|نرمال|سالم بود)/,
  "تست باتری": /(?:تست|تست‌?کردن|آزمایش)[^.\n]{0,15}?(?:ب(?:ا|أ)?طری|باطری)|(?:ب(?:ا|أ)?طری|باطری)[^.\n]{0,15}?تست/,
  "شارژ": /(?:شارژ|شارژر)/,
  "دشارژ/تخلیه": /(?:دشارژ|دیشارژ|discharge|تخلیه)/i,
  "ولتاژ": /(?:ولتاژ|ولت\b|voltage|51\.\d|52\.\d|53\.\d)/i,
  "over current/اتصال کوتاه": /(?:over\s*current|جریان\s*بیش|اتصال\s*کوتاه|جوشی|spike)/i,
  "دمای باتری": /(?:تمپ|دمای\s*باتری|temp)/i,
  "BBU bat": /(?:BBU|Bbu|bbu)[^.\n]{0,30}?(?:ب(?:ا|أ)?طری|باطری)|(?:ب(?:ا|أ)?طری|باطری)[^.\n]{0,30}?BBU/i,
  "ESM": /\bE?S?M\b|esm/,
  "تعداد باتری": /(?:تعداد|[\d۰-۹]+)\s*(?:عدد\s*)?(?:ب(?:ا|أ)?طری|باطری|سلول|cell|esm)/,
  "۴۸ ولت": /(?:48|۴۸)\s*(?:V|ولت|volt)/i,
  "استرینگ": /(?:استرینگ|استرینگ|srting|strng|string|سلول|سری\s*باتری|ردیف\s*باتری)/,
  "تعمیر باطری": /(?:تعمیر|تعمیرکاری|تعویض|تعویضی|مرجعتی|مراجعتی)\s*(?:کارگاه\s*)?(?:ب(?:ا|أ)?طری|باطری)/,
  "کارگاه": /(?:کارگاه|ورکشاپ|workshop)/,
  "دیزل ژنراتور": /(?:دیزل|دیزل‌?ژنراتور|ژنراتور|دژ|DG|diesel)/,
  "قطعی برق": /(?:قطعی\s*برق|برق\s*(?:رفت|قطع|رفتن)|قطع\s*برق|خاموشی|بی\s*برق\s*شد)/,
  "برق شهری": /(?:برق\s*شهری|شهری|mains|utility)/i,
  "چند ساعت قطع": /(?:[\d۰-۹]+\s*(?:ساعت|ساعته|ساعتی|h|hour))/,
};
const counts = {};
const samples = {};
for (const f of files) {
  const name = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"));
  for (const m of msgs) {
    const x = (m.x || "").replace(/\s+/g, " ").trim();
    if (!x || x === "[object Object]") continue;
    for (const [k, re] of Object.entries(pats)) {
      if (re.test(x)) {
        counts[k] = (counts[k] || 0) + 1;
        (samples[k] = samples[k] || []).push({ n: name, d: new Date(m.d + 3.5 * 3600000).toISOString().slice(0, 10), x: x.slice(0, 260) });
      }
    }
  }
}
const save = process.argv[2] || "batt_patterns.json";
fs.writeFileSync(save, JSON.stringify({ counts, samples }, null, 1));
for (const k of Object.keys(counts).sort((a, b) => counts[b] - counts[a]))
  console.log(String(counts[k]).padStart(6), k);