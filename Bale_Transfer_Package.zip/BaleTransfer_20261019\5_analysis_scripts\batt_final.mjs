import fs from "node:fs";
import path from "node:path";
const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const files = fs.readdirSync(MERGED).filter(f => f.endsWith(".json"));
const R = {
  batteryWord: /(?:\bب(?:ا|أ)?طری\b|\bbatt(?:ery|ries)?\b|batry|باطری)/i,
  noBattery: /(?:فاقد\s*(?:ب(?:ا|أ)?طری|باتری))|(?:(?:ب(?:ا|أ)?طری|باتری)[^.\n]{0,12}?(?:ندارد|ندار|نیست|نیستن|نبود|موجود\s*نیست|نشد))/,
  fault: /(?:ب(?:ا|أ)?طری)[^.\n]{0,30}?(?:خراب|معیوب|فالت|فاسد|سوخته|خسته|بیس|بی‌س|فرسود|دیپ|deprecat)|(?:fault(?:y)?|bad|dead)[^.\n]{0,20}?(?:ب(?:ا|أ)?طری|batt)|(?:ب(?:ا|أ)?طری|batt)[^.\n]{0,20}?fault/i,
  healthy: /(?:ب(?:ا|أ)?طری)[^.\n]{0,30}?(?:سالم|درست|سالمه|سالم بود|نرمال|روشن|اوکی|ok\b|بدون شارژر کامل صحیح|صحیح)/,
  test: /(?:تست|آزمایش|آزمایشی)[^.\n]{0,15}?(?:ب(?:ا|أ)?طری|باتری)|(?:ب(?:ا|أ)?طری|باتری)[^.\n]{0,15}?تست/i,
  install: /(?:نصب|نصب\s*باتری|ب(?:ا|أ)?طری\s*نصب|تعویض\s*(?:ب(?:ا|أ)?طری|باتری))/,
  repair: /(?:تعمیر|مرجعتی|مراجعتی|تعویض)[^.\n]{0,20}?(?:ب(?:ا|أ)?طری|باتری)/,
  workshop: /(?:کارگاه|ورکشاپ)/,
  outage: /(?:قطعی\s*برق|برق\s*(?:رفت|رفته|قطع)|قطع\s*برق|خاموشی\s*سایت|رفتن\s*برق|روی\s*باتری|رو\s*ب(?:ا|أ)?طری|بی\s*برق)/,
  dg: /(?:دیزل|دیزل\s*ژنراتور|ژنراتور|\bDG\b|diesel)/i,
  esmPerson: /(?:نفر\s*esm|esm\s*(?:نفر|شرکت|قرارداد))/i,
  esmBattery: /(?:esm[^.\n]{0,20}?(?:ب(?:ا|أ)?طری|باتری|نصب|تست))|(?:(?:ب(?:ا|أ)?طری|باتری)[^.\n]{0,20}?esm)/i,
  alarmBat: /(?:NIAN|Nian)[^.\n]{0,10}Battery/i,
  volt: /(?:ولتاژ|volt|\d{2}\.\d{1,2}\s*volt)/i,
  chargerCfg: /(?:تنظیمات\s*شارژ|کانفیگ\s*شارژ|شارژ\s*(?:کانفیگ|مقدار))/,
  temp: /(?:تمپ|دمای\s*باتری|battery\s*temperature|temp\s*(?:alarm|sensor))/i,
};
const cnt = {}, samples = {}, chats = {};
for (const f of files) {
  const name = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"));
  for (const m of msgs) {
    let x = (m.x || "").replace(/\s+/g, " ").trim();
    if (!x || x === "[object Object]") continue;
    for (const [k, re] of Object.entries(R)) {
      if (re.test(x)) {
        cnt[k] = (cnt[k] || 0) + 1;
        chats[k] = chats[k] || new Set(); chats[k].add(name);
        (samples[k] = samples[k] || []).push({ n: name, d: new Date(m.d + 3.5 * 3600000).toISOString().slice(0, 10), x: x.slice(0, 300) });
      }
    }
  }
}
for (const k of Object.keys(cnt).sort((a, b) => cnt[b] - cnt[a]))
  console.log(String(cnt[k]).padStart(6), k, "| chats:", chats[k].size);
fs.writeFileSync("batt_final.json", JSON.stringify(Object.fromEntries(Object.entries(samples).map(([k, v]) => [k, v.slice(0, 25)])), null, 1));