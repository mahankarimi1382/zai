# ============================================================
#  Bale Token Vault — استخراج توکن سشن بله
#  این اسکریپت را وقتی ZCode کاملاً بسته است اجرا کنید.
#  توکن رمزگشایی‌شده در bale_session_tools\token.json ذخیره می‌شود
#  و بعداً برای لاگین خودکار بدون شماره/پیام استفاده می‌شود.
# ============================================================
$ErrorActionPreference = "Continue"
$part = "C:\Users\someBody\AppData\Roaming\zcode\session\Partitions\zcode-embedded-browser"
$bak  = "C:\Users\someBody\.zcode\workspace\default\bale_session_iab_backup"
$tools = "C:\Users\someBody\.zcode\workspace\default\bale_session_tools"

# --- 0) ZCode must be closed ---
$running = Get-Process | Where-Object { $_.ProcessName -match '^(zcode|ZCode)$' }
if ($running) {
    Write-Output "ZCode is RUNNING - close it completely first, then re-run."
    exit 1
}
Write-Output "ZCode closed - proceeding..."

# --- 1) copy the (now unlocked) cookies DB ---
try {
    Copy-Item "$part\Network\Cookies" "$bak\Cookies_snapshot" -Force
    Copy-Item "$part\Network\Cookies-journal" "$bak\Cookies-journal_snapshot" -Force -ErrorAction SilentlyContinue
    $sz = (Get-Item "$bak\Cookies_snapshot").Length
    Write-Output "Cookies copied: $sz bytes"
} catch {
    Write-Output "COPY-FAIL: $($_.Exception.Message)"
    exit 2
}

# --- 2) decrypt + extract token via node tool ---
Push-Location "C:\Users\someBody\.zcode\workspace\default"
node "bale_session_tools\bale_token.mjs" extract
$rc = $LASTEXITCODE
Pop-Location
if ($rc -ne 0) { Write-Output "EXTRACT-FAIL rc=$rc"; exit 3 }

# --- 3) verify token file ---
$tf = "$tools\token.json"
if (Test-Path $tf) {
    $j = Get-Content $tf -Raw | ConvertFrom-Json
    Write-Output ("Token file OK - cookies: " + $j.cookies.Count + " | extracted: " + $j.extractedAt)
    $at = $j.cookies | Where-Object { $_.name -eq "access_token" }
    if ($at) { Write-Output ("access_token present, length: " + $at.value.Length) }
    else { Write-Output "WARN: access_token not found among cookies" }
} else { Write-Output "token.json MISSING"; exit 4 }

Write-Output "DONE - token vault updated."
Write-Output "Now you can reopen ZCode; auto-relogin will use this token if you get logged out."
