# بکاپ سشن بله — مرورگر داخلی ZCode
آخرین بکاپ: 2026-10-15 16:48 | اکانت: HD NWI | اپ: بله وب (web.bale.ai)

## محتویات بکاپ
| فایل/پوشه | چیست | وضعیت |
|---|---|---|
| `full_session_copy/` | کپی کامل پارتیشن مرورگر (۲٬۹۷۷ فایل / ۳۴۰MB) — IndexedDB، Local Storage، تنظیمات و... | ✅ تازه (2026-10-15) |
| `Cookies_hardlink` | **مهم‌ترین**: سخت‌پیوند به کوکی زنده سشن بله (access_token). داده را نگه می‌دارد؛ فقط وقتی ZCode بسته باشد قابل کپی است. | ✅ تازه (40960 بایت) |
| `Cookies-journal_hardlink` | ژورنال کوکی | ✅ |
| `bale_idb/` | IndexedDB بله (چت‌ها، تنظیمات) | ✅ تازه (۱۴ فایل) |
| `Local State` | کلید رمزنگاری پروفایل (برای کوکی لازم است) | ✅ |
| `README_بکاپ.md` | همین راهنما | — |

## بازیابی (اگر لاگین پرید)
1. **ZCode را کامل ببند** (همه پنجره‌ها)
2. این دستور را اجرا کن:
   ```
   powershell -ExecutionPolicy Bypass -File "C:\Users\someBody\.zcode\workspace\default\restore_iab_session.ps1"
   ```
3. ZCode را باز کن → بله باید لاگین باشد

## نکات مهم
- در حالت عادی نیازی به بازیابی نیست — سشن در پروفایل زنده می‌ماند (`%APPDATA%\zcode\session\Partitions\zcode-embedded-browser`)
- **هرگز «پاک کردن داده‌های مرورگر» داخل ZCode نزن** — سشن بله پاک می‌شود
- برای بکاپ تازه‌تر (وقتی لاگین فعال است): `powershell -File "C:\Users\someBody\.zcode\workspace\default\backup_now.ps1"`
