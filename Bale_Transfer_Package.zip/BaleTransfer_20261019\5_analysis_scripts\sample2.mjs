import fs from "node:fs";
import path from "node:path";
const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const which = process.argv[2] || "1737503770";
const n = Number(process.argv[3] || 60);
const skip = Number(process.argv[4] || 0);
const maxlen = Number(process.argv[5] || 300);
const f = fs.readdirSync(MERGED).find(x => x.startsWith(which + "_"));
const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"));
const isFile = (m) => !m.x || typeof m.x !== "string" || !m.x.trim() || m.x.includes("[object Object]") || /^\[?file:|^file:|^\s*\[فایل/i.test(m.x);
const texts = msgs.filter((m) => !isFile(m));
console.log(`file: ${f} | total: ${msgs.length} | text-only: ${texts.length}`);
for (const m of texts.slice(skip, skip + n)) {
  const dt = new Date(m.d + 3.5 * 3600000).toISOString().replace("T", " ").slice(0, 16);
  console.log(`${dt} | u${m.u}${m.out ? " OUT" : ""} | ${m.x.replace(/\s+/g, " ").slice(0, maxlen)}`);
}