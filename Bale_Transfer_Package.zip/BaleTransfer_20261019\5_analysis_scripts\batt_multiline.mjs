import fs from "node:fs";
import path from "node:path";
const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const files = fs.readdirSync(MERGED).filter(f => f.endsWith(".json"));
let multi = 0, shown = 0, total = 0;
const examples = [];
for (const f of files) {
  const name = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"));
  for (const m of msgs) {
    const x = m.x || "";
    if (!x.trim() || x.trim() === "[object Object]") continue;
    total++;
    const hasNL = /\n/.test(x.trim());
    if (!hasNL) continue;
    multi++;
    const isBatt = /(?:ب(?:ا|أ)?طری|باتری|batt)/i.test(x);
    const isOutage = /(?:قطعی\s*برق|برق\s*رفت|خاموشی|outage)/i.test(x);
    if (!isBatt && !isOutage) continue;
    if (shown++ < 14) {
      console.log(`\n### [${name}] ${new Date(m.d + 3.5 * 3600000).toISOString().slice(0, 10)} lines=${x.trim().split("\n").length}`);
      console.log(x.trim().slice(0, 800));
      examples.push({ name, date: new Date(m.d + 3.5 * 3600000).toISOString().slice(0, 10), lines: x.trim().split("\n").length });
    }
  }
}
console.log("\ntotal msgs:", total, "| multiline:", multi, "| battery/outage multiline shown:", shown);