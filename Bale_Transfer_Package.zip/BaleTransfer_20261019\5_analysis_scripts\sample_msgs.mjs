import fs from "node:fs";
import path from "node:path";
const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const which = process.argv[2] || "1737503770";
const n = Number(process.argv[3] || 60);
const skip = Number(process.argv[4] || 0);
const f = fs.readdirSync(MERGED).find(x => x.startsWith(which + "_"));
const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"));
console.log("file:", f, "| total:", msgs.length);
for (const m of msgs.slice(skip, skip + n)) {
  if (!m.x || !m.x.trim()) continue;
  console.log(`${new Date(m.d + 3.5 * 3600000).toISOString().slice(0, 10)} | ${m.x.replace(/\s+/g, " ").slice(0, 180)}`);
}