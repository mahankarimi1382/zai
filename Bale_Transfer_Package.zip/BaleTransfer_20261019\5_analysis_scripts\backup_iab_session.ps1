$ErrorActionPreference = "Continue"
$part = "C:\Users\someBody\AppData\Roaming\zcode\session\Partitions\zcode-embedded-browser"
$bak  = "C:\Users\someBody\.zcode\workspace\default\bale_session_iab_backup"

# 1) Try live read of locked Cookies with FileShare ReadWrite|Delete
try {
    $fs = [System.IO.File]::Open("$part\Network\Cookies", 'Open', 'Read', [System.IO.FileShare]::ReadWrite -bor [System.IO.FileShare]::Delete)
    $b = New-Object byte[] $fs.Length
    $n = $fs.Read($b, 0, $fs.Length)
    $fs.Close()
    [System.IO.File]::WriteAllBytes("$bak\Cookies_live_read", $b)
    Write-Output "LIVE-READ-OK bytes=$n"
} catch {
    Write-Output "LIVE-READ-FAIL: $($_.Exception.Message)"
}

# 2) Hardlink the locked cookies (survives lock; readable whenever browser is closed)
foreach ($name in @("Cookies", "Cookies-journal")) {
    try {
        $dst = "$bak\${name}_hardlink"
        if (Test-Path $dst) { Remove-Item $dst -Force }
        New-Item -ItemType HardLink -Path $dst -Target "$part\Network\$name" -ErrorAction Stop | Out-Null
        Write-Output "HARDLINK-OK: $name"
    } catch {
        Write-Output "HARDLINK-FAIL: $name -> $($_.Exception.Message)"
    }
}

# 3) Full copy of the partition folder (everything not locked) into backup
$dstAll = "$bak\full_session_copy"
New-Item -ItemType Directory -Force -Path $dstAll | Out-Null
robocopy $part $dstAll /E /R:0 /W:0 /NFL /NDL /NJH /NJS | Out-Null
Write-Output "FULL-COPY done -> $dstAll"
Get-ChildItem -Recurse $dstAll -File | Measure-Object -Property Length -Sum | ForEach-Object { Write-Output ("full copy files=" + $_.Count + " bytes=" + $_.Sum) }

# 4) Verify bale IDB backup freshness + list backup dir
Write-Output "--- backup dir ---"
Get-ChildItem $bak | Select-Object Name, Length, LastWriteTime | Format-Table -AutoSize | Out-String -Width 200
