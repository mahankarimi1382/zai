import fs from "node:fs";
const p = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_analysis\\14_planning_report.md";
let s = fs.readFileSync(p, "utf8");
if (!s.includes("26_dashboard_FINAL")) {
  s += "\n\n## داشبورد بصری\nفایل `26_dashboard_FINAL.html` را در مرورگر باز کنید — شامل نمودارهای خرابی/تأمین یونیت‌ها، باطری سایت‌ها، کولر سایت‌ها و روند ماهانه.\n";
  fs.writeFileSync(p, s);
  console.log("report updated");
} else console.log("already updated");