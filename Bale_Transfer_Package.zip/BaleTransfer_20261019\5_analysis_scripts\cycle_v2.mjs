// Unit cycle engine v2 — matches each demand to the NEAREST FOLLOWING supply of the
// same unit model (site-agnostic), which is how spare dispatch actually works.
import fs from "node:fs";
import path from "node:path";

const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const OUT    = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_analysis";
fs.mkdirSync(OUT, { recursive: true });

const PRE = (s) => String(s)
  .replace(/[۰-۹]/g, d => String(d.charCodeAt(0) - 0x06F0))
  .replace(/[٠-٩]/g, d => String(d.charCodeAt(0) - 0x0660))
  .replace(/[يى]/g, "ی").replace(/[كک]/g, "ک").replace(/[أإآ]/g, "ا").replace(/[ۀة]/g, "ه")
  .replace(/[ً-ْ]/g, "")
  .replace(/[-‏‎]/g, " ")
  .replace(/\s+/g, " ").toLowerCase().trim();

const SITE_PREFIXES = new Set(["t","e","n","b","h","d","l","f","g","k","c","m","s","v","w","a","r","j","x","y",
  "dt","lt","lut","dl","dlut","dd","th","tu","tn","te","teb","ter","kr","tr","ha","haye","tw","pk"]);
const NOT_SITE = /(good|bad|fault|falt|down|add|rem|req|ok|new|old|noa|site|cell|unit|pack|esm|adu|batty|batt|battery|hub|mains|vol|amp)/;
const isSitePrefix = (p) => {
  const w = String(p).toLowerCase().replace(/\s|-/g, "");
  if (SITE_PREFIXES.has(w)) return true;
  if (NOT_SITE.test(w)) return false;
  return /^[a-z]{2,5}$/.test(w) && /[tlscbrd]$/.test(w);
};
const UNIT_WORDS = ["ncr","cr","psu","vpsu","upsu","pbc","fpfc","rru","rrh","rrus","rus","rusb","mmu","dug","duw","dus","dub","ubbp","npu","ncu","bbu","fbba","rbs","bb","sfp","sfb","odu","epb","fsmfa","isv3","fiber","fibr","lan","jumper","cooler","koler","coler","fan","tcu","fcu","flatpack","smartpack","anten","antn","gps","fuse","fiuz","batt","batry","esm","ladder","switch","swich","sowiche","relay","umpt","pfu"];
const UNIT_SET = new Set(UNIT_WORDS);
const UNIT_TOKENS = new RegExp("\\b(" + UNIT_WORDS.join("|") + ")\\b");
const FAMILY = [
  ["رادیویی", /\b(rru|rrh|rrus|rus|rusb?|mmu|dug|duw|dus|dub|ubbp|npu|ncu|bbu|fbba|rbs|bb)\b/],
  ["برق", /\b(ncr|psu|vpsu|upsu|pbc|fpfc)\b/],
  ["اپتیک", /\b(sfp|sfb|odu|epb|fsmfa|isv3|fiber|fibr|lan|jumper)\b/],
  ["مکانیکی", /\b(cooler|koler|coler|fan|tcu|fcu|flatpack|smart ?pack|anten|antn|gps)\b/],
  ["مصرفی", /\b(fuse|fiuz|batt|batry|esm|ladder)\b/],
];
const fam = (u) => { for (const [n, re] of FAMILY) if (re.test(u)) return n; return "متفرقه"; };

const siteRe = /([a-z]{1,5})\s?-?\s?(\d{4})\b/g;
function findSites(t) {
  const out = new Set(); let m; siteRe.lastIndex = 0;
  while ((m = siteRe.exec(t))) {
    if (m[1] && (!isSitePrefix(m[1]) || UNIT_SET.has(m[1]))) continue;
    out.add((m[1] ? m[1].toUpperCase() : "") + m[2]);
  }
  return [...out];
}
const EV = {
  FAULT: [/\b(fault|faulty|falte|fualt|falt|down|damage|damaged|burn|burnt|broken|trip|busted|bad)\b/,
    /(فالت|فالتی|خراب|خرابی|سوخته|شکسته|دمیج|آب خورده|قطع|پرید|تریپ|ایراد|معیوب)/],
  REQUEST: [/\b(request|need|required|order|shortage|pending|waiting)\b/,
    /(درخواست|نیاز|تقاضا|سفارش|کمبود|موجود نیست|نداریم|در انتظار|باید تهیه|تأمین|تامین)/],
  SUPPLY: [/\b(sent to site|supplied|dispatched|installed on|delivered)\b/,
    /(ارسال شد|ارسالی|فرستاد|فرستاده شد|تحویل سایت|رفت سایت|نصب شد|نصب روی سایت|دمیج شده|دمیج شد|تأمین شد|تامین شد)/],
  RETURN: [/\b(return|rma|returned|back to stock)\b/,
    /(برگشت|برگشتی|عودت|مرجوع|مرجوعی|رفت انبار|برگشت به انبار|تحویل انبار شد|به انبار)/],
  SWAP: [/\b(swap|replaced)\b/, /(تعویض|جایگزینی|جایگزین)/],
  RESTORE: [/\b(recovered|restored|cleared|resolved|fixed)\b/, /(رفع شد|راه ?انداز|بالا آمد|سالم|ریکاور|برطرف)/],
};
const detect = (t) => {
  const hits = Object.entries(EV).filter(([, pats]) => pats.some(p => p.test(t))).map(([k]) => k);
  if (hits.includes("SUPPLY") && hits.includes("RETURN") && /(تحویل انبار شد|برگشت|عودت|مرجوع|رفت انبار)/.test(t)) return hits.filter(h => h !== "SUPPLY");
  if (hits.includes("SWAP") && hits.includes("SUPPLY") && /(تعویض شد با|جایگزین)/.test(t)) return hits.filter(h => h !== "SUPPLY");
  return hits;
};

// ---- pass 1: events ----
const events = [];
for (const f of fs.readdirSync(MERGED).filter(x => x.endsWith(".json"))) {
  const chat = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  for (const m of JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"))) {
    const raw = (m.x || "").replace(/\s+/g, " ").trim();
    if (!raw || raw === "[object Object]") continue;
    const t = PRE(raw);
    if (t.length < 4) continue;
    const units = [...new Set((t.match(UNIT_TOKENS) || []))];
    const sites = findSites(t);
    if (!units.length && !sites.length) continue;
    const evs = detect(t);
    if (!evs.length) continue;
    const snapshot = t.length > 420;
    for (const ev of evs) {
      if (snapshot) continue;
      if (!units.length) {
        for (const s of sites) events.push({ site: s, unit: "", family: "", ev, t: m.d, chat, text: raw.slice(0, 150) });
      } else {
        for (const u of units) events.push({ site: sites[0] || "", unit: u.toUpperCase(), family: fam(u), ev, t: m.d, chat, text: raw.slice(0, 150) });
      }
    }
  }
}
events.sort((a, b) => a.t - b.t);
const byEv = {}; for (const e of events) byEv[e.ev] = (byEv[e.ev] || 0) + 1;
console.log("events:", events.length, JSON.stringify(byEv));

// ---- pass 2: FIFO pairing per unit model ----
// For each unit model keep a queue of open demands; the next supply after them closes one.
const open = new Map();     // unit -> array of open demand objects
const fulfilled = [];       // demand objects that got supplied
for (const e of events) {
  if (!e.unit) continue;
  if (e.ev === "FAULT" || e.ev === "REQUEST") {
    if (!open.has(e.unit)) open.set(e.unit, []);
    const arr = open.get(e.unit);
    // an incoming fault also closes older demand on the SAME site (spare replaced)
    const o = { unit: e.unit, family: e.family, site: e.site, ev: e.ev, t: e.t, text: e.text, chat: e.chat };
    arr.push(o);
    if (arr.length > 40) arr.shift();
  } else if (e.ev === "SUPPLY" || e.ev === "SWAP" || e.ev === "RESTORE") {
    const arr = open.get(e.unit);
    if (!arr || !arr.length) continue;
    // prefer a demand on the same site, else the oldest
    let idx = arr.findIndex(d => d.site && d.site === e.site);
    if (idx < 0) idx = 0;
    const d = arr.splice(idx, 1)[0];
    d.suppliedAt = e.t; d.supplyEv = e.ev; d.supplyText = e.text;
    fulfilled.push(d);
  }
}
const allDemands = [];
for (const arr of open.values()) allDemands.push(...arr);
console.log("demands:", allDemands.length, "| fulfilled:", fulfilled.length, "| unmet:", allDemands.length);

const NOW = Date.now();
const d2 = (ms) => new Date(ms + 3.5 * 3600000).toISOString().slice(0, 10);
const q = (v) => `"${String(v ?? "").replace(/"/g, "'").replace(/[\r\n]+/g, " ")}"`;
const B = "\uFEFF";

// 1) unit failure ranking
const agg = new Map();
for (const d of allDemands.concat(fulfilled)) {
  if (!agg.has(d.unit)) agg.set(d.unit, { unit: d.unit, family: d.family, faults: 0, requests: 0, sites: new Set(), first: d.t, last: d.t, samples: [] });
  const a = agg.get(d.unit);
  if (d.ev === "FAULT") a.faults++; else a.requests++;
  if (d.site) a.sites.add(d.site);
  a.first = Math.min(a.first, d.t); a.last = Math.max(a.last, d.t);
  if (a.samples.length < 3) a.samples.push(d.text);
}
let c1 = B + ["unit","family","faults","requests","total","first_fault","last_fault","sites","sample"].map(q).join(",") + "\n";
for (const a of [...agg.values()].sort((x, y) => y.faults - x.faults)) {
  c1 += [a.unit, a.family, a.faults, a.requests, a.faults + a.requests, d2(a.first), d2(a.last), a.sites.size, a.samples.join(" || ")].map(q).join(",") + "\n";
}
fs.writeFileSync(path.join(OUT, "1_unit_failure_ranking.csv"), c1, "utf8");

// 2) slowest supply — real pairs only, sorted desc
fulfilled.sort((a, b) => (b.suppliedAt - b.t) - (a.suppliedAt - a.t));
let c2 = B + ["unit","family","site","demand_date","supply_date","lead_days","demand_type","supply_type","demand_msg","supply_msg"].map(q).join(",") + "\n";
for (const d of fulfilled) {
  const lead = (d.suppliedAt - d.t) / 86400000;
  if (lead < 1) continue;
  c2 += [d.unit, d.family, d.site, d2(d.t), d2(d.suppliedAt), lead.toFixed(1),
    d.ev === "FAULT" ? "خرابی" : "درخواست", d.supplyEv === "SUPPLY" ? "ارسال" : d.supplyEv === "SWAP" ? "تعویض" : "رفع",
    d.text, d.supplyText].map(q).join(",") + "\n";
}
fs.writeFileSync(path.join(OUT, "3_slowest_supply.csv"), c2, "utf8");

// 3) unmet — demands with no supply, by age
const unmet = allDemands.filter(d => !d.suppliedAt).sort((a, b) => (b.ev === "FAULT") - (a.ev === "FAULT") || b.t - a.t);
let c3 = B + ["unit","family","site","type","first_demand","last_demand","days_open","status","message"].map(q).join(",") + "\n";
for (const d of unmet) {
  const days = (NOW - d.t) / 86400000;
  if (d.ev !== "FAULT") continue;                 // report unmet FAULTS (real shortages)
  const status = days > 365 ? "معوق بیش از ۱ سال" : days > 180 ? "معوق بیش از ۶ ماه" : days > 90 ? "معوق بیش از ۳ ماه" : days > 30 ? "در انتظار بیش از ۱ ماه" : "اخیر";
  c3 += [d.unit, d.family, d.site, "خرابی", d2(d.t), d2(d.t), days.toFixed(0), status, d.text].map(q).join(",") + "\n";
}
fs.writeFileSync(path.join(OUT, "4_unmet_demand.csv"), c3, "utf8");

// 4) warehouse moves (strictly separated)
const ret = events.filter(e => e.ev === "RETURN");
const sup = events.filter(e => e.ev === "SUPPLY" || e.ev === "SWAP");
let c4 = B + ["direction","unit","family","site","date","chat","message"].map(q).join(",") + "\n";
for (const e of ret) c4 += ["بازگشت به انبار", e.unit, e.family, e.site, d2(e.t), e.chat, e.text].map(q).join(",") + "\n";
for (const e of sup) c4 += ["ارسال به سایت", e.unit, e.family, e.site, d2(e.t), e.chat, e.text].map(q).join(",") + "\n";
fs.writeFileSync(path.join(OUT, "4_warehouse_moves.csv"), c4, "utf8");

// 5) timeline
const NAME = { FAULT: "خرابی", REQUEST: "درخواست قطعه", SUPPLY: "ارسال به سایت", RETURN: "بازگشت به انبار", SWAP: "تعویض", RESTORE: "رفع خرابی" };
let c5 = B + ["date","event","unit","family","site","chat","message"].map(q).join(",") + "\n";
for (const e of events) c5 += [new Date(e.t + 3.5 * 3600000).toISOString().slice(0, 19).replace("T", " "), NAME[e.ev], e.unit, e.family, e.site, e.chat, e.text].map(q).join(",") + "\n";
fs.writeFileSync(path.join(OUT, "5_event_timeline.csv"), c5, "utf8");

console.log("\nTOP FAILING:", [...agg.values()].sort((a,b)=>b.faults-a.faults).slice(0,8).map(a=>`${a.unit}:${a.faults}`).join(" "));
console.log("SLOWEST SUPPLY:", fulfilled.filter(d=>(d.suppliedAt-d.t)/86400000>=7).slice(0,8).map(d=>`${d.unit}@${d.site}:${Math.round((d.suppliedAt-d.t)/86400000)}d`).join(" "));
console.log("UNMET faults:", unmet.filter(d=>d.ev==="FAULT").length);