// Minimal CDP (Chrome DevTools Protocol) client over raw WebSocket (RFC6455)
// built on node:http + node:crypto. No external deps.
import http from "node:http";
import crypto from "node:crypto";

function encodeFrame(opcode, payload) {
  const mask = crypto.randomBytes(4);
  const len = payload.length;
  let header;
  if (len < 126) {
    header = Buffer.from([0x80 | opcode, 0x80 | len]);
  } else if (len < 65536) {
    header = Buffer.alloc(4);
    header[0] = 0x80 | opcode;
    header[1] = 0x80 | 126;
    header.writeUInt16BE(len, 2);
  } else {
    header = Buffer.alloc(10);
    header[0] = 0x80 | opcode;
    header[1] = 0x80 | 127;
    header.writeBigUInt64BE(BigInt(len), 2);
  }
  const masked = Buffer.alloc(len);
  for (let i = 0; i < len; i++) masked[i] = payload[i] ^ mask[i & 3];
  return Buffer.concat([header, mask, masked]);
}

export class WsClient {
  constructor(url) {
    this.url = url;
    this.pending = new Map();
    this.handlers = new Map(); // method -> Set(fn)
    this.id = 0;
    this.buffer = Buffer.alloc(0);
    this.fragments = null; // {opcode, chunks}
    this.closed = false;
  }

  async connect() {
    const u = new URL(this.url);
    const key = crypto.randomBytes(16).toString("base64");
    return new Promise((resolve, reject) => {
      const req = http.request({
        host: u.hostname,
        port: u.port,
        path: u.pathname + u.search,
        headers: {
          Host: `${u.hostname}:${u.port}`,
          Upgrade: "websocket",
          Connection: "Upgrade",
          "Sec-WebSocket-Key": key,
          "Sec-WebSocket-Version": "13",
        },
      });
      req.on("upgrade", (res, socket) => {
        this.socket = socket;
        socket.on("data", (chunk) => this._onData(chunk));
        socket.on("error", (e) => this._onClose(e));
        socket.on("close", () => this._onClose(new Error("socket closed")));
        resolve(this);
      });
      req.on("response", (res) => reject(new Error(`Upgrade refused: ${res.statusCode}`)));
      req.on("error", reject);
      req.end();
    });
  }

  _onClose(err) {
    if (this.closed) return;
    this.closed = true;
    for (const p of this.pending.values()) p.reject(err || new Error("closed"));
    this.pending.clear();
  }

  _onData(chunk) {
    this.buffer = Buffer.concat([this.buffer, chunk]);
    while (true) {
      const parsed = this._parseFrame();
      if (!parsed) break;
      this._handleFrame(parsed);
    }
  }

  _parseFrame() {
    const buf = this.buffer;
    if (buf.length < 2) return null;
    const opcode = buf[0] & 0x0f;
    const masked = (buf[1] & 0x80) !== 0;
    let len = buf[1] & 0x7f;
    let offset = 2;
    if (len === 126) {
      if (buf.length < 4) return null;
      len = buf.readUInt16BE(2);
      offset = 4;
    } else if (len === 127) {
      if (buf.length < 10) return null;
      const big = buf.readBigUInt64BE(2);
      if (big > BigInt(64 * 1024 * 1024)) throw new Error("frame too large");
      len = Number(big);
      offset = 10;
    }
    let maskKey = null;
    if (masked) {
      if (buf.length < offset + 4) return null;
      maskKey = buf.subarray(offset, offset + 4);
      offset += 4;
    }
    if (buf.length < offset + len) return null;
    const payload = Buffer.from(buf.subarray(offset, offset + len));
    if (maskKey) for (let i = 0; i < len; i++) payload[i] ^= maskKey[i & 3];
    this.buffer = buf.subarray(offset + len);
    return { opcode, payload };
  }

  _handleFrame({ opcode, payload }) {
    if (opcode === 0x9) {
      // ping -> pong (masked)
      this.socket.write(encodeFrame(0xA, payload));
      return;
    }
    if (opcode === 0x8) {
      this._onClose(new Error("close frame"));
      return;
    }
    if (opcode === 0x1 || opcode === 0x2 || opcode === 0x0) {
      if (opcode !== 0x0 && (payload.length === 0)) return;
      if (opcode === 0x0) {
        if (!this.fragments) return;
        this.fragments.chunks.push(payload);
        const fin = true; // handled below
      }
      let full;
      if (opcode === 0x0) {
        full = Buffer.concat(this.fragments.chunks);
        this.fragments = null;
      } else {
        full = payload; // CDP sends unfragmented text in practice
      }
      const text = full.toString("utf8");
      let msg;
      try { msg = JSON.parse(text); } catch { return; }
      if (msg.id !== undefined && this.pending.has(msg.id)) {
        const p = this.pending.get(msg.id);
        this.pending.delete(msg.id);
        if (msg.error) p.reject(new Error(msg.error.message || JSON.stringify(msg.error)));
        else p.resolve(msg);
      } else if (msg.method) {
        const set = this.handlers.get(msg.method);
        if (set) for (const fn of set) fn(msg.params);
        const any = this.handlers.get("*");
        if (any) for (const fn of any) fn(msg);
      }
    }
  }

  send(method, params = {}, timeoutMs = 120000) {
    if (this.closed) return Promise.reject(new Error("ws closed"));
    const id = ++this.id;
    return new Promise((resolve, reject) => {
      const timer = setTimeout(() => {
        this.pending.delete(id);
        reject(new Error(`CDP timeout: ${method}`));
      }, timeoutMs);
      this.pending.set(id, {
        resolve: (v) => { clearTimeout(timer); resolve(v); },
        reject: (e) => { clearTimeout(timer); reject(e); },
      });
      this.socket.write(encodeFrame(0x1, Buffer.from(JSON.stringify({ id, method, params }), "utf8")));
    });
  }

  on(method, fn) {
    if (!this.handlers.has(method)) this.handlers.set(method, new Set());
    this.handlers.get(method).add(fn);
  }

  async evalJs(expression, timeoutMs = 60000) {
    const r = await this.send(
      "Runtime.evaluate",
      { expression, returnByValue: true, awaitPromise: true, timeout: timeoutMs > 60000 ? timeoutMs : undefined },
      timeoutMs
    );
    if (r.error) throw new Error(r.error.message);
    const res = r.result;
    if (res?.exceptionDetails) {
      const d = res.exceptionDetails;
      throw new Error("Page exception: " + (d.exception?.description || d.text || "unknown"));
    }
    return res?.result?.value;
  }

  close() {
    try { this.socket.end(); } catch {}
    this.closed = true;
  }
}

export async function connectPage(pageWsUrl) {
  const c = new WsClient(pageWsUrl);
  await c.connect();
  await c.send("Runtime.enable");
  return c;
}

// Fetch target list and find the web.bale.ai page target
export async function findBalePage() {
  const list = await new Promise((resolve, reject) => {
    http.get("http://127.0.0.1:9223/json/list", (res) => {
      let b = "";
      res.on("data", (c) => (b += c));
      res.on("end", () => resolve(JSON.parse(b)));
    }).on("error", reject);
  });
  return list.filter((t) => t.type === "page" && t.url.includes("web.bale.ai"));
}
