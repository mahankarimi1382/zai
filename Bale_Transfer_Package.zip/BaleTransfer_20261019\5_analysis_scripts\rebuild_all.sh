#!/bin/bash
# One-shot: re-merge deep data into report set and rebuild all analysis CSVs
cd "C:/Users/someBody/.zcode/workspace/default" || exit 1
echo "=== merging ==="
node merge_build_report.mjs 2>&1 | head -4
echo "=== unit cycle ==="
node unit_cycle.mjs 2>&1 | head -4
echo "=== clean exports ==="
node clean_exports.mjs 2>&1 | grep -E "wrote|faults"
echo "=== done ==="