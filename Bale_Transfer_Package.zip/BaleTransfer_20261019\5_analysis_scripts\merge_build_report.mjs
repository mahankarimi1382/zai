// Merge deep + 90-day data, build unit index and CSV reports
import fs from "node:fs";
import path from "node:path";

const DEEP = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_data_deep";
const OLD  = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_data";
const OUT  = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report";
const MERGED = path.join(OUT, "merged");
fs.mkdirSync(MERGED, { recursive: true });

const GROUPS = new Set(["8339623","96342159","184347948","226526641","231181343","351194861","517632817","729401255","785878952","786128402","1007814392","1048230922","1063843314","1067330875","1195001957","1206812704","1265656539","1314721953","1342929147","1358671243","1365646822","1396994789","1703520267","1729376405","1737503770","1762947819","1910422633","1917376212","1918042926","1948954274","1986682312","2011482672","2048354559","2061599862","2085953014","2113853239","2139039927","2141244797","2145164056"]);

const normalize = (s) => String(s)
  .replace(/[۰-۹]/g, d => "۰۱۲۳۴۵۶۷۸۹".indexOf(d))
  .replace(/[٠-٩]/g, d => "٠١٢٣٤٥٦٧٨٩".indexOf(d));

// --- merge per chat ---
const byId = new Map();
function ingest(dir) {
  if (!fs.existsSync(dir)) return;
  for (const f of fs.readdirSync(dir)) {
    if (!f.endsWith(".json") || f === "_users.json" || f === "_index.json") continue;
    const id = f.split("_")[0];
    if (!byId.has(id)) byId.set(id, { id, name: f.replace(/^\d+_/, "").replace(/\.json$/, "").replace(/\.partial$/, ""), rows: new Map() });
    const chat = byId.get(id);
    const rows = JSON.parse(fs.readFileSync(path.join(dir, f), "utf8"));
    for (const r of rows) {
      if (!r || !r.rid) continue;
      const prev = chat.rows.get(r.rid);
      const rec = { rid: r.rid, d: Number(r.d), u: r.u, t: r.t, x: r.x || "", f: r.f || "", out: r.out };
      // prefer version with text
      if (!prev || (!prev.x && rec.x)) chat.rows.set(r.rid, rec);
    }
  }
}
ingest(DEEP); ingest(OLD);

const users = new Map();
const ufile = path.join(OLD, "_users.json");
if (fs.existsSync(ufile)) for (const u of JSON.parse(fs.readFileSync(ufile, "utf8"))) users.set(String(u.id), u.name);

const index = [];
let grandTotal = 0;
for (const [id, chat] of byId) {
  const arr = [...chat.rows.values()].sort((a, b) => a.d - b.d);
  grandTotal += arr.length;
  fs.writeFileSync(path.join(MERGED, `${id}_${chat.name}.json`), JSON.stringify(arr));
  const dates = arr.map(r => r.d).filter(Boolean);
  index.push({
    id, name: chat.name, kind: GROUPS.has(id) ? "group" : "personal",
    total: arr.length,
    from: dates.length ? new Date(Math.min(...dates)).toISOString().slice(0, 10) : "",
    to: dates.length ? new Date(Math.max(...dates)).toISOString().slice(0, 10) : "",
    months: new Set(dates.map(d => new Date(d).toISOString().slice(0, 7))).size,
  });
}
index.sort((a, b) => b.total - a.total);
fs.writeFileSync(path.join(OUT, "_merged_index.json"), JSON.stringify(index, null, 1));
fs.writeFileSync(path.join(OUT, "_users_map.json"), JSON.stringify([...users.entries()]));
let csv = "\uFEFFchat_id,chat_name,chat_type,total_messages,first_date,last_date,months_covered\n";
for (const r of index) csv += `${r.id},"${r.name.replace(/"/g, "'")}",${r.kind},${r.total},${r.from},${r.to},${r.months}\n`;
fs.writeFileSync(path.join(OUT, "01_chat_index.csv"), csv, "utf8");

console.log("merged chats:", byId.size, "| total messages:", grandTotal);
for (const r of index.slice(0, 25)) console.log(`${r.kind}\t${r.total}\t${r.from} → ${r.to}\t${r.months}mo\t${r.name}`);