// Find warehouse/logistics staff in the warehouse-related groups: who receives/delivers material
import fs from "node:fs";
import path from "node:path";

const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const OLD    = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_data";

// sender id -> phone/name
const users = new Map();
const uf = path.join(OLD, "_users.json");
if (fs.existsSync(uf)) for (const u of JSON.parse(fs.readFileSync(uf, "utf8"))) users.set(String(u.id), { name: u.name, phone: u.phone || "" });

const WAREHOUSE_CHATS = ["1737503770","517632817","785878952","1729376405","1918042926","2061599862","1048230922","786128402","8339623","1206812704"];
// contexts where a person is acting as a warehouse/logistics person
const ROLES = {
  "انباردار (تحویل/دریافت)": /(تحویل\s?(داده|گرفته)?\s?شد|تحویل\s?انبار|دریافت\s?(شد|کرد)|ارسال\s?شد|فرستاد|برد\s?انبار|به\s?انبار)/,
  "هماهنگ کننده ارسال/اسنپ": /(اسنپ|اپارات|پست\s?پیش|ارسال\s?مرسوله|پیک|باربری|حمل\s?و\s?نقل|courier)/,
  "انبار/موجودی": /(انبار|موجودی|انبارگردانی|stock|warehouse)/,
  "کلید/دسترسی سایت": /(کلید|key\s?request|دسترسی\s?سایت|تحویل\s?کلید)/,
};
// explicit mentions of a person in a warehouse action: "@name ... تحویل" or "تحویل ... به آقای X"
const mentionRe = /@([A-Za-z0-9_.]{3,30})/g;

const staff = new Map(); // uid -> {name, phone, roles:{}, chats:{}, counts:{}}
const byName = new Map(); // normalized name -> uid

const files = fs.readdirSync(MERGED).filter(f => f.endsWith(".json"));
for (const f of files) {
  const id = f.split("_")[0];
  if (!WAREHOUSE_CHATS.includes(id)) continue;
  const chat = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  for (const m of JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"))) {
    const raw = (m.x || "").replace(/\s+/g, " ").trim();
    if (!raw || raw === "[object Object]") continue;
    const roleHit = Object.entries(ROLES).find(([, re]) => re.test(raw));
    if (!roleHit) continue;
    // who is the sender
    const uid = String(m.u);
    if (!staff.has(uid)) {
      const meta = users.get(uid) || {};
      const nm = meta.name || ("uid_" + uid);
      staff.set(uid, { uid, name: nm, phone: meta.phone || "", roles: {}, chats: {}, total: 0 });
    }
    const s = staff.get(uid);
    s.total++;
    s.roles[roleHit[0]] = (s.roles[roleHit[0]] || 0) + 1;
    s.chats[chat] = (s.chats[chat] || 0) + 1;
    // collect mentioned handles in the same message (the actor doing the delivery)
    mentionRe.lastIndex = 0;
    let mm;
    while ((mm = mentionRe.exec(raw))) {
      const h = mm[1];
      // resolve handle -> uid via users map (handles are often the username)
      const cand = [...users.entries()].find(([, v]) => v.name && v.name.replace(/[\s_.]/g, "").toLowerCase() === h.replace(/[\s_.]/g, "").toLowerCase());
      const huid = cand ? cand[0] : ("handle:" + h);
      if (!staff.has(huid)) {
        const meta = users.get(huid) || {};
        staff.set(huid, { uid: huid, name: meta.name || h, phone: meta.phone || "", roles: {}, chats: {}, total: 0 });
      }
      const hs = staff.get(huid);
      hs.roles["منشی اقدام انباری"] = (hs.roles["منشی اقدام انباری"] || 0) + 1;
      hs.chats[chat] = (hs.chats[chat] || 0) + 1;
      hs.total++;
    }
  }
}

const rows = [...staff.values()]
  .filter(s => Object.keys(s.roles).length > 0)
  .sort((a, b) => b.total - a.total);

// print top senders in warehouse chats + mentioned actors
console.log("=== WAREHOUSE STAFF (by activity) ===");
for (const s of rows.slice(0, 30)) {
  const roles = Object.entries(s.roles).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k}(${v})`).join("; ");
  console.log(`${String(s.total).padStart(4)} | ${s.name} | ${s.phone || "(no phone in users map)"} | ${roles}`);
}

// also dump top senders per warehouse chat with names
console.log("\n=== TOP SENDERS PER WAREHOUSE CHAT ===");
for (const id of WAREHOUSE_CHATS) {
  const f = files.find(x => x.startsWith(id + "_"));
  if (!f) continue;
  const chat = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  const cnt = new Map();
  for (const m of JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"))) {
    if (!m.x || m.x === "[object Object]") continue;
    cnt.set(String(m.u), (cnt.get(String(m.u)) || 0) + 1);
  }
  const top = [...cnt.entries()].sort((a, b) => b[1] - a[1]).slice(0, 6)
    .map(([u, n]) => `${users.get(u)?.name || u}:${n}`).join("  ");
  console.log(`${chat} → ${top}`);
}