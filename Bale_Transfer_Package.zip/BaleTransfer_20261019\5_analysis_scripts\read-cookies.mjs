import { DatabaseSync } from "node:sqlite";
import { join } from "node:path";

const dbPath = process.argv[2];
const filter = process.argv[3] || "%bale%";
const db = new DatabaseSync(dbPath, { readOnly: true });
const rows = db
  .prepare(
    `SELECT host_key, name, length(value) as vlen, length(encrypted_value) as elen,
            substr(hex(encrypted_value), 1, 6) as enc_prefix, expires_utc, is_httpOnly, is_persistent, samesite, source_scheme
     FROM cookies WHERE host_key LIKE ? ORDER BY host_key`
  )
  .all(filter);
console.log("total cookies in db:", db.prepare("SELECT COUNT(*) c FROM cookies").get().c);
console.log("bale rows:", rows.length);
for (const r of rows) console.log(JSON.stringify(r));
db.close();
