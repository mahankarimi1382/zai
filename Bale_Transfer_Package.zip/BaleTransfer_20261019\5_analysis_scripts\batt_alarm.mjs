import fs from "node:fs";
import path from "node:path";
const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const files = fs.readdirSync(MERGED).filter(f => f.endsWith(".json"));
const alarmTypes = new Map();
const ticketRe = /NWG-OPS-(?:TT|CR)-(\d{8})-(\d{1,7})/g;
let nTickets = 0, nLinesWithTicket = 0, nNianBat = 0;
const samples = [];
for (const f of files) {
  const name = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"));
  for (const m of msgs) {
    let x = (m.x || "").replace(/\s+/g, " ").trim();
    if (!x || x === "[object Object]") continue;
    ticketRe.lastIndex = 0;
    const tickets = [...x.matchAll(ticketRe)];
    if (tickets.length) { nLinesWithTicket++; nTickets += tickets.length; }
    const mb = x.match(/MBTS[_-]?([A-Z]{1,3}\d{4,5})X?/i);
    // capture alarm text following MBTS_site, e.g. "MBTS_T1015X,Nian Battery Door Open"
    const after = x.match(/MBTS[_-]?[A-Z]{0,4}\d{4,5}X?\s*[,:]?\s*([^|]{3,80}?)(?:\s+[A-Z]{1,3}\d{4}|\s*NWG-OPS|$)/i);
    if (after && /batt/i.test(after[1])) {
      nNianBat++;
      const t = after[1].trim().replace(/[.,;]+$/, "");
      alarmTypes.set(t, (alarmTypes.get(t) || 0) + 1);
      if (samples.length < 40) samples.push({ n: name, d: new Date(m.d + 3.5 * 3600000).toISOString().slice(0, 10), x: x.slice(0, 220) });
    }
    if (/batt/i.test(x) && /NWG-OPS/.test(x) && samples.length < 400 && samples.filter(s => s.n === name).length < 4)
      samples.push({ n: name, d: new Date(m.d + 3.5 * 3600000).toISOString().slice(0, 10), x: x.slice(0, 220) });
  }
}
console.log("tickets total:", nTickets, "| lines with ticket:", nLinesWithTicket, "| nian-batt alarms:", nNianBat);
console.log("\n--- alarm type histogram ---");
for (const [k, v] of [...alarmTypes.entries()].sort((a, b) => b[1] - a[1]).slice(0, 45)) console.log(String(v).padStart(5), k);
fs.writeFileSync("batt_alarm_samples.json", JSON.stringify(samples, null, 1));