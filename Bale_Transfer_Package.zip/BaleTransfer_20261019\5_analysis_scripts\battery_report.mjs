// Battery & power-outage report for Irancell site chats
// Rules derived from analysis of real messages (see battery_rules.md)
import fs from "node:fs";
import path from "node:path";

const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const OUT    = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_analysis";
fs.mkdirSync(OUT, { recursive: true });

const PRE = (s) => String(s)
  .replace(/[۰-۹]/g, d => String(d.charCodeAt(0) - 0x06F0))
  .replace(/[٠-٩]/g, d => String(d.charCodeAt(0) - 0x0660))
  .replace(/[يى]/g, "ی").replace(/[كک]/g, "ک").replace(/[أإآ]/g, "ا").replace(/[ۀة]/g, "ه")
  .replace(/[ً-ْ]/g, "")
  .replace(/[-‏‎]/g, " ")
  .replace(/\s+/g, " ").toLowerCase().trim();

const isFile = (x) => !x || x === "[object Object]" || (!/[a-z؀-ۿ]{3}/i.test(x));

// site codes (reuse validated prefix whitelist)
const SITE_PREFIXES = new Set(["t","e","n","b","h","d","l","f","g","k","c","m","s","v","w","a","r","j","x","y",
  "dt","lt","lut","dl","dlut","dd","th","tu","tn","te","teb","ter","kr","tr","ha","haye","tw","pk"]);
const NOT_SITE = /(good|bad|fault|falt|down|add|rem|req|ok|new|old|noa|site|cell|unit|pack|esm|adu|batty|batt|battery|hub|mains|vol|amp|cell)/;
function isSitePrefix(p) {
  const w = String(p).toLowerCase().replace(/\s|-/g, "");
  if (SITE_PREFIXES.has(w)) return true;
  if (NOT_SITE.test(w)) return false;
  return /^[a-z]{2,5}$/.test(w) && /[tlscbrd]$/.test(w);
}
const siteRe = /(^|[^\w])([a-z]{0,2})\s?-?\s?(\d{3,4})\b/g;
function findSites(t) {
  const out = new Set();
  let m; siteRe.lastIndex = 0;
  while ((m = siteRe.exec(t))) {
    if (m[2] && !isSitePrefix(m[2])) continue;
    if (!m[2] && !/(\d{4})/.test(m[3])) continue;
    const code = (m[2] ? m[2].toUpperCase() : "") + m[3];
    if (/^(19|20)\d{2}$/.test(code)) continue;              // years
    if (/^(0[0-9]|10|11|12)$/.test(code)) continue;           // clock times
    out.add(code);
  }
  return [...out];
}
const TICKET = /\b(nwg-ops-tt-\d{8}-\d+)\b/;
const MBTS = /\bmbts_([a-z]{0,2}\d{3,4})x?\b/;

// ---------- battery keywords ----------
const BAT = /(باطری|باتری|باتري|battery|batt\b|سلول|cell\s?batt|esm|bbu\s?bat|استندبای|standby)/;
const POWER_CUT = /(قطع\s?(ب?رق|برق)|برق\s?(رفت|قطع|نرفت|نیست)|قطعی\s?برق|no\s?power|power\s?(cut|out|fail|off)|blackout|outage|خاموشی\s?سایت|انرژی\s?نیست|فقط\s?باتری|روی\s?باتری|باتری\s?می‌?رود|باتری\s?میرود)/;
const DG = /(دیزل|دیزل\s?ژنراتور|dg\b|ژنراتور|generator|genset)/;
const HUB_MAINS = /(hub\s?mains| mains\s?v|ولتاژ\s?ورودی)/;

// battery states
const ST = {
  FAULT:     /(باطری|باتری|باتري|battery|batt|سلول|cell|esm)[^.]{0,40}(خراب|فالت|معیوب|سوخته|باس|اتصال کوتاه|شرابی|leak|dead|failed|fault|broken)|(خراب|فالت|معیوب|سوخته|باس|failed|fault|broken)[^.]{0,25}(باطری|باتری|battery|batt|سلول|esm)/,
  MISSING:   /(فاقد\s?باطری|فاقد\s?باتری|بدون\s?باطری|بدون\s?باتری|باتری\s?ندار|باطری\s?ندار|نداشته\s?باطری|no\s?battery|battery\s?missing|missing\s?battery|باتری\s?نصب\s?نیست|بدون\s?سلول)/,
  TEST:      /(تست\s?باطری|تست\s?باتری|باطری\s?تست|باتری\s?تست|تست\s?شد|تست\s?شده|باطری\s?تستی|شارژ\s?تست|test\s?battery|battery\s?test|تست\s?شارژ)/,
  SWAP:      /(تعویض\s?باطری|تعویض\s?باتری|تعویض\s?باتری|تعویض\s?بطری|باطری\s?تعویض|باتری\s?تعویض|تعویض\s?سلول|adding\s?battery|add\s?battery)/,
  REMOVED:   /(از\s?مدار\s?خارج|خارج\s?کردن\s?باطری|باطری\s?خارج|فیوز\s?باطری|باطری\s?سوخت|حذف\s?باطری)/,
  HEALTHY:   /(باطری\s?سالم|باتری\s?سالم|باطری\s?سالم|باطری\s?سالم|سالم\s?بود|ok\s?بود|healthy|در\s?مدار|شارژ\s?کامل|باطری\s?تست\s?شد)/,
  NO_POWER:  /(برق\s?رفت|قطع\s?ب?رق|برق\s?قطع|no\s?power|power\s?cut)/,
  NOT_ON_BAT:/(روی\s?باتری\s?نمی?ر|روی\s?باطری\s?نمی?ر|باتری\s?نمی?گیرد|روی\s?باتری\s?نرفت|به\s?باتری\s?نرفت|نرفت\s?روی\s?باتری|سایت\s?خاموش\s?شد|down\s?شد)/,
  LOW_VOLT:  /(ولتاژ\s?پایین|ولتاژ\s?کم|low\s?voltage|undervoltage|ولتاژ\s?افت|drop\s?voltage|دشارژ|discharge|خالی\s?شد)/,
  HIGH_TEMP: /(دمای\s?بالا|دما\s?زیاد| overheating|high\s?temperature|داغ)/,
  COOLING:   /(کولینگ|cooling\s?failure|فن\s?باطری|سرمایش\s?ندارد)/,
  HUB_MAINS: /(hub\s?mains| mains\s?v|ولتاژ\s?ورودی)/,
  DOOR:      /(door\s?open|در\s?باز\s?شد|باز\s?بودن\s?درب|قفل\s?فنس|fence\s?lock|شکستن\s?درب|vandal)/,
};

const rows = [];        // per-message battery facts
const outage = [];     // power-cut incidents
const files = fs.readdirSync(MERGED).filter(f => f.endsWith(".json"));
let scanned = 0, battMsgs = 0;

for (const f of files) {
  const chat = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"));
  for (const m of msgs) {
    scanned++;
    const raw = (m.x || "").replace(/\s+/g, " ").trim();
    if (isFile(raw)) continue;
    const t = PRE(raw);
    if (!BAT.test(t) && !POWER_CUT.test(t) && !HUB_MAINS.test(t)) continue;
    battMsgs++;
    const tk = TICKET.exec(t);
    const mb = MBTS.exec(t);
    let sites = findSites(t);
    if (mb) sites.unshift(mb[1].toUpperCase());
    const date = new Date(m.d + 3.5 * 3600000).toISOString().slice(0, 10);
    const state = [];
    for (const [k, re] of Object.entries(ST)) if (re.test(t)) state.push(k);
    if (!state.length && !tk && sites.length === 0) continue;
    const siteLabel = sites.length ? sites.join("|") : (mb ? mb[1].toUpperCase() : "");
    rows.push({ date, sites: siteLabel, states: state.join("|"), chat, ticket: tk ? tk[1] : "", text: raw.slice(0, 180) });
    // power-cut incidents
    if (POWER_CUT.test(t) || (ST.NOT_ON_BAT.test(t))) {
      let cause = "قطعی برق";
      if (ST.NOT_ON_BAT.test(t) || /باتری\s?ندار|فاقد\s?ب?اط|missing\s?battery/i.test(t)) cause = "قطعی برق + نبود/خرابی باطری";
      else if (ST.FAULT.test(t)) cause = "قطعی برق + خرابی باطری";
      else if (DG.test(t)) cause = "قطعی برق + مشکل دیزل ژنراتور";
      outage.push({ date, sites: siteLabel, cause, hasDg: DG.test(t) ? 1 : 0, hasBatMissing: ST.MISSING.test(t) ? 1 : 0, chat, text: raw.slice(0, 180) });
    }
  }
}
console.log(`scanned: ${scanned} | battery/power messages: ${battMsgs} | classified rows: ${rows.length} | outages: ${outage.length}`);

// ---------- aggregate per site ----------
const siteAgg = new Map();
for (const r of rows) {
  if (!r.sites) continue;
  for (const s of r.sites.split("|")) {
    if (!s) continue;
    if (!siteAgg.has(s)) siteAgg.set(s, { site: s, faults: 0, missing: 0, tests: 0, swaps: 0, removed: 0, healthy: 0, outages: 0, first: r.date, last: r.date, samples: [] });
    const a = siteAgg.get(s);
    for (const st of r.states.split("|")) {
      if (st === "FAULT") a.faults++;
      else if (st === "MISSING") a.missing++;
      else if (st === "TEST") a.tests++;
      else if (st === "SWAP") a.swaps++;
      else if (st === "REMOVED") a.removed++;
      else if (st === "HEALTHY") a.healthy++;
      else if (st === "NO_POWER") a.outages++;
    }
    if (r.date < a.first) a.first = r.date;
    if (r.date > a.last) a.last = r.date;
    if (a.samples.length < 3) a.samples.push(r.text);
  }
}
const stateName = { FAULT: "خرابی باطری", MISSING: "فاقد باطری", TEST: "تست باطری", SWAP: "تعویض باطری", REMOVED: "خارج‌کردن از مدار", HEALTHY: "سالم", NO_POWER: "قطعی برق", NOT_ON_BAT: "نرفت روی باتری", LOW_VOLT: "ولتاژ پایین", HIGH_TEMP: "دمای بالا", COOLING: "خرابی کولینگ", HUB_MAINS: "پایش برق ورودی", DOOR: "درب/فنس" };
const B = "\uFEFF";
const esc = (v) => `"${String(v ?? "").replace(/"/g, "'").replace(/[\r\n]+/g, " ")}"`;

// 8a) per-site battery status
let c8a = B + ["site","faults","missing","tests","swaps","removed","healthy","power_cut","first","last","status","sample"].map(esc).join(",") + "\n";
for (const a of [...siteAgg.values()].sort((x, y) => y.faults + y.missing - (x.faults + x.missing))) {
  const status = a.missing > 0 && a.faults === 0 ? "فاقد باطری" : a.faults > 0 ? "دارای خرابی باطری" : a.healthy > 0 ? "سالم" : a.tests > 0 ? "در حال تست" : "نامشخص";
  c8a += [a.site, a.faults, a.missing, a.tests, a.swaps, a.removed, a.healthy, a.outages, a.first, a.last, status, a.samples.join(" || ")].map(esc).join(",") + "\n";
}
fs.writeFileSync(path.join(OUT, "8a_battery_by_site.csv"), c8a, "utf8");

// 8b) battery event timeline (site + state)
let c8b = B + ["date","site","state","chat","message"].map(esc).join(",") + "\n";
for (const r of rows) for (const st of (r.states.split("|").length ? r.states.split("|") : ["—"])) {
  c8b += [r.date, r.sites, stateName[st] || st, r.chat, r.text].map(esc).join(",") + "\n";
}
fs.writeFileSync(path.join(OUT, "8b_battery_events.csv"), c8b, "utf8");

// 8c) power-cut incidents with cause
let c8c = B + ["date","site","cause","has_dg","battery_missing","chat","message"].map(esc).join(",") + "\n";
for (const o of outage) c8c += [o.date, o.sites, o.cause, o.hasDg, o.hasBatMissing, o.chat, o.text].map(esc).join(",") + "\n";
fs.writeFileSync(path.join(OUT, "8c_power_outages.csv"), c8c, "utf8");

// 8d) battery unit stats (aggregate states)
const stat = {};
for (const r of rows) for (const st of (r.states.split("|"))) stat[st] = (stat[st] || 0) + 1;
let c8d = B + ["state","count"].map(esc).join(",") + "\n";
for (const [k, v] of Object.entries(stat).sort((a, b) => b[1] - a[1])) c8d += [stateName[k] || k, v].map(esc).join(",") + "\n";
fs.writeFileSync(path.join(OUT, "8d_battery_stats.csv"), c8d, "utf8");

console.log("\nbattery state stats:", JSON.stringify(stat));
const bySiteArr = [...siteAgg.values()];
console.log("sites touched:", bySiteArr.length, "| with battery fault:", bySiteArr.filter(a => a.faults > 0).length,
  "| missing battery:", bySiteArr.filter(a => a.missing > 0).length, "| healthy-only:", bySiteArr.filter(a => a.faults === 0 && a.missing === 0 && a.healthy > 0).length);
const causeAgg = {};
for (const o of outage) causeAgg[o.cause] = (causeAgg[o.cause] || 0) + 1;
console.log("outage causes:", JSON.stringify(causeAgg));
console.log("\ntop battery-fault sites:");
for (const a of bySiteArr.filter(x => x.faults > 0).sort((x, y) => y.faults - x.faults).slice(0, 10)) console.log(`  ${a.site}\tfaults=${a.faults}\tmissing=${a.missing}\toutages=${a.outages}`);