// Clean, presentation-ready CSV exports from the unit cycle engine
import fs from "node:fs";
import path from "node:path";
const A = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_analysis";
const B = "\uFEFF";
const readCsv = (f) => {
  const lines = fs.readFileSync(path.join(A, f), "utf8").replace(/^\uFEFF/, "").split("\n").filter(Boolean);
  const head = [];
  { let cur = "", q = false;
    for (const ch of lines[0]) { if (ch === '"') q = !q; else if (ch === "," && !q) { head.push(cur); cur = ""; } else cur += ch; }
    head.push(cur); }
  const rows = lines.slice(1).map(l => {
    const out = []; let cur = "", q = false;
    for (const ch of l) {
      if (ch === '"') q = !q;
      else if (ch === "," && !q) { out.push(cur); cur = ""; }
      else cur += ch;
    }
    out.push(cur);
    const o = {};
    head.forEach((h, i) => { o[h] = out[i] ?? ""; });
    return o;
  });
  return { head, rows };
};
const w = (f, head, rows) => {
  const esc = (v) => `"${String(v ?? "").replace(/"/g, "'").replace(/[\r\n]+/g, " ")}"`;
  fs.writeFileSync(path.join(A, f), B + head.map(esc).join(",") + "\n" + rows.map(r => head.map(h => esc(r[h])).join(",")).join("\n") + "\n", "utf8");
  console.log("wrote", f, rows.length, "rows");
};

// 1) worst failing unit MODELS (compact: no site dump)
const worst = readCsv("1_worst_failed_units.csv");
w("1_unit_failure_ranking.csv",
  ["unit","family","faults","requests","total","first_fault","last_fault","distinct_sites","top_sites","sample"],
  worst.rows.map(r => ({ unit: r.unit, family: r.family, faults: r.fault_count, requests: r.request_count,
    total: Number(r.fault_count || 0) + Number(r.request_count || 0), first_fault: r.first_fault, last_fault: r.last_fault,
    distinct_sites: String(r.sites ? r.sites.split("|").filter(Boolean).length : 0),
    top_sites: (r.sites || "").split("|").filter(Boolean).slice(0, 12).join(" "),
    sample: (r.sample || "").slice(0, 140) })));

// 2) worst failing SITES
const sites = readCsv("1b_worst_failed_sites.csv");
w("2_site_failure_ranking.csv", ["site","faults","requests","first_fault","last_fault","sample"],
  sites.rows.map(r => ({ site: r.site, faults: r.fault_count, requests: r.request_count, first_fault: r.first_fault, last_fault: r.last_fault, sample: (r.sample || "").slice(0, 140) })));

// 3) slowest supply (real leads only)
const slow = readCsv("2_slowest_supply.csv");
const slowReal = slow.rows.filter(r => r.unit && Number(r.lead_days) >= 1);
w("3_slowest_supply.csv",
  ["unit","site","faults","requests","demand_date","supply_date","lead_days","supply_type","sample_demand"],
  slowReal.map(r => ({ unit: r.unit, site: r.site, faults: r.fault_count, requests: r.request_count,
    demand_date: r.demand_date, supply_date: r.supply_date, lead_days: r.lead_days, supply_type: r.supply_type,
    sample_demand: (r.sample_demand || "").slice(0, 140) }))
  .sort((a, b) => Number(b.lead_days) - Number(a.lead_days)));

// 4) unmet demand: real faults, sorted by open age
const unmet = readCsv("3_unmet_demand.csv");
const unmetReal = unmet.rows.filter(r => r.unit && Number(r.fault_count) > 0);
w("4_unmet_demand.csv",
  ["unit","site","faults","requests","first_demand","last_demand","days_open","status","sample"],
  unmetReal.map(r => ({ unit: r.unit, site: r.site, faults: r.fault_count, requests: r.request_count,
    first_demand: r.first_demand, last_demand: r.last_demand, days_open: r.days_open, status: r.status,
    sample: (r.sample || "").slice(0, 140) }))
  .sort((a, b) => Number(b.faults) - Number(a.faults) || Number(b.days_open) - Number(a.days_open)));

// 5) warehouse moves: strictly separated
const moves = readCsv("4_warehouse_moves.csv");
w("5a_warehouse_returns.csv", ["unit","family","site","date","message"],
  moves.rows.filter(r => r.direction === "بازگشت به انبار").map(r => ({ unit: r.unit, family: r.family, site: r.site, date: r.date, message: (r.message || "").slice(0, 140) })));
w("5b_warehouse_dispatch.csv", ["unit","family","site","date","message"],
  moves.rows.filter(r => r.direction === "ارسال به سایت").map(r => ({ unit: r.unit, family: r.family, site: r.site, date: r.date, message: (r.message || "").slice(0, 140) })));

// 6) timelines per event type — unit-level and site-level kept apart
const tl = readCsv("5_event_timeline.csv");
const unitLevel = tl.rows.filter(r => r.unit && r.unit !== "");
const siteLevel = tl.rows.filter(r => (!r.unit || r.unit === "") && r.site);
for (const [ev, file] of [["خرابی", "6a_timeline_faults.csv"], ["درخواست قطعه", "6b_timeline_requests.csv"], ["بازگشت به انبار", "6c_timeline_returns.csv"], ["ارسال به سایت", "6d_timeline_dispatch.csv"]]) {
  const sel = unitLevel.filter(r => r.event === ev);
  w(file, ["date","unit","family","site","message"],
    sel.map(r => ({ date: r.date, unit: r.unit, family: r.family, site: r.site, message: (r.message || "").slice(0, 140) })));
}
for (const [ev, file] of [["خرابی", "7a_site_faults.csv"], ["درخواست قطعه", "7b_site_requests.csv"], ["بازگشت به انبار", "7c_site_returns.csv"], ["ارسال به سایت", "7d_site_dispatch.csv"]]) {
  const sel = siteLevel.filter(r => r.event === ev);
  w(file, ["date","site","message"],
    sel.map(r => ({ date: r.date, site: r.site, message: (r.message || "").slice(0, 140) })));
}

// summary numbers
const faults = tl.rows.filter(r => r.event === "خرابی");
const byFamily = {};
for (const f of faults) byFamily[f.family || "نامشخص"] = (byFamily[f.family || "نامشخص"] || 0) + 1;
console.log("\nfaults by family:", JSON.stringify(byFamily));
console.log("total faults:", faults.length, "| requests:", tl.rows.filter(r => r.event === "درخواست قطعه").length,
  "| returns:", tl.rows.filter(r => r.event === "بازگشت به انبار").length,
  "| dispatch:", tl.rows.filter(r => r.event === "ارسال به سایت").length);
console.log("slowest supply (>=7d):", slowReal.filter(r => Number(r.lead_days) >= 7).length,
  "| unmet with faults:", unmet.rows.filter(r => r.unit && Number(r.faults) > 0).length);