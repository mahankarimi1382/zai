// ===== Dashboard v3 — fixed SVG rendering (proper RTL/LTR text, no overflow) =====
import fs from "node:fs";
import path from "node:path";

const OUT = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_analysis";
const esc = (s) => String(s).replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");

const readCsv = (f) => {
  const p = path.join(OUT, f);
  if (!fs.existsSync(p)) return [];
  const lines = fs.readFileSync(p, "utf8").replace(/^\uFEFF/, "").split("\n").filter(Boolean);
  const head = []; { let cur = "", q = false; for (const ch of lines[0]) { if (ch === '"') q = !q; else if (ch === "," && !q) { head.push(cur); cur = ""; } else cur += ch; } head.push(cur); }
  return lines.slice(1).map(l => { const o = []; let cur = "", q = false; for (const ch of l) { if (ch === '"') q = !q; else if (ch === "," && !q) { o.push(cur); cur = ""; } else cur += ch; } o.push(cur); return Object.fromEntries(head.map((h, i) => [h, o[i] ?? ""])); });
};
const N = (v) => Number(String(v || 0).replace(/[^\d.-]/g, "")) || 0;

// --- data ---
const units = readCsv("20_unit_full_stats.csv");
const cons = readCsv("21_consumables_full.csv");
const batSites = readCsv("22_battery_full_stats.csv").length ? readCsv("22_battery_full_stats.csv") : readCsv("22_battery_full_stats_new.csv");
const batModels = readCsv("23_battery_models_full.csv");
const batMonthly = readCsv("24_battery_monthly.csv");
const coolerSites = readCsv("27_cooler_by_site.csv");
const coolerModels = readCsv("27c_cooler_models.csv");
const chatStats = readCsv("15_chat_stats.csv");

console.log("loaded:", { units: units.length, cons: cons.length, batSites: batSites.length, batModels: batModels.length, batMonthly: batMonthly.length, coolerSites: coolerSites.length, coolerModels: coolerModels.length, chatStats: chatStats.length });

// --- helpers: horizontal bar chart, LTR labels on the left, bar grows to the right ---
function hbar(title, items, color, opts = {}) {
  const { labelW = 130, valW = 60, barH = 20, gap = 5, maxW = 470 } = opts;
  const W = labelW + maxW + valW + 20;
  const H = items.length * (barH + gap) + 44;
  const max = Math.max(...items.map(i => i[1]), 1);
  let s = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" direction="ltr">`;
  s += `<text x="${W - 10}" y="22" font-size="14" font-weight="bold" fill="#222" text-anchor="start" direction="rtl" style="font-family:Tahoma">${esc(title)}</text>`;
  items.forEach(([label, val], i) => {
    const y = 34 + i * (barH + gap);
    const w = Math.max(3, Math.round((val / max) * maxW));
    // label: anchored at right edge of label zone, LTR direction so codes render correctly
    s += `<text x="${labelW - 6}" y="${y + 14}" font-size="12" fill="#333" text-anchor="end" direction="ltr" style="font-family:Consolas,Tahoma">${esc(label)}</text>`;
    s += `<rect x="${labelW}" y="${y + 2}" width="${w}" height="${barH - 4}" fill="${color}" rx="3"/>`;
    s += `<text x="${labelW + w + 5}" y="${y + 14}" font-size="12" fill="#555" text-anchor="start" direction="ltr" style="font-family:Tahoma">${val}</text>`;
  });
  return s + `</svg>`;
}

// --- monthly line chart with correct month labels ---
function lineChart(title, points, color) {
  const W = 1060, H = 280, PL = 55, PR = 20, PT = 36, PB = 60;
  const max = Math.max(...points.map(p => p[1]), 1);
  const iw = W - PL - PR, ih = H - PT - PB;
  const xOf = (i) => PL + (points.length <= 1 ? iw / 2 : (i * iw) / (points.length - 1));
  const yOf = (v) => PT + ih * (1 - v / max);
  let s = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" direction="ltr">`;
  s += `<text x="${W - 10}" y="20" font-size="14" font-weight="bold" fill="#222" text-anchor="end" direction="rtl" style="font-family:Tahoma">${esc(title)}</text>`;
  for (let g = 0; g <= 4; g++) {
    const v = Math.round((max * g) / 4), y = yOf(v);
    s += `<line x1="${PL}" y1="${y}" x2="${W - PR}" y2="${y}" stroke="#e8e8e8"/>`;
    s += `<text x="${PL - 6}" y="${y + 4}" font-size="11" fill="#888" text-anchor="end">${v}</text>`;
  }
  const step = Math.max(1, Math.ceil(points.length / 14));
  points.forEach((p, i) => {
    if (i % step) return;
    const x = xOf(i), y = H - PB + 16;
    s += `<text x="${x}" y="${y}" font-size="10" fill="#666" text-anchor="end" transform="rotate(-40 ${x} ${y})" direction="ltr">${esc(p[0])}</text>`;
  });
  const pts = points.map((p, i) => `${xOf(i).toFixed(1)},${yOf(p[1]).toFixed(1)}`).join(" ");
  s += `<polyline points="${pts}" fill="none" stroke="${color}" stroke-width="2"/>`;
  points.forEach((p, i) => { s += `<circle cx="${xOf(i)}" cy="${yOf(p[1])}" r="2.5" fill="${color}"/>`; });
  return s + `</svg>`;
}

// --- donut for status distribution ---
function donut(title, items, colors) {
  const total = items.reduce((s, i) => s + i[1], 0) || 1;
  const W = 360, H = 260, cx = 130, cy = 130, R = 90, r = 55;
  let s = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" viewBox="0 0 ${W} ${H}" direction="ltr">`;
  s += `<text x="${W - 10}" y="20" font-size="14" font-weight="bold" fill="#222" text-anchor="end" direction="rtl" style="font-family:Tahoma">${esc(title)}</text>`;
  let a0 = -Math.PI / 2;
  items.forEach(([label, val], i) => {
    const frac = val / total, a1 = a0 + frac * Math.PI * 2;
    const large = frac > 0.5 ? 1 : 0;
    const x0 = cx + R * Math.cos(a0), y0 = cy + R * Math.sin(a0);
    const x1 = cx + R * Math.cos(a1), y1 = cy + R * Math.sin(a1);
    const x0i = cx + r * Math.cos(a0), y0i = cy + r * Math.sin(a0);
    const x1i = cx + r * Math.cos(a1), y1i = cy + r * Math.sin(a1);
    s += `<path d="M ${x0.toFixed(1)} ${y0.toFixed(1)} A ${R} ${R} 0 ${large} 1 ${x1.toFixed(1)} ${y1.toFixed(1)} L ${x1i.toFixed(1)} ${y1i.toFixed(1)} A ${r} ${r} 0 ${large} 0 ${x0i.toFixed(1)} ${y0i.toFixed(1)} Z" fill="${colors[i % colors.length]}"/>`;
    a0 = a1;
  });
  const legendX = 250;
  items.forEach(([label, val], i) => {
    const y = 50 + i * 22;
    s += `<rect x="${legendX}" y="${y - 10}" width="12" height="12" fill="${colors[i % colors.length]}" rx="2"/>`;
    s += `<text x="${legendX - 8}" y="${y}" font-size="12" fill="#333" text-anchor="end" direction="rtl" style="font-family:Tahoma">${esc(label)}</text>`;
    s += `<text x="${legendX + 18}" y="${y}" font-size="12" fill="#555" text-anchor="start" direction="ltr">${val}</text>`;
  });
  return s + `</svg>`;
}

const colors = ["#e2574c","#d35400","#f0ad4e","#5bc0de","#4a90d9","#8e6bbf","#27ae60","#7f8c8d","#c0392b","#16a085"];

// --- KPI ---
const totalFaults = units.reduce((s, a) => s + N(a.faults), 0);
const totalUnmet = units.reduce((s, a) => s + N(a.unmet), 0);
const totalOpen30 = units.reduce((s, a) => s + N(a.open_needs_30d), 0);
const totalSupplied = units.reduce((s, a) => s + N(a.supplied), 0);
const batFaulty = batSites.filter(r => r.status === "خراب").length;
const batMissing = batSites.filter(r => r.status === "فاقد").length;
const batNeeds = batSites.filter(r => r.status === "نیاز").length;
const batHealthy = batSites.filter(r => r.status === "سالم").length;
const coolFaulty = coolerSites.filter(r => r.status === "خراب" || r.status === "فن خراب").length;
const coolTemp = coolerSites.filter(r => r.status === "دمای بالا").length;
const coolReturned = coolerSites.filter(r => /انبار/.test(r.status)).length;
const coolChanged = coolerSites.filter(r => /تعویض|نصب/.test(r.status)).length;
const totalMsgs = chatStats.reduce((s, r) => s + N(r.total_messages), 0);

// --- charts data ---
const nonCons = units.filter(u => u.category === "تجهیز").sort((a, b) => N(b.faults) - N(a.faults));
const consSorted = (cons.length ? cons : units.filter(u => u.category === "مصرفی")).sort((a, b) => N(b.faults) - N(a.faults));
const unmetTop = [...units].sort((a, b) => N(b.unmet) - N(a.unmet));
const openTop = [...units].sort((a, b) => N(b.open_needs_30d) - N(a.open_needs_30d));
const leadTop = units.filter(u => N(u.avg_lead_days) >= 3).sort((a, b) => N(b.avg_lead_days) - N(a.avg_lead_days));
const coolFaultyTop = coolerSites.filter(r => r.status === "خراب" || r.status === "فن خراب").sort((a, b) => N(b.fault_count) - N(a.fault_count));
const coolTempTop = coolerSites.filter(r => r.status === "دمای بالا").sort((a, b) => N(b.temp_alarm_count) - N(a.temp_alarm_count));
const batFaultyTop = batSites.filter(r => N(r.faulty) > 0).sort((a, b) => N(b.faulty) - N(a.faulty));
const batMissingTop = batSites.filter(r => N(r.missing) > 0).sort((a, b) => N(b.missing) - N(a.missing));
const batStatusDist = [["خراب", batFaulty], ["فاقد باطری", batMissing], ["سالم", batHealthy], ["مشکل برق", batSites.filter(r => r.status === "مشکل برق").length], ["سایر", batSites.filter(r => !["خراب","فاقد","سالم","نیاز","مشکل برق"].includes(r.status)).length]];
const coolStatusDist = [["خراب", coolFaulty], ["دمای بالا", coolTemp], ["برگشتی به انبار", coolReturned], ["تعویض/نصب", coolChanged], ["سایر", coolerSites.length - coolFaulty - coolTemp - coolReturned - coolChanged]];

const uMonthly = (() => {
  const rows = readCsv("25_unit_monthly_by_family.csv");
  const byM = new Map();
  for (const r of rows) byM.set(r.month, (byM.get(r.month) || 0) + N(r.faults));
  return [...byM.entries()].sort((a, b) => a[0].localeCompare(b[0]));
})();
const bMonthly = batMonthly.map(r => [r.month, N(r.total)]);

// --- HTML ---
let h = `<!doctype html><html lang="fa" dir="rtl"><head><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">
<title>داشبورد آماری — یونیت، باطری، کولر</title>
<style>
 body{font-family:Tahoma,'Segoe UI',sans-serif;margin:0;background:#f0f2f5;color:#222}
 .wrap{max-width:1240px;margin:0 auto;padding:18px}
 h1{font-size:22px;margin:6px 0 2px}
 .sub{color:#777;font-size:13px;margin-bottom:16px}
 .kpis{display:grid;grid-template-columns:repeat(auto-fit,minmax(130px,1fr));gap:10px;margin-bottom:18px}
 .kpi{background:#fff;border:1px solid #e3e6ea;border-radius:10px;padding:12px 10px;text-align:center;box-shadow:0 1px 2px rgba(0,0,0,.04)}
 .kpi b{display:block;font-size:24px;color:#2c6fb5}
 .kpi span{font-size:12px;color:#666}
 section{background:#fff;border:1px solid #e3e6ea;border-radius:12px;padding:16px;margin-bottom:16px;box-shadow:0 1px 2px rgba(0,0,0,.04)}
 section h2{font-size:16px;margin:0 0 12px;padding-bottom:8px;border-bottom:2px solid #2c6fb5;color:#1d4e80}
 .grid{display:grid;grid-template-columns:1fr 1fr;gap:16px}
 .grid3{display:grid;grid-template-columns:1fr 1fr 1fr;gap:16px}
 @media(max-width:900px){.grid,.grid3{grid-template-columns:1fr}}
 .note{font-size:12px;color:#888;margin-top:8px}
 svg{max-width:100%;height:auto}
 table{width:100%;border-collapse:collapse;font-size:13px}
 th,td{padding:7px 9px;border-bottom:1px solid #eef1f4;text-align:right}
 th{background:#f7f9fb;color:#1d4e80;font-weight:600}
 tr:hover td{background:#fafcff}
 td.num{text-align:left;direction:ltr;font-variant-numeric:tabular-nums}
 .badge{display:inline-block;padding:2px 8px;border-radius:10px;font-size:11px;color:#fff}
 .b-red{background:#e2574c}.b-org{background:#e67e22}.b-grn{background:#27ae60}.b-gry{background:#95a5a6}.b-blu{background:#4a90d9}
</style></head><body><div class="wrap">`;

h += `<h1>داشبورد آماری — یونیت‌ها، قطعات مصرفی، باطری و کولر سایت‌ها</h1>
<div class="sub">منبع: ${totalMsgs.toLocaleString("fa")} پیام از چت‌های عملیاتی بله (ژانویه ۲۰۲۳ تا اکتبر ۲۰۲۶) | تاریخ تهیه: ${new Date().toISOString().slice(0, 10)}</div>`;

h += `<div class="kpis">
<div class="kpi"><b>${totalFaults.toLocaleString("fa")}</b><span>کل خرابی یونیت</span></div>
<div class="kpi"><b>${totalSupplied.toLocaleString("fa")}</b><span>تأمین‌شده</span></div>
<div class="kpi"><b>${totalUnmet.toLocaleString("fa")}</b><span>تأمین‌نشده</span></div>
<div class="kpi"><b>${totalOpen30.toLocaleString("fa")}</b><span>نیاز فعال (۳۰ روز)</span></div>
<div class="kpi"><b>${batFaulty}</b><span>سایت باطری خراب</span></div>
<div class="kpi"><b>${batMissing}</b><span>سایت فاقد باطری</span></div>
<div class="kpi"><b>${coolFaulty}</b><span>سایت کولر خراب</span></div>
<div class="kpi"><b>${coolTemp}</b><span>سایت دمای بالا</span></div>
<div class="kpi"><b>${coolReturned}</b><span>کولر برگشتی به انبار</span></div>
</div>`;

// Section 1: units
h += `<section><h2>۱) یونیت‌ها — خرابی و تأمین</h2><div class="grid">`;
h += `<div>${hbar("پرخرابی‌ترین یونیت‌ها (تجهیزات)", nonCons.slice(0, 15).map(u => [u.unit, N(u.faults)]), "#e2574c")}</div>`;
h += `<div>${hbar("تأمین‌نشده‌ترین یونیت‌ها", unmetTop.slice(0, 15).map(u => [u.unit, N(u.unmet)]), "#c0392b")}</div>`;
h += `<div>${hbar("نیاز فعال ۳۰ روز اخیر", openTop.slice(0, 15).map(u => [u.unit, N(u.open_needs_30d)]), "#f0ad4e")}</div>`;
h += `<div>${hbar("کندترین تأمین (میانگین روز)", leadTop.slice(0, 15).map(u => [u.unit, Math.round(N(u.avg_lead_days))]), "#5bc0de")}</div>`;
h += `</div></section>`;

// Section 2: consumables
h += `<section><h2>۲) قطعات مصرفی</h2><div class="grid">`;
h += `<div>${hbar("خرابی قطعات مصرفی", consSorted.slice(0, 10).map(u => [u.part || u.unit, N(u.faults)]), "#8e6bbf")}</div>`;
h += `<div>${hbar("تأمین‌نشده قطعات مصرفی", [...consSorted].sort((a, b) => N(b.unmet) - N(a.unmet)).slice(0, 10).map(u => [u.part || u.unit, N(u.unmet)]), "#6c3483")}</div>`;
h += `</div></section>`;

// Section 3: battery
h += `<section><h2>۳) باطری سایت‌ها</h2><div class="grid3">`;
h += `<div>${donut("توزیع وضعیت باطری سایت‌ها", batStatusDist, ["#e2574c","#c0392b","#27ae60","#f0ad4e","#95a5a6"])}</div>`;
h += `<div>${hbar("بیشترین خرابی باطری (سایت)", batFaultyTop.slice(0, 12).map(r => [r.site, N(r.faulty)]), "#e67e22")}</div>`;
h += `<div>${hbar("سایت‌های فاقد باطری", batMissingTop.slice(0, 12).map(r => [r.site, N(r.missing)]), "#c0392b")}</div>`;
h += `</div><div style="margin-top:14px">${lineChart("روند ماهانه پیام‌های باطری", bMonthly, "#e67e22")}</div>`;
h += `<div class="note">«نیاز به باطری» به‌صورت صریح در چت‌ها تقریباً وجود ندارد (۱ مورد در کل داده) — سایت‌ها معمولاً با آلارم «Battery Missing» یا خرابی باطری گزارش می‌شوند که در ستون‌های خراب/فاقد آمده است.</div>`;
h += `</section>`;

// Section 4: cooler
h += `<section><h2>۴) کولر سایت‌ها (برند نیان)</h2><div class="grid3">`;
h += `<div>${donut("توزیع وضعیت کولر", coolStatusDist, ["#d35400","#c0392b","#7f8c8d","#16a085","#95a5a6"])}</div>`;
h += `<div>${hbar("سایت‌های کولر خراب", coolFaultyTop.slice(0, 12).map(r => [r.site, N(r.fault_count)]), "#d35400")}</div>`;
h += `<div>${hbar("سایت‌های دمای بالا", coolTempTop.slice(0, 12).map(r => [r.site, N(r.temp_alarm_count)]), "#c0392b")}</div>`;
h += `</div><div class="grid" style="margin-top:14px">`;
h += `<div>${hbar("مدل‌های کولر در گردش", coolerModels.slice(0, 8).map(r => [r.cooler_model, N(r.mentions)]), "#16a085")}</div>`;
h += `<div>${hbar("مدل‌های باطری در گردش", batModels.slice(0, 8).map(r => [r.battery_model, N(r.mentions)]), "#27ae60")}</div>`;
h += `</div></section>`;

// Section 5: monthly unit trend
h += `<section><h2>۵) روند ماهانه خرابی یونیت‌ها</h2>${lineChart("", uMonthly, "#e2574c")}</section>`;

// Section 6: top tables
h += `<section><h2>۶) جدول خلاصه — ۲۰ یونیت پرخرابی</h2><table><thead><tr>
<th>مدل</th><th>خانواده</th><th>خرابی</th><th>تأمین‌شده</th><th>تأمین‌نشده</th><th>نیاز فعال</th><th>برگشت انبار</th><th>میانگین تأمین (روز)</th><th>سایت</th>
</tr></thead><tbody>`;
for (const u of nonCons.slice(0, 20)) {
  h += `<tr><td><b>${esc(u.unit)}</b></td><td>${esc(u.family)}</td><td class="num">${u.faults}</td><td class="num">${u.supplied}</td><td class="num">${u.unmet}</td><td class="num">${u.open_needs_30d}</td><td class="num">${u.returns}</td><td class="num">${u.avg_lead_days || "-"}</td><td class="num">${u.sites_count}</td></tr>`;
}
h += `</tbody></table></section>`;

h += `<section><h2>۷) جدول خلاصه — سایت‌های بحرانی (باطری + کولر)</h2><table><thead><tr>
<th>سایت</th><th>وضعیت باطری</th><th>خرابی باطری</th><th>فاقد باطری</th><th>وضعیت کولر</th><th>خرابی کولر</th><th>آلارم دما</th>
</tr></thead><tbody>`;
const crit = new Map();
for (const b of batFaultyTop.slice(0, 15)) crit.set(b.site, { site: b.site, bs: b.status, bf: N(b.faulty), bm: N(b.missing), cs: "", cf: 0, ct: 0 });
for (const c of coolFaultyTop.slice(0, 15)) { if (!crit.has(c.site)) crit.set(c.site, { site: c.site, bs: "", bf: 0, bm: 0, cs: "", cf: 0, ct: 0 }); }
for (const c of coolTempTop.slice(0, 10)) { if (!crit.has(c.site)) crit.set(c.site, { site: c.site, bs: "", bf: 0, bm: 0, cs: "", cf: 0, ct: 0 }); }
for (const [s, r] of crit) {
  const c = coolerSites.find(x => x.site === s);
  const b = batSites.find(x => x.site === s);
  const bs = b ? b.status : ""; const cs = c ? c.status : "";
  h += `<tr><td><b>${esc(s)}</b></td><td>${bs ? `<span class="badge ${bs === "خراب" ? "b-red" : bs === "فاقد" ? "b-org" : "b-gry"}">${esc(bs)}</span>` : "-"}</td><td class="num">${b ? b.faulty : "-"}</td><td class="num">${b ? b.missing : "-"}</td><td>${cs ? `<span class="badge ${cs === "خراب" ? "b-red" : cs === "دمای بالا" ? "b-org" : "b-gry"}">${esc(cs)}</span>` : "-"}</td><td class="num">${c ? c.fault_count : "-"}</td><td class="num">${c ? c.temp_alarm_count : "-"}</td></tr>`;
}
h += `</tbody></table></section>`;

h += `<div class="note">فایل‌های CSV متناظر در همین پوشه: 20_unit_full_stats · 21_consumables_full · 22_battery_full_stats · 23_battery_models_full · 24_battery_monthly · 25_unit_monthly_by_family · 27_cooler_by_site · 27b_cooler_events · 27c_cooler_models · 27d_cooler_stats</div>`;
h += `</div></body></html>`;

fs.writeFileSync(path.join(OUT, "26_dashboard_v3.html"), h, "utf8");
console.log("wrote 26_dashboard_v3.html", h.length, "bytes");