import fs from "node:fs";
import path from "node:path";
const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const files = fs.readdirSync(MERGED).filter(f => f.endsWith(".json"));
const FA = String.fromCharCode(0x06F0);
const norm = s => s.replace(/[۰-۹]/g, d => String(d.charCodeAt(0) - FA)).replace(/[٠-٩]/g, d => String(d.charCodeAt(0) - 0x0660)).replace(/[يى]/g, "ی").replace(/ك/g, "ک").replace(/‌/g, "").replace(/[ \t]+/g, " ");
const SITE = /\b([A-Za-z]{1,3})-?\s?(\d{4})\b/g;
const PREFIX = new Set(["t","e","n","b","h","d","dt","th","dl","lu","l","k","m","p","c","s","r","f","g","w","a","j","x","v","y","z","q","i","o","u"]);
const buckets = { noBattery: [], fault: [], test: [], healthy: [], install: [], outage: [] };
const RE = {
  noBattery: /(?:فاقد\s*(?:ب(?:ا|أ)?طری|باتری))|(?:(?:ب(?:ا|أ)?طری|باتری)[^.\n]{0,10}?(?:ندارد|ندار|نیست|نیستن|موجود\s*نیست|نبود))/,
  fault: /(?:ب(?:ا|أ)?طری|باتری|batt)[^.\n]{0,30}?(?:خراب|معیوب|فالت|فاسد|سوخته|خسته|بیس|frسود|فرسود|فولت\s*ندار|disconnect)/i,
  test: /(?:تست|آزمایش)[^.\n]{0,12}?(?:ب(?:ا|أ)?طری|باتری)|(?:ب(?:ا|أ)?طری|باتری)[^.\n]{0,12}?تست/i,
  healthy: /(?:ب(?:ا|أ)?طری|باتری|batt)[^.\n]{0,30}?(?:سالم|درست|روشن|نرمال|بدون\s*شارژر\s*کامل)/i,
  install: /(?:نصب|تعویض)\s*(?:ب(?:ا|أ)?طری|باتری)|(?:ب(?:ا|أ)?طری|باتری)\s*نصب/i,
  outage: /(?:قطعی\s*برق|برق\s*(?:رفت|رفته|قطع)|قطع\s*برق|روی\s*ب(?:ا|أ)?طری|رو\s*ب(?:ا|أ)?طری|خاموشی\s*سایت)/,
};
for (const f of files) {
  const name = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"));
  for (const m of msgs) {
    const x = norm(m.x || "").replace(/\s+/g, " ").trim();
    if (!x || x === "[object Object]") continue;
    const sites = new Set();
    SITE.lastIndex = 0;
    for (const m2 of x.matchAll(SITE)) if (PREFIX.has(m2[1].toLowerCase()) && m2[2] !== "1400") sites.add(m2[1].toUpperCase() + m2[2]);
    if (!sites.size) continue;
    for (const [k, re] of Object.entries(RE)) {
      if (re.test(x) && buckets[k].length < 400)
        buckets[k].push({ site: [...sites][0], all: [...sites].join("|"), d: new Date(m.d + 3.5 * 3600000).toISOString().slice(0, 10), chat: name, x: x.slice(0, 150) });
    }
  }
}
for (const k of Object.keys(buckets)) {
  const uniq = new Set(buckets[k].map(b => b.site));
  console.log(`\n=== ${k}: ${buckets[k].length} rows, ${uniq.size} unique sites ===`);
  console.log([...uniq].slice(0, 30).join(", "));
}
fs.writeFileSync("batt_sites.json", JSON.stringify(buckets, null, 1));