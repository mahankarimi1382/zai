import fs from "node:fs";
import path from "node:path";
const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const FA = String.fromCharCode(0x06F0);
const norm = s => s.replace(/[۰-۹]/g, d => String(d.charCodeAt(0) - FA)).replace(/[٠-٩]/g, d => String(d.charCodeAt(0) - 0x0660)).replace(/[يى]/g, "ی").replace(/ك/g, "ک").replace(/‌/g, "").replace(/[ \t]+/g, " ");
const f = fs.readdirSync(MERGED).find(x => x.startsWith("785878952_"));
const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"));
const lead = /^\s*([A-Za-z]{0,2})(\d{3,4})\b/;
let hit = 0, withSite = 0;
const list = [];
for (const m of msgs) {
  const x = norm(m.x || "").replace(/\s+/g, " ").trim();
  if (!x || x === "[object Object]") continue;
  const nb = /(?:فاقد\s*(?:ب(?:ا|أ)?طری|باتری))|(?:(?:ب(?:ا|أ)?طری|باتری)[^.\n]{0,10}?(?:ندارد|ندار|نیست|موجود\s*نیست|نبود))/.test(x);
  if (!nb) continue;
  hit++;
  const mm = x.match(lead);
  if (mm) { withSite++; list.push(mm[1].toUpperCase() + mm[2] + " | " + x.slice(0, 110)); }
}
console.log("no-battery lines:", hit, "| with leading site code:", withSite);
console.log(list.slice(0, 25).join("\n"));