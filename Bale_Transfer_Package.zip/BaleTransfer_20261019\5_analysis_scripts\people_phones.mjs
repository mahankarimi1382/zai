// Extract (name, phone) pairs from Bale messages.
// Bale's structured message headers look like: "... 11-Jul-26 Mehrdad Nafar 9392799934 Site Audit ..."
// i.e. a person's display name immediately followed by their mobile number.
import fs from "node:fs";
import path from "node:path";

const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const OUTDIR = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_analysis";

const WAREHOUSE_CHATS = new Set(["1737503770","517632817","785878952","1729376405","1918042926","2061599862","1048230922","786128402","8339623"]);

// name tokens: latin words or Persian words, 1..4 words, then a mobile number
const NAME_LATIN = "[A-Za-z][A-Za-z._-]*(?:\\s+[A-Za-z][A-Za-z._-]*){0,3}";
const NAME_FA = "[\\u0600-\\u06FF][\\u0600-\\u06FF\\s.-]{1,28}";
const PHONE = "(?:\\+?98|0098|0)?9\\d{9}";
const reLatin = new RegExp(`(${NAME_LATIN})\\s*[:،,\\-]?\\s*(${PHONE})`, "g");
const reFa = new RegExp(`(${NAME_FA})\\s*[:،,\\-]?\\s*(${PHONE})`, "g");

const fmt = (m) => { let d = m.replace(/\D/g, ""); if (d.startsWith("0098")) d = d.slice(4); else if (d.startsWith("98")) d = d.slice(2); else if (d.startsWith("0")) d = d.slice(1); return "0" + d; };
const cleanName = (s) => String(s).replace(/\s+/g, " ").replace(/[،,\-–—:;]/g, " ").trim().replace(/\b\d{1,4}[-–]\d{2,4}\b/g, "").trim();

const byPhone = new Map();   // phone -> {phone, names:Set, chats:Set, wh:Set, hits}
const files = fs.readdirSync(MERGED).filter(f => f.endsWith(".json"));

// take only the token(s) immediately preceding the number (max 4 words, last one is the person)
const pickName = (m, raw, phoneRaw) => {
  const idx = raw.indexOf(phoneRaw);
  if (idx < 0) return m[1];
  const before = raw.slice(Math.max(0, idx - 60), idx);
  const cleaned = before.replace(/[,\-–—:;|/\\()\[\]{}]/g, " ").replace(/\s+/g, " ").trim();
  const words = cleaned.split(" ").filter(Boolean);
  if (!words.length) return m[1];
  // the last word must be part of a name (letters); take up to 3 words back
  let take = [];
  for (let k = words.length - 1; k >= 0 && take.length < 3; k--) {
    const w = words[k];
    if (!/^[A-Za-z\u0600-\u06FF][A-Za-z\u0600-\u06FF._'-]*$/.test(w)) break;
    if (/^(Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec|Sun|Mon|Tue|Wed|Thu|Fri|Sat|NWG|OPS|MBTS|Ticket|Site|Zone|R7|Code|Visit|Clean|Expansion|Shift|Team|Date|Time|Priority|Region|Comment)$/i.test(w)) break;
    take.unshift(w);
  }
  return take.join(" ") || m[1];
};

for (const f of files) {
  const id = f.split("_")[0];
  const chat = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  const isWh = WAREHOUSE_CHATS.has(id);
  for (const m of JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"))) {
    const raw = m.x;
    if (!raw || raw === "[object Object]" || raw.length > 600) continue;
    reLatin.lastIndex = 0;
    let mm;
    while ((mm = reLatin.exec(raw))) {
      const name = cleanName(pickName(mm, raw, mm[2]));
      if (!name || name.length < 3) continue;
      if (/^(NWG|OPS|TT|CR|MBTS|Site|Zone|R7|Code|Priority|Fiber|Power|Battery|Cooler|ESM|RRU|SFP|PSU|NCR|Ticket|Shift|Team|Region)\b/i.test(name)) continue;
      const p = fmt(mm[2]);
      if (!/^09\d{9}$/.test(p)) continue;
      if (!byPhone.has(p)) byPhone.set(p, { phone: p, names: new Set(), chats: new Set(), wh: new Set(), hits: 0 });
      const e = byPhone.get(p);
      e.names.add(name); e.chats.add(chat); if (isWh) e.wh.add(chat); e.hits++;
    }
    reFa.lastIndex = 0;
    while ((mm = reFa.exec(raw))) {
      const name = cleanName(pickName(mm, raw, mm[2]));
      if (!name || name.length < 3) continue;
      if (/^(سایت|کد|تاریخ|شیفت|تیم|منطقه|گروه|بازه|دوره|پروژه|کار|نفر|ساعت|بازدید|پاکسازی|توسعه|برچسب)\b/.test(name)) continue;
      const p = fmt(mm[2]);
      if (!/^09\d{9}$/.test(p)) continue;
      if (!byPhone.has(p)) byPhone.set(p, { phone: p, names: new Set(), chats: new Set(), wh: new Set(), hits: 0 });
      const e = byPhone.get(p);
      e.names.add(name); e.chats.add(chat); if (isWh) e.wh.add(chat); e.hits++;
    }
  }
}

const all = [...byPhone.values()]
  .map(e => ({ phone: e.phone, names: [...e.names], chats: [...e.chats], warehouseChats: [...e.wh], hits: e.hits }))
  .sort((a, b) => b.warehouseChats.length - a.warehouseChats.length || b.hits - a.hits);

console.log("total phones with a name:", all.length);
console.log("\n=== PHONES APPEARING IN WAREHOUSE GROUPS ===");
const wh = all.filter(e => e.warehouseChats.length > 0);
for (const e of wh.slice(0, 60)) {
  console.log(`${e.phone} | ${e.names.slice(0, 3).join(" / ")} | chats: ${e.warehouseChats.join(", ")} | hits=${e.hits}`);
}
console.log("\n=== ALL CONTACTS (top 40 by hits) ===");
for (const e of all.slice(0, 40)) {
  console.log(`${e.phone} | ${e.names.slice(0, 2).join(" / ")} | hits=${e.hits} | chats=${e.chats.length}`);
}

fs.writeFileSync(path.join(OUTDIR, "30_people_phones.csv"),
  "\uFEFF" + ["phone","names","warehouse_chats","all_chats","hits"].map(x => `"${x}"`).join(",") + "\n" +
  all.map(e => [e.phone, e.names.join(" | "), e.warehouseChats.join(" | "), e.chats.join(" | "), e.hits]
    .map(v => `"${String(v).replace(/"/g, "'")}"`).join(",")).join("\n") + "\n", "utf8");
console.log("\nwrote 30_people_phones.csv");