// Final warehouse-contact report: group people by their warehouse role (key/lock delivery,
// material handover, return) and attach the phone numbers found in message headers.
import fs from "node:fs";
import path from "node:path";

const OUTDIR = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_analysis";
const MERGED = path.join(OUTDIR, "..", "bale_report", "merged");
const OLD    = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_data";

const users = new Map();
const uf = path.join(OLD, "_users.json");
if (fs.existsSync(uf)) for (const u of JSON.parse(fs.readFileSync(uf, "utf8"))) users.set(String(u.id), u.name || "");

// ---- 1. phone -> clean name (best name = the one appearing most) ----
const phoneRaw = fs.readFileSync(path.join(OUTDIR, "30_people_phones.csv"), "utf8").replace(/^\uFEFF/, "");
const lines = phoneRaw.split("\n").filter(Boolean);
const head = lines[0].split(",").map(s => s.replace(/"/g, ""));
const rows = lines.slice(1).map(l => {
  const o = []; let c = "", q = false;
  for (const ch of l) { if (ch === '"') q = !q; else if (ch === "," && !q) { o.push(c); c = ""; } else c += ch; }
  o.push(c);
  return Object.fromEntries(head.map((h, i) => [h, o[i] || ""]));
});
const bestName = (namesStr) => {
  const arr = namesStr.split("|").map(s => s.trim()).filter(Boolean);
  if (!arr.length) return "";
  const score = (s) => {
    let v = 0;
    if (/Mr\.|MCI|RFA|MW|CPG/.test(s)) v -= 2;
    if (/Survey|Site visit|Clean|Expansion|Azimuth|Dismantling|LOS|Check|Shift/i.test(s)) v -= 3;
    if (s.length >= 8 && s.length <= 26) v += 2;
    if (/^[A-Za-z]+\s+[A-Za-z]+$/.test(s)) v += 2;
    if (/[\u0600-\u06FF]/.test(s)) v += 2;
    return v;
  };
  return arr.map(s => [s, score(s)]).sort((a, b) => b[1] - a[1])[0][0];
};
const phoneToName = new Map();
for (const r of rows) {
  const n = bestName(r.names);
  if (n) phoneToName.set(r.phone.replace(/"/g, ""), n);
}

// ---- 2. role per person from their own messages in warehouse groups ----
const WH = new Set(["1737503770","517632817","785878952","1729376405","1918042926","2061599862","1048230922","786128402","8339623"]);
const ROLES = [
  ["تحویل کلید سایت (Key)", /(کلید|key\s?delivery|key\s?request|دسترسی\s?سایت|تحویل\s?کلید|رفت\s?سایت)/i],
  ["انبار قطعات / مرجوعی", /(انبار|مرجوع|برگشت|تحویل\s?انبار|عودت|return\s?material)/i],
  ["ارسال / اسنپ / حمل", /(ارسال|اسنپ|اپارات|پست|باربری|حمل|مرسوله|pickup)/i],
];
const person = new Map(); // uid/name -> {name, msgs, roles:{}, phones:Set, chats:Set}
const files = fs.readdirSync(MERGED).filter(f => f.endsWith(".json"));
for (const f of files) {
  const id = f.split("_")[0];
  if (!WH.has(id)) continue;
  const chat = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  for (const m of JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"))) {
    const raw = m.x || "";
    if (!raw || raw === "[object Object]") continue;
    const uid = String(m.u);
    const name = users.get(uid) || ("uid_" + uid);
    if (!person.has(uid)) person.set(uid, { uid, name, msgs: 0, roles: {}, phones: new Set(), chats: new Set() });
    const p = person.get(uid);
    p.msgs++; p.chats.add(chat);
    for (const [label, re] of ROLES) if (re.test(raw)) p.roles[label] = (p.roles[label] || 0) + 1;
    // attach any phone in this message to this sender (they wrote their own number)
    const ph = (raw.match(/(?:0|98|\+98)?9\d{9}/g) || []).map(s => { let d = s.replace(/\D/g, ""); if (d.startsWith("98")) d = d.slice(2); else if (d.startsWith("0")) d = d.slice(1); return "0" + d; }).filter(x => /^09\d{9}$/.test(x));
    for (const x of ph) p.phones.add(x);
  }
}

// also link names <-> phones discovered globally (message headers)
const nameToPhone = new Map();
for (const [ph, nm] of phoneToName) nameToPhone.set(nm.toLowerCase().replace(/\s+/g, " "), ph);

const out = [...person.values()]
  .filter(p => Object.keys(p.roles).length > 0)
  .map(p => {
    const phones = new Set(p.phones);
    const byName = nameToPhone.get(p.name.toLowerCase().replace(/\s+/g, " "));
    if (byName) phones.add(byName);
    return { name: p.name, phones: [...phones], totalRoleHits: Object.values(p.roles).reduce((a, b) => a + b, 0), roles: p.roles, chats: [...p.chats], msgs: p.msgs };
  })
  .sort((a, b) => b.totalRoleHits - a.totalRoleHits);

console.log("=== WAREHOUSE PEOPLE (role-based) ===");
for (const p of out.slice(0, 35)) {
  const roles = Object.entries(p.roles).sort((a, b) => b[1] - a[1]).map(([k, v]) => `${k}:${v}`).join(" | ");
  console.log(`${p.name.padEnd(28)} | ${(p.phones.join(", ") || "(شماره در پیام‌ها نیست)").padEnd(30)} | ${roles}`);
}
console.log("\ntotal people with warehouse role:", out.length);

fs.writeFileSync(path.join(OUTDIR, "31_warehouse_people.csv"),
  "\uFEFF" + ["name","phones","role_hits","roles","chats","messages"].map(x => `"${x}"`).join(",") + "\n" +
  out.map(p => [p.name, p.phones.join(" | "), p.totalRoleHits,
    Object.entries(p.roles).map(([k, v]) => `${k}(${v})`).join(" | "),
    p.chats.join(" | "), p.msgs].map(v => `"${String(v).replace(/"/g, "'")}"`).join(",")).join("\n") + "\n", "utf8");
console.log("wrote 31_warehouse_people.csv");