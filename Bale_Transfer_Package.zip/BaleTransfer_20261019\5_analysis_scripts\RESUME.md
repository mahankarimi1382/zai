# وضعیت پروژه استخراج بله — ادامه کار فردا

## وضعیت فعلی (تاریخ: 2026-10-06)
- **استخراج پیام‌ها کامل شد ✅** — ۱۷۸٬۷۹۴ پیام از ۶۳ چت/گروه در `bale_data/*.json` (فرمت: آرایه JSON ردیف‌ها: rid,d,u,t,x,f,out)
- **فیلتر پیام‌های مرتبط انجام شد ✅** — ۴۰٬۵۱۳ پیام یونیت/انبارمحور در `bale_data/filtered/*.jsonl` (هر خط یک JSON: rid,d,u,t,x,chat,chatId,kind,f)
- **نقشه کاربران ✅** — `bale_data/_users.json` (uid → نام، ۱۲۶۰ نفر)
- **ایندکس چت‌ها ✅** — `bale_data/00_chat_index_raw.csv` و `_index.json`
- **تحلیل: شروع نشده** — ۸ ساب‌ایجنت موازی با خطای «user concurrency limit exceeded» رد شدن. فردا: حداکثر ۲-۳ تا هم‌زمان اجرا کن.

## گروه‌های اصلی و تعداد پیام کل/مرتبط
R7_DS_Follow_UP 20034/8405 | Zone_C 15011/2995 | Zone_Z 15007/2602 | Zone_D 15016/2533 | Zone_B 15006/2199 | R7_DG_Dispatching 5997/1809 | R7_Return_Material 4702/803 (مرجوعی!) | Zone_A 4057/853 | Zone_E 4710/950 | Varamin_S2 5827/1682 | eslamshahr 8034/1709 | FO-HD_Alignment 8028/3770 | KEY Delivery ها (A 6885, E 6471, C 4036, Z 3189, D 2776, B 2371, key_delivery 2182, RFA 2224) | بقیه + ۲۹ چت شخصی

## دستور کار فردا
0. **استخراج عمیق (درخواست جدید کاربر 2026-10-06 شب):** کاربر تاریخچه چند سال اخیر را می‌خواهد، نه فقط ۹۰ روز. پس قبل از تحلیل، استخراج را با عمق کامل تکرار کن:
   - همان صف اولویت‌دار + همه گروه‌ها با `stopDate = 1` (بدون حد) و `cap` بزرگ (مثلاً 300000) و `limit: 200`
   - چت‌های شخصی هم عمیق (cap 10000)
   - نرخ مشاهده‌شده ~۷۰۰ پیام/ثانیه → حتی ۱ میلیون پیام ≈ ۳۰ دقیقه
   - خروجی در `bale_data_deep/<id>_<name>.json` و در تحلیل با داده‌های قبلی ادغام شود (dedupe روی rid؛ داده ۹۰ روزه زیرمجموعه است)
   - بعد از استخراج عمیق، فیلتر را دوباره اجرا کن (`prep_analysis.mjs` روی پوشه deep، خروجی filtered جدید) — حجم relevant احتمالاً ۱۵۰k+ می‌شود؛ تحلیل ساب‌ایجنت را موج‌بندی کن (اولویت: R7_DS، R7_Return_Material، Zoneها؛ بعد بقیه) و برای بخش قدیمی‌تر از تحلیل اسکریپتی (تجمیع کد یونیت‌ها + کلیدواژه) هم استفاده کن
1. ساب‌ایجنت‌های تحلیل (۸ بچه‌کار، ولی فقط ۲-۳ هم‌زمان) روی فایل‌های `bale_data/filtered/*.jsonl`:
   - تقسیم پیشنهادی: part_1=R7_DS | part_2=FO-HD+R7_DG | part_3=Zone_C+Z | part_4=Zone_D+B | part_5=eslamshahr+Varamin+pic_C | part_6=Escalation+Zone_E+RFA+ZONE_E_KEY | part_7=Zone_A+R7_Return_Material+activity_D+key+ZONE_Z_KEY+OWS+TX | part_8=بقیه کوچک‌ها و شخصی‌ها
   - خروجی هرکدام: `analysis/part_N.csv` با ستون‌های `unit;site;area;event;chat;chat_type;date;sender_uid;snippet` (جداکننده «;» بدون header)
   - event ∈ {خرابی، تعویض، نصب_یا_راه‌اندازی، خروج_از_انبار، بازگشت_به_انبار، درخواست_قطعه، وضعیت_سالم، تعمیر، ریاستارت، سایر}
   - + `analysis/part_N_summary.md`
2. ادغام + غنی‌سازی نام فرستنده از `_users.json` + ساخت CSVهای نهایی (UTF-8 با BOM برای اکسل فارسی):
   - `01_chat_index.csv` (گروه/شخصی جدا)
   - `02_unit_events.csv`
   - `03_unit_summary.csv` (یونیت × نوع رویداد)
   - `04_warehouse_flow.csv` (خروج/بازگشت انبار)
   - `05_relevant_messages.csv` (پیام‌های طبقه‌بندی‌شده)
   - `README_گزارش.md` خلاصه یافته‌ها
3. تحویل در پوشه `bale_report/`

## نکات فنی (اگر دوباره استخراج لازم شد)
- سشن بله در پروفایل مرورگر داخلی ZCode ماندگار است: `%APPDATA%\zcode\session\Partitions\zcode-embedded-browser` (کوکی access_token تا 2027؛ بکاپ IDB: `bale_session_iab_backup/`)
- **بکاپ کامل سشن (ساخته‌شده 2026-10-06)**: `bale_session_iab_backup/` شامل full_session_copy (۱۷۷MB)، Cookies_hardlink (سخت‌پیوند زنده به کوکی — فقط وقتی ZCode بسته است خواندنی)، bale_idb، Local State. راهنما: `bale_session_iab_backup/README_بکاپ.md`. بازیابی: `restore_iab_session.ps1` (فقط با ZCode بسته).
- **اولین قدم فردا**: چک کن هنوز لاگین است — tabs.list() → تب web.bale.ai → بررسی href اگر /chat بود OK؛ اگر /login بود → restore_iab_session.ps1 را اجرا کن (ZCode باید بسته باشد؛ یعنی به کاربر بگو اجرا کند و برگردد).
- در صفحه web.bale.ai: هوک Rspack → `window.rspackChunkweb.push([["h"],{},r=>{window.__req=r}])` سپس `window.__req(28184).Db.core.messaging.loadHistory({type:2,id}, BigInt(dateMs), 2, limit)` → Observable؛ subscribe کن. تاریخ = epoch ms به صورت BigInt. پاسخ: آرایه پیام.
- فیلترها/کد: `prep_analysis.mjs` (workspace). بکاپ‌های قدیمی Edge در `Temp/edge_bale_cdp` و `Temp/bale_session_backup` — قابل حذف.
- پاکسازی باقی‌مانده (غیرفوری): حذف کلید رجیستری `HKCU\Software\Policies\Microsoft\Edge\DevToolsRemoteDebuggingAllowed` و Junction `Temp\edge_ud_link`
