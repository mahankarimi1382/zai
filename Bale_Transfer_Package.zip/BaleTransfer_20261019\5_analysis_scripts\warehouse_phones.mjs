// Extract phone numbers tied to warehouse staff from message text
import fs from "node:fs";
import path from "node:path";

const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const OLD    = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_data";

const users = new Map();
const uf = path.join(OLD, "_users.json");
if (fs.existsSync(uf)) for (const u of JSON.parse(fs.readFileSync(uf, "utf8"))) users.set(String(u.id), { name: u.name, phone: u.phone || "" });

const norm = (s) => String(s).toLowerCase().replace(/[\s._\-]/g, "");
const nameToUid = new Map();
for (const [id, v] of users) if (v.name) nameToUid.set(norm(v.name), id);

// Iranian phone patterns (with/without 0098/98/0/9...)
const phoneRe = /(?:\+?98|0098|0)?9\d{9}/g;
const fmt = (m) => {
  let d = m.replace(/\D/g, "");
  if (d.startsWith("0098")) d = d.slice(4);
  else if (d.startsWith("98")) d = d.slice(2);
  else if (d.startsWith("0")) d = d.slice(1);
  return "0" + d;
};

const WAREHOUSE = ["1737503770","517632817","785878952","1729376405","1918042926","2061599862","1048230922","786128402","8339623","1206812704"];
// window: same message or ±2 messages around a warehouse action
const ACTION = /(تحویل\s?(داده|گرفته|شد)|ارسال\s?شد|فرستاد|دریافت|انبار|اسنپ|باربری|حمل|پیک|مرسوله)/i;

const hits = new Map();   // phone -> {phone, names:Set, contexts:[]}
const nameHits = new Map(); // uid -> {name, phones:Set}
const files = fs.readdirSync(MERGED).filter(f => f.endsWith(".json"));

for (const f of files) {
  const id = f.split("_")[0];
  if (!WAREHOUSE.includes(id)) continue;
  const chat = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"))
    .filter(m => m.x && m.x !== "[object Object]");
  for (let i = 0; i < msgs.length; i++) {
    const raw = msgs[i].x.replace(/\s+/g, " ").trim();
    if (!ACTION.test(raw)) continue;
    // context = this message + next 2 + prev 2
    const ctx = [msgs[i - 2], msgs[i - 1], msgs[i], msgs[i + 1], msgs[i + 2]]
      .filter(Boolean).map(m => m.x.replace(/\s+/g, " ").trim()).join(" | ");
    // phones in the action message itself
    let ms;
    phoneRe.lastIndex = 0;
    while ((ms = phoneRe.exec(ctx))) {
      const p = fmt(ms[0]);
      if (!/^09\d{9}$/.test(p)) continue;
      // find a known staff name in the context
      const names = [];
      for (const [nn, uid] of nameToUid) if (nn.length >= 4 && norm(ctx).includes(nn)) names.push(users.get(uid).name);
      // also sender
      const sender = users.get(String(msgs[i].u));
      if (sender?.name) names.push(sender.name);
      if (!names.length) continue;
      if (!hits.has(p)) hits.set(p, { phone: p, names: new Set(), count: 0, chats: new Set(), sample: "" });
      const h = hits.get(p);
      names.forEach(n => h.names.add(n));
      h.count++;
      h.chats.add(chat);
      if (!h.sample) h.sample = ctx.slice(0, 220);
    }
  }
}

console.log("=== PHONES FOUND IN WAREHOUSE CONTEXTS ===");
const sorted = [...hits.values()].sort((a, b) => b.count - a.count);
for (const h of sorted) {
  console.log(`${h.phone} | hits=${h.count} | names: ${[...h.names].join(", ")} | chats: ${[...h.chats].join(", ")}`);
}
console.log("total unique phones:", sorted.length);
fs.writeFileSync("C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_analysis\\28_warehouse_phones.json",
  JSON.stringify(sorted.map(h => ({ phone: h.phone, hits: h.count, names: [...h.names], chats: [...h.chats], sample: h.sample })), null, 1));