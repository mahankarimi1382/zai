// ===== Bale session token extractor & restorer =====
// extract — read access_token cookie from ZCode browser profile, decrypt, save token.json
// restore — inject token.json back into cookie DB (browser must be closed)
import fs from "node:fs";
import path from "node:path";
import crypto from "node:crypto";

const PART = "C:\\Users\\someBody\\AppData\\Roaming\\zcode\\session\\Partitions\\zcode-embedded-browser";
const TOOLS = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_session_tools";
const BAK = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_session_iab_backup";
fs.mkdirSync(TOOLS, { recursive: true });

const mode = process.argv[2] || "extract";
const keyHex = fs.readFileSync(path.join(TOOLS, "key.hex"), "utf8").trim();
const key = Buffer.from(keyHex, "hex");
if (key.length !== 32) throw new Error("bad key length: " + key.length);

const { DatabaseSync } = await import("node:sqlite");

function decryptCookie(encBuf) {
  const prefix = encBuf.subarray(0, 3).toString("ascii");
  if (prefix !== "v10" && prefix !== "v11") return { dpapi: encBuf };
  const nonce = encBuf.subarray(3, 15);
  const payload = encBuf.subarray(15);
  const tag = payload.subarray(payload.length - 16);
  const data = payload.subarray(0, payload.length - 16);
  const decipher = crypto.createDecipheriv("aes-256-gcm", key, nonce);
  decipher.setAuthTag(tag);
  return { plain: Buffer.concat([decipher.update(data), decipher.final()]) };
}
function encryptCookie(value) {
  const nonce = crypto.randomBytes(12);
  const cipher = crypto.createCipheriv("aes-256-gcm", key, nonce);
  const enc = Buffer.concat([cipher.update(Buffer.from(value, "utf8")), cipher.final()]);
  const tag = cipher.getAuthTag();
  return Buffer.concat([Buffer.from("v10"), nonce, enc, tag]);
}

function openReadableCopy(src) {
  const tmp = path.join(TOOLS, "_probe.db");
  fs.copyFileSync(src, tmp);
  const d = new DatabaseSync(tmp, { readOnly: true });
  d.prepare("SELECT COUNT(*) c FROM cookies").get();
  return d;
}

if (mode === "extract") {
  const list = [path.join(BAK, "Cookies_snapshot"), path.join(BAK, "Cookies_hardlink"), path.join(PART, "Network", "Cookies")];
  let db = null, src = null;
  for (const c of list) {
    if (!fs.existsSync(c)) continue;
    try { db = openReadableCopy(c); src = c; break; }
    catch (e) { console.log("skip", c, "->", e.message.slice(0, 70)); }
  }
  if (!db) { console.log("NO-READABLE-COOKIE-DB"); process.exit(2); }
  const rows = db.prepare("SELECT host_key,name,encrypted_value,path,is_secure,is_httponly,expires_utc FROM cookies WHERE host_key LIKE '%bale%'").all();
  console.log("source:", src, "| bale cookies:", rows.length);
  const out = { extractedAt: new Date().toISOString(), source: src, cookies: [] };
  for (const r of rows) {
    const enc = Buffer.from(r.encrypted_value);
    try {
      const d = decryptCookie(enc);
      if (d.plain) {
        const val = d.plain.toString("utf8");
        out.cookies.push({ host: r.host_key, name: r.name, path: r.path, secure: !!r.is_secure, httpOnly: !!r.is_httponly, expiresUtc: String(r.expires_utc), value: val });
        console.log(`DECRYPTED ${r.host_key} ${r.name} (len ${val.length})`);
      } else {
        out.cookies.push({ host: r.host_key, name: r.name, dpapi: enc.toString("base64") });
        console.log(`DPAPI-FORMAT ${r.host_key} ${r.name}`);
      }
    } catch (e) { console.log(`DECRYPT-FAIL ${r.host_key} ${r.name}: ${e.message}`); }
  }
  db.close();
  const outPath = path.join(TOOLS, "token.json");
  fs.writeFileSync(outPath, JSON.stringify(out, null, 1));
  console.log("saved ->", outPath, "| cookies:", out.cookies.length);
} else if (mode === "restore") {
  const tokenFile = path.join(TOOLS, "token.json");
  if (!fs.existsSync(tokenFile)) { console.log("NO-TOKEN-FILE"); process.exit(2); }
  const tok = JSON.parse(fs.readFileSync(tokenFile, "utf8"));
  const dbPath = path.join(PART, "Network", "Cookies");
  const db = new DatabaseSync(dbPath);
  // schema-adaptive: use only columns that actually exist in this DB
  const cols = db.prepare("PRAGMA table_info(cookies)").all().map(r => r.name);
  const nowUtc = (BigInt(Date.now()) + 11644473600000n) * 1000n;
  let n = 0;
  for (const c of tok.cookies) {
    if (!c.value) continue;
    const enc = encryptCookie(c.value);
    const values = {
      creation_utc: nowUtc, host_key: c.host, top_frame_site_key: "", name: c.name, value: "",
      encrypted_value: enc, path: c.path || "/", expires_utc: BigInt(c.expiresUtc) || 13370000000000000n,
      is_secure: c.secure ? 1 : 0, is_httponly: c.httpOnly ? 1 : 0, last_access_utc: nowUtc,
      has_expires: 1, is_persistent: 1, priority: 1, samesite: -1, source_scheme: 1,
      source_port: 443, last_update_utc: nowUtc, source_type: 2, has_cross_site_ancestor: 0,
    };
    const useCols = cols.filter(k => k in values);
    const sql = `INSERT OR REPLACE INTO cookies (${useCols.join(",")}) VALUES (${useCols.map(() => "?").join(",")})`;
    try { db.prepare(sql).run(...useCols.map(k => values[k])); n++; }
    catch (e) { console.log("INSERT-FAIL", c.name, e.message.slice(0, 80)); }
  }
  db.close();
  console.log("RESTORED", n, "cookies into", dbPath);
}