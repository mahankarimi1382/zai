# ============================================================
#  Bale Auto-Relogin — بازگرداندن خودکار سشن بدون شماره/پیام
#  شرط: ZCode کاملاً بسته باشد. سپس اجرا کنید و ZCode را باز کنید.
#  توکن از bale_session_tools\token.json خوانده و به کوکی مرورگر تزریق می‌شود.
# ============================================================
$ErrorActionPreference = "Continue"
$part = "C:\Users\someBody\AppData\Roaming\zcode\session\Partitions\zcode-embedded-browser"
$tools = "C:\Users\someBody\.zcode\workspace\default\bale_session_tools"

# --- 0) ZCode must be closed ---
$running = Get-Process | Where-Object { $_.ProcessName -match '^(zcode|ZCode)$' }
if ($running) {
    Write-Output "ZCode is RUNNING - close it completely first, then re-run."
    exit 1
}

# --- 1) token must exist ---
$tf = "$tools\token.json"
if (-not (Test-Path $tf)) {
    Write-Output "NO TOKEN VAULT. Run extract_token.ps1 (with ZCode closed) while the Bale session is still alive."
    exit 2
}

# --- 2) backup current cookies (just in case) ---
$stamp = Get-Date -Format "yyyyMMdd_HHmm"
try { Copy-Item "$part\Network\Cookies" "$tools\Cookies_before_$stamp" -Force } catch {}

# --- 3) inject token into cookies DB via node tool ---
Push-Location "C:\Users\someBody\.zcode\workspace\default"
node "bale_session_tools\bale_token.mjs" restore
$rc = $LASTEXITCODE
Pop-Location
if ($rc -ne 0) { Write-Output "RESTORE-FAIL rc=$rc"; exit 3 }

Write-Output "DONE - session token restored."
Write-Output "Open ZCode and check web.bale.ai - you should be logged in WITHOUT phone/OTP."
