# ============================================================
#  Restore Bale session from backup into ZCode in-app browser
#  Usage: close ZCode completely, then run this script.
# ============================================================
$ErrorActionPreference = "Continue"
$part = "C:\Users\someBody\AppData\Roaming\zcode\session\Partitions\zcode-embedded-browser"
$bak  = "C:\Users\someBody\.zcode\workspace\default\bale_session_iab_backup"

# --- 1) ZCode must be closed ---
$running = Get-Process | Where-Object { $_.ProcessName -match '^(zcode|ZCode)$' }
if ($running) {
    Write-Output "ZCode is RUNNING. Close it completely first, then re-run this script."
    exit 1
}
Write-Output "ZCode is closed - starting restore..."

# --- 2) restore live cookies from fresh hardlink ---
$cookieSrc = "$bak\Cookies_hardlink"
if (Test-Path $cookieSrc) {
    $sz = (Get-Item $cookieSrc).Length
    if ($sz -gt 0) {
        Copy-Item $cookieSrc "$part\Network\Cookies" -Force
        if (Test-Path "$bak\Cookies-journal_hardlink") { Copy-Item "$bak\Cookies-journal_hardlink" "$part\Network\Cookies-journal" -Force }
        Write-Output "Cookies restored ($sz bytes)"
    } else { Write-Output "WARN: hardlink is empty" }
} else { Write-Output "WARN: no cookies hardlink found" }

# --- 3) restore full partition copy ---
if (Test-Path "$bak\full_session_copy") {
    robocopy "$bak\full_session_copy" $part /E /R:1 /W:1 /NFL /NDL /NJH /NJS | Out-Null
    Write-Output "Full partition restored"
}

# --- 4) restore Bale IndexedDB ---
if (Test-Path "$bak\bale_idb") {
    $dst = "$part\IndexedDB\https_web.bale.ai_0.indexeddb.leveldb"
    if (Test-Path $dst) { Remove-Item $dst -Recurse -Force -ErrorAction SilentlyContinue }
    Copy-Item "$bak\bale_idb" $dst -Recurse -Force
    Write-Output "Bale IndexedDB restored"
}

# --- 5) restore Local State (encryption key) ---
if (Test-Path "$bak\Local State") { Copy-Item "$bak\Local State" "$part\Local State" -Force; Write-Output "Local State restored" }

# --- 6) verify ---
Write-Output ("Cookies: " + $(if (Test-Path "$part\Network\Cookies") { "OK" } else { "MISSING" }))
Write-Output ("Bale IDB: " + $(if (Test-Path "$part\IndexedDB\https_web.bale.ai_0.indexeddb.leveldb") { "OK" } else { "MISSING" }))
Write-Output "Now open ZCode and check web.bale.ai - you should be logged in."
