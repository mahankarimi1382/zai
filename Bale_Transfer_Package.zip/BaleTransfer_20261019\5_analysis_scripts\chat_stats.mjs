// ===== General chat statistics from merged Bale data =====
import fs from "node:fs";
import path from "node:path";

const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const OUT    = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_analysis";
const OLD    = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_data";

const users = new Map();
const uf = path.join(OLD, "_users.json");
if (fs.existsSync(uf)) for (const u of JSON.parse(fs.readFileSync(uf, "utf8"))) users.set(String(u.id), u.name);
const nameOf = (u) => users.get(String(u)) || ("uid_" + u);

const GROUPS = new Set(["8339623","96342159","184347948","226526641","231181343","351194861","517632817","729401255","785878952","786128402","1007219512","1007814392","1048230922","1063843314","1067330875","1195001957","1206812704","1265656539","1314721953","1342929147","1358671243","1365646822","1396994789","1703520267","1729376405","1737503770","1762947819","1813863495","1910422633","1917376212","1918042926","1948954274","1986682312","2011482672","2048354559","2061599862","2085953014","2113853239","2139039927","2141244797","2145164056"]);

const d2 = (ms) => new Date(ms + 3.5 * 3600000).toISOString().slice(0, 10);
const q = (v) => `"${String(v ?? "").replace(/"/g, "'").replace(/[\r\n]+/g, " ")}"`;
const B = "\uFEFF";

const chatRows = [];
const monthAgg = new Map();      // YYYY-MM -> total msgs
const senderAgg = new Map();     // sender -> count (group chats only)
let totalAll = 0, totalText = 0, totalMedia = 0;

for (const f of fs.readdirSync(MERGED).filter(x => x.endsWith(".json"))) {
  const id = f.split("_")[0];
  const name = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  const kind = GROUPS.has(id) ? "گروه" : "شخصی";
  const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"));
  if (!msgs.length) continue;
  const dates = msgs.map(m => m.d).filter(Boolean);
  const byMonth = new Map();
  let text = 0, media = 0;
  for (const m of msgs) {
    const mo = new Date(m.d + 3.5 * 3600000).toISOString().slice(0, 7);
    byMonth.set(mo, (byMonth.get(mo) || 0) + 1);
    monthAgg.set(mo, (monthAgg.get(mo) || 0) + 1);
    if (m.x && m.x !== "[object Object]") text++; else media++;
    if (kind === "گروه") senderAgg.set(m.u, (senderAgg.get(m.u) || 0) + 1);
  }
  const first = new Date(Math.min(...dates) + 3.5 * 3600000).toISOString().slice(0, 10);
  const last = new Date(Math.max(...dates) + 3.5 * 3600000).toISOString().slice(0, 10);
  const months = byMonth.size;
  const avgPerMonth = Math.round(msgs.length / Math.max(1, months));
  const busiest = [...byMonth.entries()].sort((a, b) => b[1] - a[1])[0] || ["", 0];
  chatRows.push({
    chat_id: id, chat_name: name, chat_type: kind,
    total: msgs.length, text_msgs: text, media_msgs: media,
    first_date: first, last_date: last, months_covered: months,
    avg_per_month: avgPerMonth, busiest_month: busiest[0], busiest_month_count: busiest[1],
  });
  totalAll += msgs.length; totalText += text; totalMedia += media;
}
chatRows.sort((a, b) => b.total - a.total);

// 15a) per-chat stats
fs.writeFileSync(path.join(OUT, "15_chat_stats.csv"),
  B + ["chat_name","chat_type","total_messages","text_messages","media_messages","first_date","last_date","months_covered","avg_per_month","busiest_month","busiest_month_count"].map(q).join(",") + "\n" +
  chatRows.map(r => [r.chat_name, r.chat_type, r.total, r.text_msgs, r.media_msgs, r.first_date, r.last_date, r.months_covered, r.avg_per_month, r.busiest_month, r.busiest_month_count].map(q).join(",")).join("\n") + "\n", "utf8");
console.log("wrote 15_chat_stats.csv", chatRows.length);

// 15b) monthly activity
const months = [...monthAgg.entries()].sort((a, b) => a[0].localeCompare(b[0]));
fs.writeFileSync(path.join(OUT, "15b_monthly_activity.csv"),
  B + ["month","total_messages"].map(q).join(",") + "\n" +
  months.map(([m, n]) => [m, n].map(q).join(",")).join("\n") + "\n", "utf8");
console.log("wrote 15b_monthly_activity.csv", months.length);

// 15c) top senders (group chats)
const topSenders = [...senderAgg.entries()].sort((a, b) => b[1] - a[1]).slice(0, 100);
fs.writeFileSync(path.join(OUT, "15c_top_senders.csv"),
  B + ["sender","message_count"].map(q).join(",") + "\n" +
  topSenders.map(([u, n]) => [nameOf(u), n].map(q).join(",")).join("\n") + "\n", "utf8");
console.log("wrote 15c_top_senders.csv", topSenders.length);

// summary
console.log(`\nTOTAL: ${totalAll.toLocaleString()} msgs | text: ${totalText.toLocaleString()} | media: ${totalMedia.toLocaleString()}`);
console.log("chats:", chatRows.length, "| groups:", chatRows.filter(r => r.chat_type === "گروه").length, "| personal:", chatRows.filter(r => r.chat_type === "شخصی").length);
console.log("busiest months:", months.sort((a, b) => b[1] - a[1]).slice(0, 5).map(([m, n]) => `${m}:${n}`).join(" "));
console.log("top senders:", topSenders.slice(0, 5).map(([u, n]) => `${nameOf(u)}(${n})`).join(" "));