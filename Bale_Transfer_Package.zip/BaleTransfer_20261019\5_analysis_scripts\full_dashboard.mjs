// ===== گزارش جامع آماری با نمودار — یونیت‌ها، مصرفی‌ها، باطری‌ها =====
// Input: bale_report/merged/*.json  Output: bale_analysis/20_*.csv + dashboard SVG
import fs from "node:fs";
import path from "node:path";

const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const OUT    = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_analysis";

const PRE = (s) => String(s)
  .replace(/[۰-۹]/g, d => String(d.charCodeAt(0) - 0x06F0))
  .replace(/[٠-٩]/g, d => String(d.charCodeAt(0) - 0x0660))
  .replace(/[يى]/g, "ی").replace(/[كک]/g, "ک").replace(/[أإآ]/g, "ا").replace(/[ۀة]/g, "ه")
  .replace(/[ً-ْ]/g, "").replace(/[-‏‎]/g, " ")
  .replace(/\s+/g, " ").toLowerCase().trim();

const UNIT_WORDS = ["ncr","cr","psu","vpsu","upsu","pbc","fpfc","rru","rrh","rrus","rus","rusb","mmu","dug","duw","dus","dub","ubbp","npu","ncu","bbu","fbba","rbs","bb","sfp","sfb","odu","epb","fsmfa","isv3","fiber","fibr","lan","jumper","cooler","koler","coler","fan","tcu","fcu","flatpack","smartpack","anten","antn","gps","fuse","fiuz","batt","batry","esm","ladder","switch","swich","sowiche","relay","umpt","pfu","scu"];
const UNIT_SET = new Set(UNIT_WORDS);
const UNIT_RE = new RegExp("\\b(" + UNIT_WORDS.join("|") + ")\\b", "g");
const FAMILY = [
  ["رادیویی", /\b(rru|rrh|rrus|rus|rusb?|mmu|dug|duw|dus|dub|ubbp|npu|ncu|bbu|fbba|rbs|bb|scu)\b/],
  ["برق", /\b(ncr|psu|vpsu|upsu|pbc|fpfc)\b/],
  ["اپتیک", /\b(sfp|sfb|odu|epb|fsmfa|isv3|fiber|fibr|lan|jumper)\b/],
  ["مکانیکی", /\b(cooler|koler|coler|fan|tcu|fcu|flatpack|smartpack|anten|antn|gps)\b/],
  ["مصرفی", /\b(fuse|fiuz|batt|batry|esm|ladder)\b/],
  ["انتقال", /\b(umpt|relay|switch|swich|sowiche|pfu)\b/],
];
const fam = (u) => { const w = String(u).toLowerCase(); for (const [n, re] of FAMILY) if (re.test(w)) return n; return "متفرقه"; };
const CONS = new Set(["fuse","fiuz","batt","batry","esm","ladder","jumper","fiber","fibr","lan"]);
// consumables = spare-parts consumed per replacement (fiber/fuse/cable/battery/ladder)
// equipment units = RRU/NPU/SFP/PSU... which are field-replaceable modules

// site codes
const SITE_PREFIXES = new Set(["t","e","n","b","h","d","l","f","g","k","c","m","s","v","w","a","r","j","x","y",
  "dt","lt","lut","dl","dlut","dd","th","tu","tn","te","teb","ter","kr","tr","ha","haye","tw","pk"]);
const NOT_SITE = /(good|bad|fault|falt|down|add|rem|req|ok|new|old|noa|site|cell|unit|pack|esm|adu|batty|batt|battery|hub|mains|vol|amp)/;
const isSitePrefix = (p) => {
  const w = String(p).toLowerCase().replace(/\s|-/g, "");
  if (SITE_PREFIXES.has(w)) return true;
  if (NOT_SITE.test(w)) return false;
  return /^[a-z]{2,5}$/.test(w) && /[tlscbrd]$/.test(w);
};
const siteRe = /([a-z]{1,5})\s?-?\s?(\d{4})\b/g;
function findSites(t) {
  const out = new Set(); let m; siteRe.lastIndex = 0;
  while ((m = siteRe.exec(t))) {
    if (m[1] && (!isSitePrefix(m[1]) || UNIT_SET.has(m[1]))) continue;
    out.add((m[1] ? m[1].toUpperCase() : "") + m[2]);
  }
  return [...out];
}

// events
const EV = {
  FAULT: [/\b(fault|faulty|falte|fualt|falt|down|damage|damaged|burn|burnt|broken|trip|busted|bad)\b/,
    /(فالت|فالتی|خراب|خرابی|سوخته|شکسته|دمیج|آب خورده|قطع|پرید|تریپ|ایراد|معیوب)/],
  REQUEST: [/\b(request|need|required|order|shortage|pending|waiting)\b/,
    /(درخواست|نیاز|تقاضا|سفارش|کمبود|موجود نیست|نداریم|در انتظار|باید تهیه|تأمین|تامین)/],
  SUPPLY: [/\b(sent to site|supplied|dispatched|installed on|delivered)\b/,
    /(ارسال شد|ارسالی|فرستاد|فرستاده شد|تحویل سایت|رفت سایت|نصب شد|نصب روی سایت|دمیج شده|دمیج شد|تأمین شد|تامین شد)/],
  RETURN: [/\b(return|rma|returned|back to stock)\b/,
    /(برگشت|برگشتی|عودت|مرجوع|مرجوعی|رفت انبار|برگشت به انبار|تحویل انبار شد|به انبار)/],
  SWAP: [/\b(swap|replaced)\b/, /(تعویض|جایگزینی|جایگزین)/],
  RESTORE: [/\b(recovered|restored|cleared|resolved|fixed)\b/, /(رفع شد|راه ?انداز|بالا آمد|سالم|ریکاور|برطرف)/],
};
const detect = (t) => {
  const hits = Object.entries(EV).filter(([, pats]) => pats.some(p => p.test(t))).map(([k]) => k);
  if (hits.includes("SUPPLY") && hits.includes("RETURN") && /(تحویل انبار شد|برگشت|عودت|مرجوع|رفت انبار)/.test(t)) return hits.filter(h => h !== "SUPPLY");
  return hits;
};

// ===== collect =====
const events = [];
const batAgg = new Map();       // site -> battery stats
const batModelAgg = new Map();  // model -> mentions
const BAT_KW = /(باطری|باتری|باتري|battery|batt\b|esm\b|سلول)/;
const BAT_STATES = {
  "خراب": /(باطری|باتری|battery|batt|سلول|esm)[^.]{0,30}(خراب|فالت|معیوب|سوخته|failed|fault|dead)|(خراب|فالت|معیوب|سوخته)[^.]{0,20}(باطری|باتری|battery|batt|esm)/,
  "فاقد": /(فاقد\s?ب?اطری|بدون\s?ب?اطری|باطری\s?ندار|باتری\s?ندار|no\s?battery|battery\s?missing|missing\s?battery)/,
  "نیاز": /(نیاز\s?به\s?ب?اطری|باطری\s?نیاز|باتری\s?نیاز|نیاز\s?باطری|باطری\s?بخوایم|باطری\s?میخوایم)/,
  "تست": /(تست\s?ب?اطری|تست\s?باتری|battery\s?test|تست\s?شارژ)/,
  "تعویض": /(تعویض\s?ب?اطری|تعویض\s?باتری|swap\s?battery|add\s?battery|اضافه\s?شد\s?باطری)/,
  "سالم": /(باطری\s?سالم|باتری\s?سالم|healthy|در\s?مدار|ok\s?bood|باطری\s?ok)/,
  "قطع برق": /(قطع\s?ب?رق|برق\s?رفت|برق\s?قطع|power\s?cut|no\s?power)/,
  "نرفت روی باطری": /(روی\s?ب?اطری\s?نمی?ر|روی\s?باتری\s?نرفت|باتری\s?نمی?گیرد)/,
};
const BAT_MODELS = [
  ["ESM", /\besm\b/], ["Huawei", /huawei|هوآوی/], ["صبا باتری", /صبا\s?باتری|saba/], ["FIAMM", /fiamm/],
  ["C&D", /c\s?&\s?d/], ["Sonnenschein", /sonnen/], ["Eltek", /eltek/], ["12V", /12\s?v/], ["48V", /48\s?v/], ["2V Cell", /2\s?v\s?(cell|سلول)/],
  ["100Ah", /100\s?ah/], ["150Ah", /150\s?ah/], ["200Ah", /200\s?ah/],
];
let batMsgs = 0, totalMsgs = 0;
const seenBat = new Set();

for (const f of fs.readdirSync(MERGED).filter(x => x.endsWith(".json"))) {
  const chat = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  for (const m of JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"))) {
    totalMsgs++;
    const raw = (m.x || "").replace(/\s+/g, " ").trim();
    if (!raw || raw === "[object Object]" || raw.length < 4) continue;
    const t = PRE(raw);
    const sites = findSites(t);
    // battery
    if (BAT_KW.test(t)) {
      batMsgs++;
      const states = Object.entries(BAT_STATES).filter(([, re]) => re.test(t)).map(([k]) => k);
      const models = BAT_MODELS.filter(([, re]) => re.test(t)).map(([k]) => k);
      const date = new Date(m.d + 3.5 * 3600000).toISOString().slice(0, 10);
      for (const s of sites) {
        const dk = s + "|" + states.join(",") + "|" + date + "|" + t.slice(0, 50);
        if (states.length && seenBat.has(dk)) continue;
        if (states.length) seenBat.add(dk);
        if (!batAgg.has(s)) batAgg.set(s, { site: s, states: new Map(), models: new Set(), first: date, last: date, samples: [] });
        const a = batAgg.get(s);
        for (const st of states) a.states.set(st, (a.states.get(st) || 0) + 1);
        for (const mo of models) a.models.add(mo);
        if (date < a.first) a.first = date;
        if (date > a.last) a.last = date;
        if (a.samples.length < 2) a.samples.push(raw.slice(0, 110));
      }
      for (const mo of models) {
        if (!batModelAgg.has(mo)) batModelAgg.set(mo, { model: mo, mentions: 0, sites: new Set() });
        const b = batModelAgg.get(mo); b.mentions++; for (const s of sites) b.sites.add(s);
      }
    }
    // unit events
    const units = [...new Set((t.match(UNIT_RE) || []))];
    if (!units.length) continue;
    const evs = detect(t);
    if (!evs.length) continue;
    if (t.length > 420) continue;
    for (const ev of evs) for (const u of units) events.push({ unit: u.toUpperCase(), family: fam(u), site: sites[0] || "", ev, t: m.d, chat, text: raw.slice(0, 130) });
  }
}
events.sort((a, b) => a.t - b.t);

// FIFO pairing
const open = new Map(); const unitsAgg = new Map();
function U(u) { if (!unitsAgg.has(u)) unitsAgg.set(u, { unit: u, family: fam(u), faults: 0, requests: 0, dispatches: 0, swaps: 0, restores: 0, returns: 0, supplied: 0, restored: 0, unmet: 0, open30: 0, leadSum: 0, leadN: 0, leadMax: 0, first: Infinity, last: 0, sites: new Set(), consumable: CONS.has(u.toLowerCase()), samples: [] }); return unitsAgg.get(u); }
for (const e of events) {
  const a = U(e.unit);
  a.first = Math.min(a.first, e.t); a.last = Math.max(a.last, e.t);
  if (e.site) a.sites.add(e.site);
  if (e.ev === "FAULT" || e.ev === "REQUEST") {
    if (e.ev === "FAULT") a.faults++; else a.requests++;
    if (!open.has(e.unit)) open.set(e.unit, []);
    open.get(e.unit).push({ site: e.site, ev: e.ev, t: e.t });
    if (a.samples.length < 2) a.samples.push(e.text);
  } else if (e.ev === "SUPPLY" || e.ev === "SWAP") {
    if (e.ev === "SUPPLY") a.dispatches++; else a.swaps++;
    const arr = open.get(e.unit);
    if (arr && arr.length) {
      let idx = arr.findIndex(d => d.site && d.site === e.site); if (idx < 0) idx = 0;
      const d = arr.splice(idx, 1)[0]; a.supplied++;
      const lead = (e.t - d.t) / 86400000;
      if (lead >= 0) { a.leadSum += lead; a.leadN++; a.leadMax = Math.max(a.leadMax, lead); }
    }
  } else if (e.ev === "RESTORE") {
    a.restores++;
    const arr = open.get(e.unit);
    if (arr && arr.length && e.site) { const idx = arr.findIndex(d => d.site === e.site); if (idx >= 0) { arr.splice(idx, 1); a.restored++; } }
  } else if (e.ev === "RETURN") a.returns++;
}
const nowMs = Date.now();
for (const [unit, arr] of open) { const a = unitsAgg.get(unit); for (const d of arr) { a.unmet++; if (d.ev === "FAULT" && (nowMs - d.t) < 30 * 86400000) a.open30++; } }

// monthly series per family
const months = [...new Set(events.map(e => new Date(e.t + 3.5 * 3600000).toISOString().slice(0, 7)))].sort();
const famMonthly = {};
for (const e of events) { if (e.ev !== "FAULT") continue; const mo = new Date(e.t + 3.5 * 3600000).toISOString().slice(0, 7); if (!famMonthly[e.family]) famMonthly[e.family] = {}; famMonthly[e.family][mo] = (famMonthly[e.family][mo] || 0) + 1; }

const q = (v) => `"${String(v ?? "").replace(/"/g, "'").replace(/[\r\n]+/g, " ")}"`;
const B = "\uFEFF";
const d2 = (ms) => new Date(ms + 3.5 * 3600000).toISOString().slice(0, 10);
const write = (f, head, rows) => {
  const body = B + head.map(q).join(",") + "\n" + rows.map(r => head.map(h => q(r[h])).join(",")).join("\n") + "\n";
  try { fs.writeFileSync(path.join(OUT, f), body, "utf8"); console.log("wrote", f, rows.length); }
  catch (e) { const alt = f.replace(/\.csv$/, "_new.csv"); fs.writeFileSync(path.join(OUT, alt), body, "utf8"); console.log("wrote", alt, rows.length, "(locked original)"); }
};

// ===== 20: unit models full stats =====
const allUnits = [...unitsAgg.values()].sort((a, b) => b.faults - a.faults);
write("20_unit_full_stats.csv",
  ["unit","family","category","faults","requests","dispatches","swaps","restores","returns","supplied","restored","unmet","open_needs_30d","avg_lead_days","max_lead_days","sites_count","first_seen","last_seen","sample"],
  allUnits.map(a => ({ unit: a.unit, family: a.family, category: a.consumable ? "مصرفی" : "تجهیز", faults: a.faults, requests: a.requests, dispatches: a.dispatches, swaps: a.swaps, restores: a.restores, returns: a.returns, supplied: a.supplied, restored: a.restored, unmet: a.unmet, open_needs_30d: a.open30, avg_lead_days: a.leadN ? (a.leadSum / a.leadN).toFixed(1) : "", max_lead_days: a.leadN ? a.leadMax.toFixed(0) : "", sites_count: a.sites.size, first_seen: isFinite(a.first) ? d2(a.first) : "", last_seen: a.last ? d2(a.last) : "", sample: a.samples.join(" || ") })));

// ===== 21: consumables =====
const cons = allUnits.filter(a => a.consumable);
write("21_consumables_full.csv",
  ["part","faults","requests","dispatches","swaps","returns","supplied","restored","unmet","open_needs_30d","avg_lead_days","max_lead_days","sites_count","first_seen","last_seen"],
  cons.map(a => ({ part: a.unit, faults: a.faults, requests: a.requests, dispatches: a.dispatches, swaps: a.swaps, returns: a.returns, supplied: a.supplied, restored: a.restored, unmet: a.unmet, open_needs_30d: a.open30, avg_lead_days: a.leadN ? (a.leadSum / a.leadN).toFixed(1) : "", max_lead_days: a.leadN ? a.leadMax.toFixed(0) : "", sites_count: a.sites.size, first_seen: isFinite(a.first) ? d2(a.first) : "", last_seen: a.last ? d2(a.last) : "" })));

// ===== 22: battery sites =====
const batArr = [...batAgg.values()];
write("22_battery_full_stats.csv",
  ["site","status","faulty","missing","needs","test","swap","healthy","power_cut","not_on_bat","models","first","last","sample"],
  batArr.map(a => ({ site: a.site, status: a.states.get("خراب") ? "خراب" : a.states.get("فاقد") ? "فاقد" : a.states.get("نیاز") ? "نیاز" : a.states.get("قطع برق") ? "مشکل برق" : a.states.get("سالم") ? "سالم" : "سایر", faulty: a.states.get("خراب") || 0, missing: a.states.get("فاقد") || 0, needs: a.states.get("نیاز") || 0, test: a.states.get("تست") || 0, swap: a.states.get("تعویض") || 0, healthy: a.states.get("سالم") || 0, power_cut: a.states.get("قطع برق") || 0, not_on_bat: a.states.get("نرفت روی باطری") || 0, models: [...a.models].join("|"), first: a.first, last: a.last, sample: a.samples.join(" || ") })).sort((x, y) => (y.faulty + y.missing + y.needs) - (x.faulty + x.missing + x.needs)));

// ===== 23: battery models =====
write("23_battery_models_full.csv",
  ["battery_model","mentions","sites_count"],
  [...batModelAgg.values()].sort((a, b) => b.mentions - a.mentions).map(b => ({ battery_model: b.model, mentions: b.mentions, sites_count: b.sites.size })));

// ===== 24: battery monthly trend =====
const batMonthly = {};
for (const f of fs.readdirSync(MERGED).filter(x => x.endsWith(".json"))) {
  for (const m of JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"))) {
    const raw = (m.x || ""); if (!raw || raw === "[object Object]") continue;
    const t = PRE(raw); if (!BAT_KW.test(t)) continue;
    const mo = new Date(m.d + 3.5 * 3600000).toISOString().slice(0, 7);
    if (!batMonthly[mo]) batMonthly[mo] = { fault: 0, missing: 0, need: 0, total: 0 };
    batMonthly[mo].total++;
    if (BAT_STATES["خراب"].test(t)) batMonthly[mo].fault++;
    if (BAT_STATES["فاقد"].test(t)) batMonthly[mo].missing++;
    if (BAT_STATES["نیاز"].test(t)) batMonthly[mo].need++;
  }
}
write("24_battery_monthly.csv", ["month","total","faulty","missing","needed"], Object.entries(batMonthly).sort((a, b) => a[0].localeCompare(b[0])).map(([mo, v]) => ({ month: mo, total: v.total, faulty: v.fault, missing: v.missing, needed: v.need })));

// ===== 25: unit monthly faults by family =====
write("25_unit_monthly_by_family.csv", ["month","family","faults"], months.flatMap(mo => Object.entries(famMonthly).map(([f, byM]) => ({ month: mo, family: f, faults: byM[mo] || 0 })).filter(r => r.faults > 0)));

console.log(`\nbatMsgs=${batMsgs} batSites=${batAgg.size} units=${allUnits.length} events=${events.length} total=${totalMsgs}`);

// ===== SVG Dashboard =====
function barChart(title, items, color, maxBars = 15, unit = "") {
  const W = 560, BH = 22, PAD = 8, LAB = 200, VALW = 60;
  const H = items.length * (BH + 6) + 40;
  const max = Math.max(...items.map(i => i[1]), 1);
  let s = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" font-family="Tahoma" font-size="12">`;
  s += `<text x="${PAD}" y="20" font-size="14" font-weight="bold" fill="#222">${title}</text>`;
  items.forEach(([label, val], i) => {
    const y = 34 + i * (BH + 6);
    const w = Math.max(2, Math.round((val / max) * (W - LAB - VALW - 20)));
    s += `<text x="${PAD}" y="${y + 15}" fill="#333">${String(label).slice(0, 28)}</text>`;
    s += `<rect x="${LAB}" y="${y + 2}" width="${w}" height="${BH - 4}" fill="${color}" rx="3"/>`;
    s += `<text x="${LAB + w + 6}" y="${y + 15}" fill="#555">${val}${unit}</text>`;
  });
  return s + `</svg>`;
}
function lineChart(title, points, color, W = 1100, H = 260) {
  const PADL = 50, PADR = 20, PADT = 34, PADB = 50;
  const max = Math.max(...points.map(p => p[1]), 1);
  const xs = points.length > 1 ? (W - PADL - PADR) / (points.length - 1) : 1;
  const yOf = v => PADT + (H - PADT - PADB) * (1 - v / max);
  let s = `<svg xmlns="http://www.w3.org/2000/svg" width="${W}" height="${H}" font-family="Tahoma" font-size="11">`;
  s += `<text x="${PADL}" y="20" font-size="14" font-weight="bold" fill="#222">${title}</text>`;
  for (let g = 0; g <= 4; g++) {
    const v = Math.round(max * g / 4), y = yOf(v);
    s += `<line x1="${PADL}" y1="${y}" x2="${W - PADR}" y2="${y}" stroke="#e5e5e5"/>`;
    s += `<text x="6" y="${y + 4}" fill="#888">${v}</text>`;
  }
  const pts = points.map((p, i) => [PADL + i * xs, yOf(p[1])]);
  s += `<polyline points="${pts.map(p => p.join(",")).join(" ")}" fill="none" stroke="${color}" stroke-width="2"/>`;
  points.forEach((p, i) => { if (i % Math.ceil(points.length / 12) === 0) s += `<text x="${pts[i][0] - 20}" y="${H - 20}" fill="#666" transform="rotate(45 ${pts[i][0] - 20} ${H - 20})">${p[0]}</text>`; });
  return s + `</svg>`;
}

let html = `<!doctype html><html dir="rtl"><head><meta charset="utf-8"><title>داشبورد آماری یونیت و باطری</title>
<style>body{font-family:Tahoma;margin:20px;background:#fafafa}h2{color:#333;border-bottom:2px solid #4a90d9;padding-bottom:4px}
.card{background:#fff;border:1px solid #ddd;border-radius:8px;padding:14px;margin:14px 0;display:inline-block;vertical-align:top}
.row{display:flex;flex-wrap:wrap;gap:14px}.kpi{font-size:26px;font-weight:bold;color:#4a90d9}.kpi-l{font-size:12px;color:#777}</style></head><body>`;
html += `<h1>داشبورد آماری — یونیت‌ها، مصرفی‌ها، باطری‌ها</h1><div style="color:#777">منبع: ${totalMsgs.toLocaleString()} پیام از چت‌های عملیاتی | تاریخ: ${new Date(nowMs + 3.5 * 3600000).toISOString().slice(0, 10)}</div>`;

// ===== cooler (from cooler_report outputs) =====
let coolerSites = [], coolerModels = [];
try {
  const readCsv = (f) => {
    const lines = fs.readFileSync(path.join(OUT, f), "utf8").replace(/^\uFEFF/, "").split("\n").filter(Boolean);
    const head = []; { let cur = "", qq = false; for (const ch of lines[0]) { if (ch === '"') qq = !qq; else if (ch === "," && !qq) { head.push(cur); cur = ""; } else cur += ch; } head.push(cur); }
    return lines.slice(1).map(l => { const o = []; let cur = "", qq = false; for (const ch of l) { if (ch === '"') qq = !qq; else if (ch === "," && !qq) { o.push(cur); cur = ""; } else cur += ch; } o.push(cur); return Object.fromEntries(head.map((h, i) => [h, o[i] ?? ""])); });
  };
  coolerSites = readCsv("27_cooler_by_site.csv");
  coolerModels = readCsv("27c_cooler_models.csv");
} catch (e) { console.log("cooler data not ready:", e.message); }
const coolFaulty = coolerSites.filter(r => r.status === "خراب" || r.status === "فن خراب").length;
const coolTemp = coolerSites.filter(r => r.status === "دمای بالا").length;
const coolReturned = coolerSites.filter(r => /انبار/.test(r.status)).length;
const coolChanged = coolerSites.filter(r => /تعویض|نصب/.test(r.status)).length;

// KPI cards
const totalFaults = allUnits.reduce((s, a) => s + a.faults, 0);
const totalUnmet = allUnits.reduce((s, a) => s + a.unmet, 0);
const totalOpen30 = allUnits.reduce((s, a) => s + a.open30, 0);
const batFaulty = batArr.filter(a => a.states.get("خراب")).length;
const batMissing = batArr.filter(a => a.states.get("فاقد")).length;
const batNeeds = batArr.filter(a => a.states.get("نیاز")).length;
html += `<div class="row">
<div class="card"><div class="kpi">${totalFaults.toLocaleString()}</div><div class="kpi-l">کل خرابی یونیت</div></div>
<div class="card"><div class="kpi">${totalUnmet.toLocaleString()}</div><div class="kpi-l">خرابی تأمین‌نشده</div></div>
<div class="card"><div class="kpi">${totalOpen30.toLocaleString()}</div><div class="kpi-l">نیاز فعال ۳۰ روز</div></div>
<div class="card"><div class="kpi">${batFaulty}</div><div class="kpi-l">سایت باطری خراب</div></div>
<div class="card"><div class="kpi">${batMissing}</div><div class="kpi-l">سایت فاقد باطری</div></div>
<div class="card"><div class="kpi">${batNeeds}</div><div class="kpi-l">سایت نیازمند باطری</div></div>
<div class="card"><div class="kpi">${coolFaulty}</div><div class="kpi-l">سایت کولر خراب</div></div>
<div class="card"><div class="kpi">${coolTemp}</div><div class="kpi-l">سایت دمای بالا</div></div>
<div class="card"><div class="kpi">${coolReturned}</div><div class="kpi-l">کولر برگشتی به انبار</div></div>
</div>`;

// charts
html += `<div class="row">`;
html += `<div class="card">${barChart("بیشترین خرابی یونیت‌ها", allUnits.filter(a => !a.consumable).slice(0, 15).map(a => [a.unit, a.faults]), "#e2574c")}</div>`;
html += `<div class="card">${barChart("تأمین‌نشده‌ترین یونیت‌ها", [...allUnits].sort((a, b) => b.unmet - a.unmet).slice(0, 15).map(a => [a.unit, a.unmet]), "#d9534f")}</div>`;
html += `</div><div class="row">`;
html += `<div class="card">${barChart("نیاز فعال ۳۰ روز اخیر", [...allUnits].sort((a, b) => b.open30 - a.open30).slice(0, 15).map(a => [a.unit, a.open30]), "#f0ad4e")}</div>`;
html += `<div class="card">${barChart("قطعات مصرفی — خرابی", cons.slice(0, 10).map(a => [a.unit, a.faults]), "#8e6bbf")}</div>`;
html += `</div><div class="row">`;
html += `<div class="card">${barChart("میانگین زمان تأمین (روز) — کندترین", [...allUnits].filter(a => a.leadN >= 3).sort((a, b) => (b.leadSum / b.leadN) - (a.leadSum / a.leadN)).slice(0, 15).map(a => [a.unit, Math.round(a.leadSum / a.leadN)]), "#5bc0de")}</div>`;
html += `<div class="card">${barChart("سایت‌های باطری خراب (تعداد رویداد)", batArr.filter(a => a.states.get("خراب")).sort((a, b) => (b.states.get("خراب") || 0) - (a.states.get("خراب") || 0)).slice(0, 15).map(a => [a.site, a.states.get("خراب")]), "#e67e22")}</div>`;
html += `</div><div class="row">`;
html += `<div class="card">${barChart("سایت‌های فاقد باطری", batArr.filter(a => a.states.get("فاقد")).sort((a, b) => (b.states.get("فاقد") || 0) - (a.states.get("فاقد") || 0)).slice(0, 15).map(a => [a.site, a.states.get("فاقد")]), "#c0392b")}</div>`;
html += `<div class="card">${barChart("مدل‌های باطری در گردش", [...batModelAgg.values()].sort((a, b) => b.mentions - a.mentions).slice(0, 10).map(b => [b.model, b.mentions]), "#27ae60")}</div>`;
html += `</div>`;

// monthly line charts
const uMonths = months.map(mo => [mo, events.filter(e => e.ev === "FAULT" && new Date(e.t + 3.5 * 3600000).toISOString().slice(0, 7) === mo).length]);
html += `<div class="card" style="width:100%">${lineChart("روند ماهانه خرابی یونیت‌ها", uMonths, "#e2574c")}</div>`;
const bMonths = Object.entries(batMonthly).sort((a, b) => a[0].localeCompare(b[0])).map(([mo, v]) => [mo, v.total]);
html += `<div class="card" style="width:100%">${lineChart("روند ماهانه پیام‌های باطری", bMonths, "#e67e22")}</div>`;

// cooler charts
if (coolerSites.length) {
  html += `<div class="row">`;
  html += `<div class="card">${barChart("سایت‌های کولر خراب", coolerSites.filter(r => r.status === "خراب" || r.status === "فن خراب").slice(0, 15).map(r => [r.site, Number(r.fault_count) || 1]), "#d35400")}</div>`;
  html += `<div class="card">${barChart("سایت‌های دمای بالا (کولر)", coolerSites.filter(r => r.status === "دمای بالا").slice(0, 15).map(r => [r.site, Number(r.temp_alarm_count) || 1]), "#c0392b")}</div>`;
  html += `</div><div class="row">`;
  html += `<div class="card">${barChart("مدل‌های کولر در گردش", coolerModels.slice(0, 10).map(r => [r.cooler_model, Number(r.mentions)]), "#16a085")}</div>`;
  html += `<div class="card">${barChart("کولرهای برگشتی به انبار", coolerSites.filter(r => /انبار/.test(r.status)).slice(0, 15).map(r => [r.site, Number(r.returned_count) || 1]), "#7f8c8d")}</div>`;
  html += `</div>`;
}

html += `</body></html>`;
fs.writeFileSync(path.join(OUT, "26_dashboard_v2.html"), html, "utf8");
console.log("wrote 26_dashboard_v2.html");