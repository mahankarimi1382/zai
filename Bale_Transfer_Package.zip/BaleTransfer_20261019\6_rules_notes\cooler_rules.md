# قواعد تشخیص وضعیت کولر سایت‌ها از پیام‌های چت عملیاتی ایرانسل (منطقه R7)

دادهٔ مرجع: `C:\Users\someBody\.zcode\workspace\default\bale_report\merged\*.json`
فرمت هر رکورد: `{rid, d (epoch ms), u, t, x (متن), f, out}`
تاریخ همهٔ نمونه‌ها با آفست `+3.5h` (IRST) محاسبه شده است.

**فرایند تولید این سند (قابل تکرار):**
```bash
node grep_msgs2.mjs "کولر|cooler|koler|coler" 80        # نمونه‌گیری سراسری
node grep_msgs2.mjs "هیتکس|hitex|heatex" 40             # هیتکس (heat exchanger)
node batt_dump.mjs "cooler|کولر" "<chatFile>" 40 500    # چاپ پیام‌های کامل یک چت
node cooler_stats.mjs                                    # شمارش دسته‌ها + سایت‌ها
node cooler_final.mjs                                    # شمارش قالب‌های نهایی F1..F15
```

---

## ۰) خلاصهٔ آماری (کل corpus، ۷۱ فایل چت)

| دسته | کلیدواژهٔ محوری | تعداد پیام | تعداد چت |
|---|---|---|---|
| کولر (هر شکل املایی) | `کولر\|cooler\|coler\|kooler\|coolr` | **۱۰۹۰** | ۲۷ |
| کولر فالت/خراب/سوخته | see §2.1 | **۲۷۳** | ۲۰ |
| تمپ بالا (co-occurring) | `تمپ شدید\|temp on\|high temp` | **۳۸۶** | ۳۱ |
| فن فالت/نویز | see §2.4 | **۱۷۰** | ۱۹ |
| هیتکس (HX) | `هیتکس\|hitex\|heat ex` | **۲۱۲** | ۱۶ |
| شستشو کولر/هیتکس | see §2.5 | **۹۶** | ۱۴ |
| نصب کولر | see §2.3 | **۳۵** | ۱۲ |
| تعویض کولر | see §2.3 | **۲۰** | ۹ |
| NAC (مدل نیان) | `NAC\d{3,4}` | **۶۶** | ۲۱ |
| NCR48U | `NCR48U` | **۱۱** | ۶ |
| آلارم Cooling Failure | `Cooling (System) Failure` | **۱۲۱** | ۲۲ |
| AEC (پیمانکار مدرنایزیشن) | `AEC` | **۱۴۸۶** | ۲۰ |
| ACU | `ACU` | **۳۳** | ۷ |
| کولر کنسل | — | ۲ | ۱ |

> **نکتهٔ کلیدی:** ۱۰۹۰ پیام «کولر» عمدتاً در ۵ قالب می‌آید: (۱) پیام آزاد تیم عملیاتی Zone_D/R7_DS، (۲) گزارش بازدید Key-Delivery، (۳) تیکت آلارم `NIAN … Cooling Failure`، (۴) پیام انبار `R7_Return_Material`، (۵) فعالیت FLM.

**چت‌های کلیدی کولر (به ترتیب اهمیت):**

| chatId | نام | تعداد پیام کولر | نقش |
|---|---|---|---|
| 1206812704 | R7_DS_Follow_UP | 130 | عملیات روزانه منطقه |
| 1007814392 | Zone_D | 39 | عملیات Zone D (منبع غنی فارسی) |
| 1737503770 | R7_Return_Material | **416** | انبار/عودت — الگوی «کولر فالتی NNNN ارسال انبار» |
| 517632817 | ZONE_A_KEY_Delivery | 40 | تحویل کلید AEC |
| 785878952 | ZONE_E_KEY_Delivery | 40 | تحویل کلید + «کولر خراب. در باز می‌مونه» |
| 1986682312 | eslamshahr | 40 | نصب/تعویض کولر (نصب‌کار محلی) |
| 1365646822 | Picture_Zone_E | 54 | گزارش بازدید عکس‌دار (نیان/هیتکس/ACU) |
| 2145164056 | Zone_Z | 69 | نصب/تعویض (کولر ۱۲۰۹، ۵۵۹۲…) |
| 729401255 | hitex_clean | 10 | **چت اختصاصی شستشوی هیتکس** |
| 351194861 | picture_of_site_zone_C | 42 | مدل‌ها: «کولر ۵۵۰w / ۲۰۰۰w / نیان ۹۰» |
| 1703520267 | Zone_A | 41 | نصب کولر ۱۲۰۹/۱۵۶۰، کمپرسور/گاز |
| 1048230922 | ZONE_Z_KEY_Delivery | 65 | AEC Modernization + تحویل کلید |
| 1097166168 | mehrdad_aslani | — | **PR فنی: کد مدل NAC3000D/NCR48U/NAC550** |

---

## ۱) پیش‌پردازش اجباری

```js
const FA = 0x06F0;
const norm = s => s
  .replace(/[۰-۹]/g, d => String(d.charCodeAt(0) - FA))     // ارقام فارسی → لاتین
  .replace(/[٠-٩]/g, d => String(d.charCodeAt(0) - 0x0660))  // ارقام عربی
  .replace(/[يى]/g, 'ی').replace(/ك/g, 'ک')                 // ی/ک عربی
  .replace(/‌‏‎/g, '')                        // نیم‌فاصله/RTL
  .replace(/\s+/g, ' ').trim();

// کلیدواژهٔ مرکزی کولر — همهٔ املاءها
const COOLER = /کولر|کوالر|cooler|coler|kooler|coolr/i;
// «نیان» برند رک/کولر است — کو-تاگ مهم
const NIAN   = /نیان|nian|NAC/i;
const HITEX  = /هیتکس|هتکس|hitex|heatex|heat\s*ex/i;
```

### ۱-۱) استخراج کد سایت (چهار سطح اولویت — همان قواعد باتری)

```js
const PREFIX = new Set(['t','e','n','b','h','d','dt','th','dl','lu','l','k','m',
                        'p','c','s','r','f','g','w','a','j','x','v','y','z','q','i','o','u']);

// سطح ۱ – کد صریح: T1482, E6053, N4119, DT6593, H9024
const SITE_TOK = /\b([A-Za-z]{1,3})-?\s?(\d{3,5})\b/g;

// سطح ۲ – داخل ساختار MBTS (آلارم‌های تیکتی): MBTS_T3585X → T3585
const SITE_MBTS = /MBTS[_-]?([A-Z]{1,3}\d{3,5})X?/i;

// سطح ۳ – سرِ پیام (قالب Key-Delivery/activity): «۳۶۰۴ همراه پورعبدالله» → 3604
const SITE_LEAD = /^\s*([A-Za-z]{0,2})(\d{3,4})(?![0-9])/;

// سطح ۴ – بعد از واژهٔ «سایت/site»: «سایت t2750» / «سایت 4001»
const SITE_AFTER = /(?:سایت|site)\s*t?\s*-?([A-Za-z]{0,2}\d{3,5})/i;
```

> ⚠️ در `R7_Return_Material` و `activity_zon_D` الگوی غالب «کولر [فالتی] NNNN» است که NNNN **کد سایت** است (نه سریال کولر). در PR های فنی `mehrdad_aslani` سریال‌ها ارقام ۷ رقمی‌اند و سایت جدا در `Site ID :` می‌آید.

### ۱-۲) نرمال‌سازی «فالت» — ۸ املاء رایج!

```js
const FAULT = /فالت|فالتی|فولت|fa?u?lt|fualt|fult|فالط|فلت/;   // همه در داده دیده شد
const NASB  = /نصب|nasb|nasbe|نصبی|نصبب/;
const CHANGE= /تعویض|change|chenge|chng|عوض|جابجا/;
const CANCEL= /کنسل|cansel|cancel|cansell/;
```

---

## ۲) مدل‌های واقعی کولر (کشف‌شده از متن‌ها)

### ۲-۱) برند اصلی: **نیان (NIAN)** — تأمین‌کنندهٔ رک و کولر ایرانسل

| شاهد | نمونهٔ واقعی |
|---|---|
| «کولر نیان» | `R7_Return_Material` 2024-05-13: «یک عدد کولر نیان فالت سایت 1471 تحویل انبار داده شد» |
| «کولر رک نیان» | `R7_Return_Material` 2026-05-27: «۱ عدد کولر رک نیان ۱ عدد rrh طناب و قرقره T6775 تحویل اسنپ انبار شد» |
| «Cooler nian» | `eslamshahr` 2026-08-24: «5467 cooler rack nian shoste shod» |
| «کولر نیان ۹۰» | `picture_of_site_zone_C` 2026-08-07: «t1421 2ta NCR fault dare **Cooler nian 90 nist** Door eltek damage shode Cooler nian 90 va eltek shoste shod» |
| «Niyan 90» | `picture_of_site_zone_C` 2026-05-04: «**Niyan 90 Cooler 550w ro support nemide**» |
| «Nian 90» | `R7_DS_Follow_UP` 2026-03-17: «Nian 90 e» |
| «نیان ۹۰» | `Zone_Z` 2026-08-14: «اینجا نیان 90 هست که blvd و llvd فالت کرده» |

### ۲-۲) کدهای فنی مدل (از PR های فنی `mehrdad_aslani` و انبار `Zone_Z`)

| کد مدل | توضیح | نمونهٔ واقعی |
|---|---|---|
| **NAC3000D** | System Cooling (نیان) | «Fault Unit Description: SYSTEM COOLING / Fault Item code: **NAC3000D** / Good P/N: ER-NAC3000 / Responsible: HUAWEI» (T1197, PR898947) |
| **NAC2000D** | Air Conditioner 48U | «NCR 48U **Air Conditioner** / ER-NCR48U-D/01 / **NAC2000D**» (E5438, PR914416) |
| **NAC550** | نیان ۵۵۰ وات | «NCR48U COOLINGSYTEM / NCR48UC/02 / **NAC550** / Good P/N: ER-NAC550D-M/01» (T6519) |
| **NAC1250D-A/03** | نیان ۱۲۵۰ | `Zone_Z` 2026-08-19: «**NAC1250D-A/03** 9700784 1 E5592 … tahvil bgirid» |
| **NCR48U** (-C/-D/-G/-H) | کولر رک ۴۸U (کولر رک اصلی) | «Fault Unit Description: **NCR48U** COOLINGSYTEM» |
| **BPD104105/2** | system cooling هواوی (مدل قدیمی) | «Fault Unit Description: system cooling / **BPD104105/2** / Responsible: HUAWEI» (T1237) |
| **ER-NAC3000 / ER-NAC2000 / ER-NAC550D-M/01** | P/N گود (Good) | همان PR ها |

### ۲-۳) توان (وات) در گفتار روزمره

| عبارت | نمونه |
|---|---|
| «کولر **۲۰۰۰**» | `activity_zon_D` 2026-08-13: «change cooler **2000**» (سایت 1096) — یعنی NAC2000 |
| «کولر **۱۲۵۰**» | `eslamshahr` 2026-08-30: «E5243 **acu 1250**» |
| «کولر **۵۵۰ وات**» | `picture_of_site_zone_C` 2026-04-28: «این سایت کولر نداره **کولر ۵۵۰ وات** گذاشتن تمپ داره» |
| «**500w** گذاشتن جای **2000w**» | `picture_of_site_zone_C` 2026-04-11: «Cooler 500w gazazshtan jaye 2000w» |
| «کولر **۳۰۰۰**» | `R7_Return_Material` 2026-07-19: «**NAC 3000** T3442» |
| «کولر **۹۰**» | = نیان ۹۰ (مدل رک) |
| «**ACU** 1250» | `S` 2026-08-27: «T3138 **NIAN ACU 1250** in unito check mikonid» |

### ۲-۴) ACU در این بافت = یونیت سرمایش/کولر (نه پیمانکار)

| شاهد | متن |
|---|---|
| ACU به‌عنوان قطعه | `R7_DS_Follow_UP` 2026-06-22: «chizi ke be man goft ineke **ACU fault** hast, khob **ACU ro avaz konim** ok mishe dige» |
| «**التک ACU نداره**» | `R7_DS_Follow_UP` 2026-06-22: «نه اینطور نیست **التک ACU نداره**» → ACU متعلق به رک نیان است نه Eltek |
| نصب ACU | `R7_DS_Follow_UP` 2026-05-10: «T3799 **ACU ro aval bayad nasb konim** ta unit haye MW bedan» |
| ACU 1250 | `S` 2026-08-27: «T3138 **NIAN ACU 1250**» |
| ACU + cooler هم‌ارز | `Picture_Zone_E` 2026-10-01: «N4356 nab **ACU nasb shod coller salem**» → بعد از نصب ACU، کولر سالم شد |

### ۲-۵) **AEC در این بافت = پیمانکار (نه نوع کولر)**

شواهد قطعی از ۳ قالب:
1. **«نفر aec»** — یعنی «فرد/نفر از شرکت AEC»: `ZONE_Z_KEY_Delivery`: «سایت t2799 به آقای مهرداد **نفر نفر aec** جهت عکسبرداری از دکل…» / «کلید سایت ۵۲۸۳ ۷۵۷۸ ۱۶۷۹ به آقای بنیادی **نفر aec** تحویل داده شد»
2. **«AEC Modernization»** — خط عنوان تیکت: «T2750 **AEC Modernization** Ali Maheralnaghsh-… NWG-OPS-TT-20260711-03904 Power al…» / «T1804 **AEC Modernization** … Tower-FDD Rack-TDD Rack»
3. **ستون Comment تیکت**: «N4228 A **NOA//AEC**» / «E5361 A project responsibility **AEC**» (`Setare_Motalebi`)

> نتیجه: AEC یک پیمانکار (احتمالاً مخفف شرکت) است که کارهای **مدرنایزیشن** و بازدید/تعویض انجام می‌دهد. «نفر aec» = اپراتور AEC. **کولر AEC نداریم؛ کولر نیان داریم.**

### ۲-۶) فلت‌پک (Flat Pack) — **رکتیفایر Eltek است، نه کولر**

- `chat_1099555220` 2025-09-28: «RE_ T2751__**Flatpack fault**__NWG-OPS-TT-…»
- `chat_1099555220` 2026-10-11: «RE_ T2866_**Flatpack fault**_…_**Eltek**»
- `R7_DS_Follow_UP` 2026-04-12: «T2853 1 **flatpack 3000** fault» → ۳۰۰۰ وات رکتیفایر
- **همراهی با کولر در یک پیام انبار** ولی اقلام جدا: «کولر ۲۸۴۰ و **فلت پک** ۳۸۷۹ ارسال شد انبار» / «کولرt1764 ۲تا **فلت پک** t1766 ارسال شد انبار»
- در پیام‌ها همیشه با `Smartpack`/`PSU`/`NCR` جمع می‌شود = خانوادهٔ پاور Eltek.

### ۲-۷) هیتکس (HX = Heat Exchanger) — **مکمل کولر، جدا از کولر**

- `Picture_Zone_E` 2026-09-26 (توضیح فنی نادر): «کولر دو تا الارم داره **کولر الارم ماله دماس** / **Fan fail مال فن هاشنه** که باد گرمو میگیره میده / **کمپرسور اکسترنال** هم برای در هاس»
- هیتکس‌ها معمولاً **۲ عدد** روی درب رک‌اند: «دوتا فن هیتکس همسوخته» / «هیتکس رو شستیم **هیتکس هاش خرابه**»
- چت اختصاصی: `hitex_clean` — الگوی استاندارد: «**۴۲۱۹ هیتکس شسته شد / ۲فن فالت**» یا «3675 hitex shoste shod / 5 fan salme / 1 fan fualt»

### ۲-۸) indoor/outdoor و کولر رک

در این بافت **کولر دکل/اتاق وجود ندارد**؛ همه کولرها **رک‌مانت** هستند:
- «کولر **رک** بالا و پایین» (کولر بالای رک + کولر پایین رک): `eslamshahr` 2026-08-23 «کولر رک بالا و پایین شسته شد»؛ `Picture_Zone_E` 2026-08-09 «کولر بالا و پایین رک پاور TDD فالت»
- «کولر **رک باتری**» / «کولر رک باطری»: `eslamshahr` 2026-08-30 «1833 کولر رک باطری»؛ `Zone_Z` 2026-09-20 «درخواست کولر رک باتری رو بزنید»
- «کولر **قسمت باتری ها**»: `Picture_Zone_E` 2026-08-08 «کولر قسمت باتری ها تعمیر و روشن شد»
- فن‌ها: **fan internal** (داخل رک) و **fan external** (روی درب رک): «fan external فالت fan internal فالت»
- کمپرسور: فقط کولرهای باتری‌خانه/رک نیان: «کولر رک **گاز نداره** و خاموش هست» / «**کمپرسورش ایراد داره**» / «تستش سالمه ولی انگار **گازش تموم شده**»

---

## ۳) انواع رویداد کولر (۷ دسته) با نمونهٔ واقعی

| # | رویداد | علائم متنی | نمونهٔ واقعی | سورس |
|---|---|---|---|---|
| 1 | **خرابی/فالت** | `cooler fault/fualt`، `کولر فالت/فالتی/خراب/سوخته`، `cooler faulte` | «اقا سایت ۱۱۴۳ رو چک میکنی **کولرش سوخته** اعلام فالتی کردم» / «کولرهای این رک کلا فالت شده **دمای رک روی ۵۷ بود**» / «مشخصات **کولر فالتی 4334** رو بفرستید» | Zone_D 09-18/10-02 |
| 2 | **دمای بالا (تمپ)** | `تمپ شدید`، `Temp on`، `high temp`، `با تمپ دان`، `hightemp` | «4G, DE5490 **Temp on** T1339 / **cooler fault**» / «در رک بسته بود **کولر فالته سایت تمپ شدید داره**» / «سایت با **تمپ دان** شده کولرش فالت» | Zone_D 09-20، Zone_A 09-29 |
| 3 | **نصب** | `Cooler nasb she/shod`، `نصب کولر`، `cooler nasb konim`، `ACU nasb` | «**N4334 Cooler nasb she** T3517 Cooler nasb she» / «**E6137 cooler nasb shod**» / «کولر جدید ۱۲۰۹ **نصب شد**» / «3ta coler 5133 3502 5360 **Nasb shod**» | Zone_D 10-01، R7_DS 05-21، Zone_A 09-30 |
| 4 | **تعویض** | `Coler chenge`، `تعویض کولر`، `cooler change`، `Cooler & NCU changing` | «**Coler chenge**» / «کسی نمیاد کمکم برای **تعویض کولره**» / «T6751 TDD UP **کولر نیان تعویض شد**» / «سایت 4100 کولر فالت… **تعویض شد کولر جدید** بسته شد در حال تست» | Zone_D 10-01، Picture_Zone_E 09-19، Zone_Z 08-06 |
| 5 | **فن خراب/نویز** | `fan noise`، `fan fault/fualt`، `فنش خراب شده`، `فن فالت`، `فن سوخته` | «میگه **فنش خراب شده** سمیم براش درخواست بزن کولر» / «۴۲۱۹ هیتکس شسته شد **۲فن فالت**» / «**1346 fan noise** dare» / «دوتا **فن هیتکس همسوخته**» | Zone_D 09-22، hitex_clean 08-09 |
| 6 | **هیتکس** | `هیتکس شسته شد`، `هیتکس خرابه`، `hitex shoste`، `clear hitex` | «**هیتکس شسته شد** فن ها سالم هستن» / «هیتکس رو شستیم **هیتکس هاش خرابه** الان **تمپ شدید** براش گرفتن» / «**هیتکسم میشورم** الان ک سر تمپ نباشه» | Zone_D 09-21/09-22 |
| 7 | **ریست/رفع** | `کولر ریست کردم درست شد`، `الارمش برطرف شد`، `کولر خنک داره کار میکنه` | «**کولر ریست کردم درست شد** انشالله که دوباره قط نکنه» / «بادوتا جواب میده **کولرهم الارمش برطرف شد**» / «الان **کولر خنک هستش**» | Zone_D 09-22 |
| 8 | **کنسل** | `کولر کنسله`، `cooler cansel` | «@mohsenahanchideh **کولر ها کنسله** داداش اینارو فالو کن» / «are **cooler cansel shode**» | Zone_D 10-02 |
| 9 | **خاموش‌کردن/یادرفتن** | `کولر خاموش کرده رفته`، `cooler off`، `کولرو خاموش` | «3403 امروز یکی اومده سایت چک کرده **کولر خاموش کرده رفته**» / «پروژه **کولر خاموش نکرده باشه** بعد درو ببند» / «نصف یونیتا از **تمپ شدید فالت شدن**» | Zone_Z 08-07، ZONE_A_KEY 07-30 |
| 10 | **سرقت/وندالیزم** | `وندلیزم کولر`، `vandalism` + cooler | «bbu کولرش **وندلیزم شده** داریم پیگیری ورک اردرشو انجام میدیم» / «کولرش مال چندسال پیش **وندلیز خورده**» | R7_DS 05-04 / 07-06 |
| 11 | **فقدان کولر** | `کولر ندارد/نداره/نیست` | «rack itmc **cooler nadare** baroon mizane tooye rack» / «T1633… **کولرم نداره**» / «۳۴۹۶ در رک بازه **کولر نداره**» | R7_DS 04-30، ZONE_A_KEY 09-15 |

---

## ۴) قالب‌های پیام (مهم‌ترین بخش) — سایت و کولر در یک خط؟

**پاسخ کوتاه:** بله در ۵ قالب از ۱۰ قالب، سایت و رویداد کولر در **یک خط/بلوک** می‌آیند. فقط در پیام‌های تیکتی `NIAN … Cooling Failure` سایت داخل `MBTS_XXXXX` است.

| # | قالب | regex | نمونه | n | چت‌ها |
|---|---|---|---|---|---|
| **F1** | `N4334 Cooler nasb she` — سایت‌های چندتایی + عملیات انگلیسی | `/\b([A-Z]{0,2}\d{3,5})\s+(?:Cooler\|Coler)\s+(?:nasb\|cange\|chenge\|change\|fault\|fa?u?lt\|salem\|nist\|nadare\|ok)/i` | «**N4334 Cooler nasb she** **T3517 Cooler nasb she**» / «**E6137 cooler nasb shod**» | 29 | 9 |
| **F2** | `مشخصات کولر فالتی 4334` / `کولر فالتی 3440` — «کولر (فالتی) + NNNN» | `/(?:کولر\|کوالر\|coler\|cooler)\s*(?:فالتی\|فالت\|fa?u?lt)\s*(\d{3,5})\|(?:فالتی\|فالت)\s*(?:کولر\|کوالر)\s*(\d{3,5})/i` | «مشخصات **کولر فالتی 4334** رو بفرستید» / «**فالتی کولر 3440**» / «**کولر 5305 فالت**» | 73 | 3 |
| **F3** | `کولر 3517` / `کولر ۱۳۶۱` / `کولر 1209` — «کولر + NNNN» (سایت) | `/(?:کولر\|کوالر\|cooler\|coler)\s*(\d{3,5})(?!\d)/i` | «بابت **کولر 3517**» / «**کولر ۱۳۶۱**رو با پیچ خودکار زدن» / «@mohsen_fathi96 **coler 1209** bgo bfrestan» | **119** | 13 |
| **F4** | `کولر اومده برا سایت 6830` — کولر و سایت در یک جمله | `/(?:کولر\|cooler\|coler).*?(?:سایت\|site)\s*\d{3,5}\|(?:سایت\|site)\s*\d{3,5}.*(?:کولر\|cooler\|coler)/i` | «کولر اومده برا **سایت 6830** نصب کردم» / «**سایت 4100** کولر فالت… تعویض شد» | 67 | 11 |
| **F5** | `کولر فالتی سایت NNNN ارسال شد انبار` — قالب انبار | `/(?:کولر\|کوالر\|cooler\|coler\|NAC)\s*(?:فالتی\|فالت\|fa?u?lt)?\s*(?:سایت\s*)?(\d{3,5})?.*(?:ارسال\|تحویل\|عودت).*(?:انبار\|اسنپ\|snap)/i` | «یک عدد **کولر نیان فالت سایت 1471 تحویل انبار** داده شد» / «**کولر 9095** با کولر 9087 جابه جا کردیم» | **247** | 4 |
| **F6** | `MBTS_T3585X,NIAN Battery Cooling Failure` — آلارم تیکتی | `/MBTS[_-]?([A-Z]{1,3}\d{3,5})X?\s*[,،]?\s*(?:NIAN\|Nian).{0,40}Cooling/i` | «NWG-OPS-TT-20251007-06602 **MBTS_T3585X,NIAN Battery Cooling Failure**» / «MBTS_T3498X, **NIAN Main Cooling Failure (VIP)**» | 75 | 14 |
| **F7** | `سایت tXXXX به آقای X نفر aec جهت ...` — Key Delivery | `/سایت\s*t?\s*(\d{3,5})\s*به\s*آقای\s*.{1,30}نفر\s*aec/` | «**سایت t2799 به آقای مهرداد نفر نفر aec** جهت عکسبرداری از دکل در ساعت۱۰:۳۰ تحویل…» | 5 | 1 (ZONE_Z) |
| **F8** | `CODE SITE : NNNN … ISSUES : cooler fault … ACTIVITY :` — گزارش روزانه | `/CODE SITE\s*:?\s*(\d{3,5}).{0,200}?(?:cooler\|cooler fault\|fan noise\|hitex\|temp)/is` | «🆔 CODE SITE : **1096** … 🔎 ISSUES : **cooler fault** 🔧 ACTIVITY : **change cooler 2000**» | 54 | 1 (activity_zon_D) |
| **F9** | `Code site:E7662 … Activity Type : cooling fault` — FLM | `/Code site\s*:?\s*([A-Za-z]{0,2}\d{3,5}).{0,200}?Activity Typ[^\n]*:?\s*[^\n]*cooling/i` | «🆔Code site:**E7662** … 🧰Activity Type : **cooling fault** 🏘City : varamin» | 5 | 1 (chat_226526641) |
| **F10** | `سایت ۴۳۰۱ … جهت سرویس کولر` / «در رک بازه کولرش فالته» — Key Delivery روزمره | `/(?:سایت\s*\d{3,5}).{0,60}(?:کولر\|cooler).{0,60}\|(?:کولر\|cooler).{0,40}(?:فالت\|خراب).{0,40}(?:در\|رک).{0,20}(?:باز)/i` | «سایت ۴۳۰۱برای آقای مجتبی نلطفی **جهت سرویس کولر** در ساعت 15,57 باز شد» / «**کولرش فالته** اونجا **در رکش بازه**» | ~40 | 6 |

### ۴-۱) نکات کلیدی قالب‌ها

1. **در F2/F3 عدد بعد از «کولر» همیشه کد سایت است** — نه سریال و نه توان. با شواهد: «کولر 3517» در Zone_D و هم‌زمان «N4334 Cooler nasb she **T3517** Cooler nasb she» → 3517 کد سایت T3517 است.
2. **در F3 عدد می‌تواند توان باشد**: «change cooler **2000**» (توان NAC2000)، «کولر **550** سایت 6913» (توان ۵۵۰W). تفکیک: اگر جمله «انبار/ارسال/فالتی» یا کد سایت همراه باشد → سایت؛ اگر «change/نصب/وات/w» کنارش باشد → توان/مدل.
3. **پیام‌های چندسایتی** (Zone_D): «N4334 Cooler nasb she **T3517** Cooler nasb she» → دو سایت در یک خط؛ باید با `matchAll` همه را استخراج کرد.
4. **AEC در قالب F7 پیمانکار است** و **هیچ‌جای کولر در آن نیامده** — برای گزارش کولر از F7 فقط برای تخصیص «کولر به پیمانکار AEC» استفاده شود.
5. **رک نیان کلید کو-تاگ است**: «کولر» + «نیان/NAC/NCR48U» در ۸۰٪ پیام‌های فنی با هم می‌آیند.

---

## ۵) جدول نهایی پیشنهادی — Site × Cooler State

### ۵-۱) وضعیت‌های ممکن

| وضعیت | تشخیص | منبع اصلی |
|---|---|---|
| `SALEM` (سالم) | `کولر سالم\|cooler salem\|کولر اوکی\|کولر خنک\|الارمش برطرف\|kولر سالم ولی high temp` | Zone_D، Picture_Zone_E |
| `FAULT` (خراب) | `cooler fault/fualt/faulte\|کولر فالت/فالتی/خراب/سوخته\|کولر خوابیده\|گاز نداره\|کمپرسور ایراد` | همه‌جا |
| `HIGHTEMP` (دمای بالا) | `تمپ شدید\|temp on\|high temp\|hightemp\|با تمپ دان\|تمپ داره` | Zone_D، Zone_A، R7_DS |
| `PENDING_NASB` (در انتظار نصب) | `Cooler nasb she\|کولر باید نصب شه\|اکسز.*کولر\|درخواست کولر\|cooler nasb konim` | Zone_D، Zone_A، eslamshahr |
| `CHANGED` (تعویض‌شده) | `Cooler change\|کولر تعویض شد\|Coler chenge\|cooler nasb shod (پس از فالت)` | Zone_D، Zone_Z |
| `RETURNED` (عودت انبار) | `کولر فالتی.*ارسال.*انبار\|تحویل اسنپ\|ارسال شد انبار` | R7_Return_Material |
| `NONE` (فاقد کولر) | `کولر نداره\|cooler nadare\|کولر موجود نیست\|cooler nist` | R7_DS، Picture_Zone_E |
| `CANCELED` (کنسل) | `کولر کنسله\|cooler cansel` | Zone_D |
| `VANDALIZED` | `کولر.*وندلیزم\|vandalism.*cooler` | R7_DS |
| `OFF` (خاموش دستی) | `کولر خاموش\|cooler off\|کولر خاموش کرده` | Zone_Z، ZONE_A_KEY |
| `HITEX_FAULT` (فن/هیتکس) | `هیتکس خرابه\|فن فالت\|fan noise\|fan fualt\|فن هیتکس سوخته` | hitex_clean، Zone_D |

### ۵-۲) شبه‌کد کامل

```js
// ============ 1) نرمال‌سازی ============
const FA = 0x06F0;
const norm = s => s
  .replace(/[۰-۹]/g, d => String(d.charCodeAt(0) - FA))
  .replace(/[٠-٩]/g, d => String(d.charCodeAt(0) - 0x0660))
  .replace(/[يى]/g, 'ی').replace(/ك/g, 'ک')
  .replace(/‌‏‎/g, '').replace(/\s+/g, ' ').trim();

// ============ 2) تشخیص پیام کولر ============
const COOLER_MSG = /کولر|کوالر|cooler|coler|kooler|coolr|هیتکس|hitex|heatex|\bNAC\b|NCR48U|\bACU\b|کولینگ|cooling/i;
const NIAN_COOLER = /نیان|nian|NAC|NCR48U/i;   // کو-تاگ مدل نیان

// ============ 3) استخراج سایت ============
const PREFIX = new Set(['t','e','n','b','h','d','dt','th','dl','lu','l','k','m','p','c','s','r','f','g','w','a','j','x','v','y','z','q','i','o','u']);
function extractSites(x) {
  const out = new Set();
  for (const m of x.matchAll(/\b([A-Za-z]{1,3})-?\s?(\d{3,5})\b/g))
    if (PREFIX.has(m[1].toLowerCase()) && m[2] !== '1400') out.add(m[1].toUpperCase() + m[2]);
  const mb = x.match(/MBTS[_-]?([A-Z]{1,3}\d{3,5})X?/i);      if (mb) out.add(mb[1].toUpperCase());
  const lead = x.match(/^\s*([A-Za-z]{0,2})(\d{3,4})(?![0-9])/); if (lead) out.add(lead[1].toUpperCase() + lead[2]);
  const after = x.match(/(?:سایت|site)\s*t?\s*-?([A-Za-z]{0,2}\d{3,5})/i);
  if (after && /^\d+$/.test(after[1])) out.add('T' + after[1]);   // «سایت 4100» → T4100 (پیش‌فرض T)
  return [...out];
}

// ============ 4) قالب‌های ترکیبی سایت+کولر ============
// F1: «N4334 Cooler nasb she» / «T2832 cooler faulte ?»
const F1 = /\b([A-Z]{0,2}\d{3,5})\s+(?:Cooler|Coler|Kooler|cooler|ACU)\s+(nasb|cange|chenge|change|fault|fa?u?lt|salem|nist|nadare|ok|damage|salm)/gi;
// F2: «کولر فالتی 4334» / «فالتی کولر 3440»
const F2 = /(?:کولر|کوالر|coler|cooler)\s*(?:فالتی|فالت|fa?u?lt)\s*(\d{3,5})|(?:فالتی|فالت)\s*(?:کولر|کوالر)\s*(\d{3,5})/gi;
// F3: «کولر 3517» / «کولر ۱۲۰۹»
const F3 = /(?:کولر|کوالر|cooler|coler)\s*(\d{3,5})(?!\d)/gi;
// F4: «کولر اومده برا سایت 6830»
const F4 = /(?:کولر|cooler|coler)[^.]{0,40}?(?:سایت|site)\s*t?\s*(\d{3,5})|(?:سایت|site)\s*t?\s*(\d{3,5})[^.]{0,40}?(?:کولر|cooler|coler)/gi;
// F5: «کولر نیان فالت سایت 1471 تحویل انبار»
const F5 = /(?:کولر|کوالر|cooler|coler|NAC)\s*(?:فالتی|فالت|fa?u?lt)?\s*(?:سایت\s*)?(\d{3,5})[^.]{0,40}(?:ارسال|تحویل|عودت)[^.]{0,20}(?:انبار|اسنپ|snap)/gi;
// F6: آلارم تیکتی
const F6 = /MBTS[_-]?([A-Z]{1,3}\d{3,5})X?\s*[,،]?\s*(?:NIAN|Nian)[^.\n]{0,60}Cooling/i;
// F8: activity_zon_D
const F8 = /CODE SITE\s*:?\s*(\d{3,5})[\s\S]{0,250}?(?:cooler|fan|hitex|temp|کولر)/i;

function extractCoolerEvents(msg) {
  const x = norm(msg.x);
  if (!COOLER_MSG.test(x)) return [];
  const sites = extractSites(x);
  const events = [];
  const push = (site, action, m) => events.push({ site, action, chat: msg.f, ts: msg.d });

  for (const m of x.matchAll(F1)) { const a = m[2].toLowerCase();
    push(m[1].toUpperCase(), a.startsWith('nasb') ? 'NASB' : a.startsWith('salem')||a==='ok' ? 'SALEM'
      : a==='nist'||a==='nadare' ? 'NONE' : 'FAULT', m[0]); }

  const seen = new Set(events.map(e => e.site + '|' + e.action));
  for (const m of x.matchAll(F2)) { const s = m[1] || m[2];
    if (!seen.has(s + '|FAULT')) { push(s, 'FAULT', m[0]); seen.add(s + '|FAULT'); } }
  for (const m of x.matchAll(F3)) {
    const n = m[1]; if (!seen.has(n + '|FAULT') && !seen.has(n + '|NASB')) {
      // F3 مبهم: با نشانه‌های بافت تصمیم بگیر
      const action = /nasb|نصب/i.test(x) ? 'NASB' : /انبار|ارسال|تعمیر/i.test(x) ? 'RETURNED'
        : /فالت|fault|خراب|تمپ|temp/i.test(x) ? 'FAULT' : 'MENTION';
      push(n, action, m[0]); } }
  for (const m of x.matchAll(F5)) push(m[1], 'RETURNED', m[0]);
  for (const m of x.matchAll(F6)) push(m[1].toUpperCase(), 'ALARM_COOLING_FAILURE', m[0]);
  for (const m of x.matchAll(F8)) push(m[1], 'FIELD_REPORT', m[0]);
  if (events.length === 0) for (const s of sites) push(s, 'MENTION', x.slice(0, 80));
  return events;
}

// ============ 5) جدول نهایی: Site × آخرین وضعیت ============
function buildCoolerTable(messages) {
  const table = new Map(); // site -> {state, model, date, samples[], evidence}
  for (const msg of messages) {
    for (const ev of extractCoolerEvents(msg)) {
      const prev = table.get(ev.site) || { site: ev.site, state: 'UNKNOWN', model: null, date: null, samples: [], faults: 0, nasbs: 0 };
      // مدل
      if (NIAN_COOLER.test(norm(msg.x))) {
        const w = norm(msg.x).match(/(?:NAC|کولر|cooler)\s*(\d{3,4})\s*(?:w|وات)?/i);
        if (w && /550|1250|2000|3000|90/.test(w[1])) prev.model = 'NIAN-' + w[1];
        else prev.model = prev.model || 'NIAN';
      }
      // ترتیب زمانی: جدیدترین پیام برنده است
      if (!prev.date || msg.d >= prev.date) {
        prev.date = msg.d;
        if (ev.action === 'NASB' || ev.action === 'CHANGED') { prev.state = 'CHANGED_OR_INSTALLED'; prev.nasbs++; }
        else if (ev.action === 'SALEM') prev.state = 'SALEM';
        else if (ev.action === 'NONE') prev.state = 'NONE';
        else if (ev.action === 'RETURNED') prev.state = 'PENDING_INSTALL';
        else if (ev.action === 'FAULT') { prev.state = 'FAULT'; prev.faults++; }
        else if (ev.action === 'ALARM_COOLING_FAILURE') prev.state = 'FAULT_ALARM';
      }
      if (/تمپ شدید|temp on|high ?temp|hightemp/i.test(norm(msg.x))) prev.state += '+HIGHTEMP';
      if (/کنسل|cansel|cancel/i.test(norm(msg.x))) prev.state = 'CANCELED';
      if (/هیتکس|hitex|fan noise|fan fualt|فن فالت/i.test(norm(msg.x)) && prev.state === 'FAULT') prev.state = 'FAULT_HITEX_FAN';
      if (prev.samples.length < 3) prev.samples.push(`${new Date(msg.d+3.5*3600000).toISOString().slice(0,10)} | ${norm(msg.x).slice(0,120)}`);
      table.set(ev.site, prev);
    }
  }
  return [...table.values()].sort((a,b) => (b.faults - a.faults));
}
```

### ۵-۳) نمونهٔ خروجی جدول (استخراج‌شده از دادهٔ واقعی)

| Site | State | Model | تاریخ آخرین رویداد | نمونه پیام |
|---|---|---|---|---|
| N4334 | CHANGED_OR_INSTALLED | — | 2026-10-01 | «N4334 Cooler nasb she T3517 Cooler nasb she» |
| T3517 | CHANGED_OR_INSTALLED | — | 2026-10-02 | «man hamahng mikonam kargaro… 3517 va 4334» (کولر فالتی 4334، تعویض 3517) |
| T1209 | CHANGED_OR_INSTALLED | — | 2026-10-02 | «کولر جدید ۱۲۰۹ نصب شد» (قبلاً: «کانسل کنید»، «اکسز اوکیه؟») |
| E6137 | CHANGED_OR_INSTALLED | — | 2026-05-21 | «E6137 cooler nasb shod» |
| E5592 | PENDING_INSTALL→CHANGED | NAC1250D-A/03 | 2026-08-24 | «نصب کولر سایت 5592 هزینه کارگر… ۵ طبقه بالا بردن کولر یک میلیون تومان» |
| T4100 | CHANGED_OR_INSTALLED | — | 2026-08-06 | «سایت 4100 کولر فالت… تعویض شد کولر جدید بسته شد در حال تست» |
| T6786 | FAULT | NIAN | 2026-08-18 | «6786 کولر فالت» + قبلاً «کولر بالای رک نیان نیاز به سرویس دارد» |
| T6751 | CHANGED_OR_INSTALLED | NIAN | 2026-09-19 | «کولر نیان تعویض شد NCR تعویض شد FLAT PACK تعویض شد… فن کولر راه اندازی مجدد شد» |
| T6582 | FAULT | NIAN | 2026-09-28 | «کولر نیان فالت… یک عدد فن external رک ۶۱۰۲ موجود نیست» |
| T1361 | FAULT+HIGHTEMP | — | 2026-09-22 | «من دارم میرم 1361 اونم تمپ داره» + «کوالر 1361 رو با پیچ خودکار زدن… کولر جدید رو هم سوراخ کنن» |
| T3641 | FAULT | NIAN | 2026-08-08 | «NCR فالت / فن External کولر باتری ها فالت / دو عدد از باتری ها lock شده» |
| T4096→N4096 | FAULT | NIAN | 2026-09-29 | «هردو کولر فالت / NCU FAULT / کولر باتری ها موجود نیست» |
| T5310 | FAULT | — | 2026-05-22 | «کولر فالت شده ولی روشن گذاشتمش تا یکم باد به داخل رک بفرسته… در رک هم نیمه بازه» |
| T1818 | CHANGED_OR_INSTALLED | — | 2026-08-11 | «1818 کولر تعویض شد» (قبلاً: «کولر فالتی ۱۸۱۸ ارسال شد به انبار») |
| T4055/E6707 | FAULT | — | 2026-08-20 | «E6707 کولر بالا فالت قبلا درخواست زدیم» |
| E5310 | PENDING_INSTALL | — | 2026-08-23 | «e5310 cooler nasb shod ?» |
| E5301 | CHANGED_OR_INSTALLED | — | 2026-08-20 | «E5301 کولر خوابیده فرستادن بعید میدونم جواب بده» → «E5301 کولر نصب شد» |
| T1421 | FAULT | NIAN-90 | 2026-08-07 | «t1421 2ta NCR fault dare Cooler nian 90 nist… Cooler nian 90 va eltek shoste shod» |
| E5592 (اسنپ) | PENDING_INSTALL | NAC1250D-A/03 | 2026-08-19 | «NAC1250D-A/03 9700784 1 E5592 … tahvil bgirid» |

### ۵-۴) هیستوگرام سایت‌های دارای پیام کولر (Top)

سایت‌های پرتکرار: `T1181، T1576، T1361، T3517، N4334، E6137، T1209، T5592، T6751، T6786، T6582، E5310، E5301، T1421، T4100، H9077، H8033، T1688، T1818، T5310، T4096، E5224، T4219، T1344، E5243، E6668، T3778، T3709، E4002، T4002`

---

## ۶) قواعد تجمیع و تداخل

1. **اولویت زمانی**: آخرین پیام برنده است (مثلاً E5301: «خوابیده فرستادن» → «نصب شد» = وضعیت نهایی `CHANGED_OR_INSTALLED`).
2. **کو-تاگ اجباری تمپ**: هر پیام کولر فالت که «تمپ شدید/temp on» دارد، هم `FAULT` و هم `HIGHTEMP` ثبت شود — چون در گزارش عملیاتی این دو معادل یک حادثه‌اند («کولرش فالت تمپ میاره»).
3. **در رک باز**: نشانهٔ عملیاتی «کولر فالت» است — نگهبان‌ها در را باز می‌گذارند تا تمپ نیاید؛ اگر پیام «در رک بسته بود + کولر فالت + تمپ شدید» دیدی یعنی حادثهٔ جدی (یونیت فالت می‌شود).
4. **«کولر کنسله»** = درخواست تعویض/نصب لغو شده؛ وضعیت را `CANCELED` بگذار ولی تاریخچه را نگه دار.
5. **فن/هیتکس جدا ثبت شود**: `fan_noise` (شکایت مالک → احتمال خاموشی اجباری)، `fan_fault` (تعویض فن)، `hitex_clean` (سرویس دوره‌ای). این‌ها روی خود کولر اثر دارند ولی «تعویض کولر» نیستند.
6. **مدل را از آخرین ذکر بردار**: «کولر ۲۰۰۰» یعنی NAC2000؛ «نیان ۹۰» یعنی مدل ۹۰؛ اگر فقط «کولر نیان» بدون عدد، مدل = `NIAN` (نامشخص).

## ۷) نکات پیت‌فال (اشتباهات رایج)

| پیت‌فال | توضیح |
|---|---|
| ❌ AEC را نوع کولر فرض کنی | AEC = پیمانکار (نفر aec / AEC Modernization). کولر AEC وجود ندارد. |
| ❌ فلت‌پک را کولر فرض کنی | Flat Pack = رکتیفایر Eltek (3000W)؛ در پیام‌های انبار همراه کولر می‌آید ولی قلم جدا است. |
| ❌ «کولر ۵۵۰» را سایت بگیری | ۵۵۰ و ۲۰۰۰ و ۱۲۵۰ توان (وات) است وقتی با «وات/w/change» می‌آید؛ ولی «کولر 3517/1361/1209/4334» کد سایت است (با شواهد F1). |
| ❌ تمپ را فقط رویداد جدا بگیری | «تمپ» و «کولر فالت» در R7 تقریباً همیشه یک حادثه‌اند؛ جدا شمردن، دوبار گزارش می‌سازد. |
| ❌ «در رک باز» را نقص فنی بگیری | در بافت ایرانسل، «در باز» **اقدام حفاظتی** است وقتی کولر فالت است (جلوگیری از تمپ). |
| ❌ ارقام فارسی را فراموش کنی | «کولر ۱۳۶۱» / «مشخصات کولر فالتی ۴۳۳۴» — بدون نرمال‌سازی از دست می‌روند. |
| ❌ «Nian 90» را توان بگیری | «نیان ۹۰» = مدل رک/کولر ۹۰ (نه ۹۰ وات). «کولر ۵۵۰w» روی «Niyan 90» ساپورت نمی‌شود (شاهد مستقیم). |
| ❌ «ACU» را پیمانکار بگیری | ACU = یونیت کولر/سرمایش نیان («التک ACU نداره» = ACU متعلق به نیان است). |

## ۸) چت‌های طلایی برای پرس‌وجوهای آیندهٔ کولر

| chatId | چرا طلایی |
|---|---|
| 1007814392 (Zone_D) | غنی‌ترین پیام‌های فارسی رویدادمحور: سوخته/فالت/ریست/هیتکس/تعویض/کنسل |
| 1737503770 (R7_Return_Material) | الگوی استاندارد انبار: «کولر (فالتی) NNNN ارسال شد انبار» — ۲۴۷ مورد |
| 729401255 (hitex_clean) | قالب دقیق سرویس: «NNNN هیتکس شسته شد / N فن فالت/سالم» |
| 1365646822 (Picture_Zone_E) | گزارش چندبندی After/Before با کولر نیان/ACU/هیتکس |
| 1986682312 (eslamshahr) | چرخهٔ کامل نصب: درخواست→اکسز→نصب→تست |
| 1206812704 (R7_DS_Follow_UP) | آلارم‌های VIP نیان Cooling Failure + وضعیت روزانه |
| 1097166168 (mehrdad_aslani) | کدهای فنی PR: NAC3000D/NAC2000D/NAC550/NCR48U/BPD104105 |
| 2145164056 (Zone_Z) | نصب‌های واقعی + لیست سریال انبار NAC1250D |
| 1703520267 (Zone_A) | چرخهٔ تعویض ۱۲۰۹/۵۵۲۰ + کمپرسور/گاز |
| 351194861 (picture_of_site_zone_C) | مدل‌های توان: 550w/2000w + Niyan 90 |
