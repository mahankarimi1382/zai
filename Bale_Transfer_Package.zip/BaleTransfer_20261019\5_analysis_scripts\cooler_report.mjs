// ===== Cooler (کولر نیان) report for Irancell R7 sites =====
// Rules from cooler_rules.md: NIAN rack coolers, NAC* models, AEC=contractor
import fs from "node:fs";
import path from "node:path";

const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const OUT    = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_analysis";

const PRE = (s) => String(s)
  .replace(/[۰-۹]/g, d => String(d.charCodeAt(0) - 0x06F0))
  .replace(/[٠-٩]/g, d => String(d.charCodeAt(0) - 0x0660))
  .replace(/[يى]/g, "ی").replace(/[كک]/g, "ک").replace(/[أإآ]/g, "ا").replace(/[ۀة]/g, "ه")
  .replace(/[ً-ْ]/g, "").replace(/[-‏‎]/g, " ")
  .replace(/\s+/g, " ").toLowerCase().trim();

const COOLER_KW = /(کولر|کوالر|cooler|koler|coler|کولینگ|cooling|hitex|هیتکس|heat\s?exchanger|نیان|nian|acu\b)/;

// --- model detection ---
const MODELS = [
  ["NAC3000D", /nac\s?3000|3000d/],
  ["NAC2000D", /nac\s?2000|2000d/],
  ["NAC1250D", /nac\s?1250|1250d|1250/],
  ["NAC550", /nac\s?550|کولر\s?550/],
  ["NCR48U", /ncr\s?48u|48u/],
  ["BPD104105/2", /bpd\s?104105/],
  ["نیان ۹۰", /نیان\s?۹۰|نیان\s?90/],
  ["NIAN", /\bnian\b|نیان/],
];
// power spec mentioned with cooler (not model): "کولر ۲۰۰۰ وات", "کولر 550"
const POWER_SPEC = /(کولر|cooler|coler)[^\d]{0,6}(\d{3,4})\s*(?:w|وات|watt)/;

// --- states (priority order matters: later checks refine) ---
const STATES = {
  "دمای بالا": /(تمپ|temp|دما|حرارت)[^.]{0,30}(بالا|زیاد|شدید|آلارم|alarm|فالت)|high\s?temp/,
  "خراب": /(کولر|کوالر|cooler|coler|کولینگ|cooling)[^.]{0,25}(فالت|خراب|سوخته|fail|fault|failed|از\s?کار|خاموش)|(فالت|خراب|سوخته|fail|fault)[^.]{0,20}(کولر|کوالر|cooler|coler|کولینگ)/,
  "فن خراب": /(فن|fan)[^.]{0,25}(خراب|فالت|fail|fault|alarm)|(کولر|cooler)[^.]{0,20}فن/,
  "هیتکس": /(هیتکس|hitex|heat\s?exchanger)/,
  "نصب جدید": /(cooler|coler|کولر|کوالر)[^.]{0,20}(nasb|نصب|نصب\s?شد)|(nasb\s?she|cooler\s?nasb|coler\s?chenge|cooler\s?change|تعویض\s?کولر|کولر\s?جدید)/,
  "تعویض": /(cooler|coler|کولر|کوالر)[^.]{0,15}(change|chenge|cange|تعویض)|تعویض[^.]{0,10}(کولر|cooler)/,
  "ارسال به انبار": /(کولر|کوالر|cooler|coler)[^.]{0,30}(انبار|ارسال\s?شد|تحویل\s?انبار)|انبار[^.]{0,20}(کولر|cooler)/,
  "رفع شد": /(کولر|کوالر|cooler|coler)[^.]{0,30}(درست\s?شد|رفع|ok\s?شد|برطرف|ریست\s?کردم|recover)|(رفع|برطرف)[^.]{0,15}(کولر|cooler)/,
  "کنسل": /(کولر|کوالر|cooler|coler)[^.]{0,15}(کنسل|cancel)|(cancel|cansel)[^.]{0,10}(کولر|cooler)/,
  "سالم": /(کولر|کوالر|cooler|coler)[^.]{0,20}(سالم|ok\b|اوکی|نرمال|خنک)|سالم[^.]{0,10}(کولر|cooler)/,
  "سرقت/تخریب": /(کولر|cooler)[^.]{0,20}(دزد|سرقت|vandal|شکسته|تخریب)/,
};
// event classifier for timeline
const EVT = [
  ["خرابی", /(فالت|خراب|سوخته|fail|fault|failed)/],
  ["دمای بالا", /(تمپ|temp|دما)[^.]{0,30}(بالا|زیاد|شدید|آلارم|alarm)/],
  ["تعویض/نصب", /(nasb|نصب|change|chenge|cange|تعویض|کولر\s?جدید)/],
  ["برگشت به انبار", /(انبار|ارسال\s?شد|تحویل\s?انبار|مرجوع)/],
  ["رفع/ریست", /(درست\s?شد|رفع|برطرف|ریست|recover|ok\s?شد)/],
  ["کنسل", /(کنسل|cancel|cansel)/],
  ["درخواست", /(درخواست|نیاز|بخوایم|باید|سفارش)/],
];

const isFile = (x) => !x || x === "[object Object]";
const d2 = (ms) => new Date(ms + 3.5 * 3600000).toISOString().slice(0, 10);

// site extraction (compact version of validated regexes)
const siteGlueRe = /\b([a-z]{0,2}\d{3,5})\b/g;
const siteWordRe = /(?:کولر|کوالر|cooler|coler|فالتی|فالت|nasb|cange|chenge|change|مشخصات)\s*(?:فالتی|فالت|fault)?\s*([a-z]{0,2}\d{3,5})/gi;
const mbtsRe = /mbts[_-]?([a-z]{0,2}\d{3,5})x?/gi;
const KNOWN_PREFIXES = /^(t|e|n|b|h|d|l|f|g|k|c|m|s|v|w|a|r|j|x|y|dt|lt|lut|dl|dlut|dd|th|tu|tn|te|teb|ter|kr|tr|ha|tw|pk|lt|gdt|ldt)\d{3,5}$/i;
function findCoolerSites(t) {
  const out = new Set(); let m;
  siteWordRe.lastIndex = 0;
  while ((m = siteWordRe.exec(t))) {
    const code = m[1].toUpperCase();
    if (/^\d{4,5}$/.test(code) || KNOWN_PREFIXES.test(code)) out.add(code);
  }
  mbtsRe.lastIndex = 0;
  while ((m = mbtsRe.exec(t))) out.add(m[1].toUpperCase());
  // "کولر 3517" / "مشخصات کولر فالتی 4334" handled by siteWordRe
  if (!out.size) {
    // glued: "N4334 Cooler nasb she"
    const glue = /\b([a-z]{1,3}\d{3,5})\s+(?:cooler|coler|کولر|کوالر)\b/gi;
    while ((m = glue.exec(t))) { const c = m[1].toUpperCase(); if (KNOWN_PREFIXES.test(c)) out.add(c); }
  }
  return [...out];
}

// ===== collect =====
const rows = [];          // all cooler mentions
let scanned = 0;
for (const f of fs.readdirSync(MERGED).filter(x => x.endsWith(".json"))) {
  const chat = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  for (const m of JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"))) {
    scanned++;
    const raw = (m.x || "").replace(/\s+/g, " ").trim();
    if (isFile(raw) || raw.length < 5) continue;
    const t = PRE(raw);
    if (!COOLER_KW.test(t)) continue;
    // exclude pure AEC-contractor messages (AEC alone is not a cooler event)
    const isAecOnly = /\baec\b/.test(t) && !/(کولر|cooler|coler|کوالر|کولینگ|cooling|hitex|هیتکس)/.test(t);
    const sites = findCoolerSites(t);
    const models = MODELS.filter(([, re]) => re.test(t)).map(([k]) => k);
    const states = Object.entries(STATES).filter(([, re]) => re.test(t)).map(([k]) => k);
    const events = EVT.filter(([, re]) => re.test(t)).map(([k]) => k);
    const pw = POWER_SPEC.exec(t);
    rows.push({ date: d2(m.d), t: m.d, sites: sites.join("|"), models: models.join("|"), states: states.join("|"), events: events.join("|"), power: pw ? pw[2] : "", aecOnly: isAecOnly ? 1 : 0, chat, text: raw.slice(0, 160) });
  }
}
console.log("scanned:", scanned, "| cooler mentions:", rows.length, "| with sites:", rows.filter(r => r.sites).length);

const q = (v) => `"${String(v ?? "").replace(/"/g, "'").replace(/[\r\n]+/g, " ")}"`;
const B = "\uFEFF";
const write = (f, head, rws) => { fs.writeFileSync(path.join(OUT, f), B + head.map(q).join(",") + "\n" + rws.map(r => head.map(h => q(r[h])).join(",")).join("\n") + "\n", "utf8"); console.log("wrote", f, rws.length); };

// ===== 27a: per-site cooler status (last state wins) =====
const siteAgg = new Map();
for (const r of rows) {
  if (!r.sites) continue;
  for (const s of r.sites.split("|")) {
    if (!siteAgg.has(s)) siteAgg.set(s, { site: s, lastDate: r.date, lastT: r.t, states: new Map(), models: new Set(), events: new Map(), first: r.date, samples: [], msgs: 0 });
    const a = siteAgg.get(s);
    a.msgs++;
    for (const st of r.states.split("|").filter(Boolean)) a.states.set(st, (a.states.get(st) || 0) + 1);
    for (const mo of r.models.split("|").filter(Boolean)) a.models.add(mo);
    for (const ev of r.events.split("|").filter(Boolean)) a.events.set(ev, (a.events.get(ev) || 0) + 1);
    if (r.t > a.lastT) { a.lastT = r.t; a.lastDate = r.date; a.lastStates = r.states; }
    if (r.date < a.first) a.first = r.date;
    if (a.samples.length < 3) a.samples.push(r.text);
  }
}
const statusOf = (a) => {
  const ls = (a.lastStates || "").split("|");
  if (ls.includes("کنسل")) return "کنسل شده";
  if (ls.includes("سالم")) return "سالم";
  if (ls.includes("رفع شد")) return "رفع شده";
  if (ls.includes("تعویض") || ls.includes("نصب جدید")) return "تعویض/نصب شده";
  if (ls.includes("دمای بالا")) return "دمای بالا";
  if (ls.includes("خراب") || ls.includes("فن خراب")) return "خراب";
  if (ls.includes("ارسال به انبار")) return "به انبار برگشته";
  // fallback: most frequent
  const best = [...a.states.entries()].sort((x, y) => y[1] - x[1])[0];
  return best ? best[0] : "نامشخص";
};
write("27_cooler_by_site.csv",
  ["site","status","models","fault_count","temp_alarm_count","changed_count","returned_count","fixed_count","first_seen","last_event","messages","sample"],
  [...siteAgg.values()].map(a => ({
    site: a.site, status: statusOf(a), models: [...a.models].join("|"),
    fault_count: (a.states.get("خراب") || 0) + (a.states.get("فن خراب") || 0),
    temp_alarm_count: a.states.get("دمای بالا") || 0,
    changed_count: (a.states.get("تعویض") || 0) + (a.states.get("نصب جدید") || 0),
    returned_count: a.states.get("ارسال به انبار") || 0,
    fixed_count: a.states.get("رفع شد") || 0,
    first_seen: a.first, last_event: a.lastDate, messages: a.msgs, sample: a.samples.join(" || "),
  })).sort((x, y) => (y.fault_count + y.temp_alarm_count) - (x.fault_count + x.temp_alarm_count)));

// ===== 27b: cooler event timeline =====
const tl = [];
for (const r of rows) {
  if (!r.events) continue;
  const site = (r.sites || "").split("|")[0] || "";
  for (const ev of r.events.split("|")) tl.push({ date: r.date, site, model: r.models.split("|")[0] || "", event: ev, chat: r.chat, text: r.text });
}
write("27b_cooler_events.csv", ["date","site","model","event","chat","message"], tl);

// ===== 27c: cooler model stats =====
const modelAgg = new Map();
for (const r of rows) {
  for (const mo of r.models.split("|").filter(Boolean)) {
    if (!modelAgg.has(mo)) modelAgg.set(mo, { model: mo, mentions: 0, sites: new Set(), first: r.date, last: r.date });
    const a = modelAgg.get(mo); a.mentions++;
    for (const s of r.sites.split("|").filter(Boolean)) a.sites.add(s);
    if (r.date < a.first) a.first = r.date;
    if (r.date > a.last) a.last = r.date;
  }
}
write("27c_cooler_models.csv", ["cooler_model","mentions","sites_count","first_seen","last_seen"],
  [...modelAgg.values()].sort((a, b) => b.mentions - a.mentions).map(a => ({ cooler_model: a.model, mentions: a.mentions, sites_count: a.sites.size, first_seen: a.first, last_seen: a.last })));

// ===== 27d: summary stats =====
const byState = {};
for (const r of rows) for (const st of r.states.split("|").filter(Boolean)) byState[st] = (byState[st] || 0) + 1;
const byEvent = {};
for (const r of rows) for (const ev of r.events.split("|").filter(Boolean)) byEvent[ev] = (byEvent[ev] || 0) + 1;
write("27d_cooler_stats.csv", ["metric","count"], [
  { metric: "کل پیام‌های کولر", count: rows.length },
  { metric: "پیام با کد سایت", count: rows.filter(r => r.sites).length },
  { metric: "سایت‌های درگیر کولر", count: siteAgg.size },
  ...Object.entries(byState).map(([k, v]) => ({ metric: "وضعیت: " + k, count: v })),
  ...Object.entries(byEvent).map(([k, v]) => ({ metric: "رویداد: " + k, count: v })),
]);

console.log(`\ncooler sites: ${siteAgg.size} | models: ${modelAgg.size}`);
const sts = {};
for (const a of siteAgg.values()) { const s = statusOf(a); sts[s] = (sts[s] || 0) + 1; }
console.log("site statuses:", JSON.stringify(sts));
console.log("models:", [...modelAgg.entries()].sort((a,b)=>b[1].mentions-a[1].mentions).map(([k,v])=>`${k}(${v.mentions})`).join(" "));
console.log("top faulty cooler sites:");
for (const a of [...siteAgg.values()].sort((x, y) => ((y.states.get("خراب")||0)+(y.states.get("فن خراب")||0)+(y.states.get("دمای بالا")||0)) - ((x.states.get("خراب")||0)+(x.states.get("فن خراب")||0)+(x.states.get("دمای بالا")||0))).slice(0, 10)) {
  console.log(`  ${a.site}\t${statusOf(a)}\tfault=${a.states.get("خراب")||0}\ttemp=${a.states.get("دمای بالا")||0}\tmodels=${[...a.models].join(",")}`);
}