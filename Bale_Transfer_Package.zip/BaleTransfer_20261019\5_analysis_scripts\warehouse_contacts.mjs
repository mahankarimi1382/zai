// Precise: find phone numbers that appear in warehouse-action messages as the
// recipient/subject of the action (not in team-roster blocks).
import fs from "node:fs";
import path from "node:path";

const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const OLD    = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_data";
const users = new Map();
const uf = path.join(OLD, "_users.json");
if (fs.existsSync(uf)) for (const u of JSON.parse(fs.readFileSync(uf, "utf8"))) users.set(String(u.id), { name: u.name, phone: u.phone || "" });
const norm = (s) => String(s).toLowerCase().replace(/[\s._\-]/g, "");
const nameToUid = new Map();
for (const [id, v] of users) if (v.name) nameToUid.set(norm(v.name), id);

const phoneRe = /(?:\+?98|0098|0)?9\d{9}/g;
const fmt = (m) => { let d = m.replace(/\D/g, ""); if (d.startsWith("0098")) d = d.slice(4); else if (d.startsWith("98")) d = d.slice(2); else if (d.startsWith("0")) d = d.slice(1); return "0" + d; };

// Roster pattern: 3+ phones listed together = team contact list, not a person
const rosterLike = (text) => (text.match(phoneRe)?.length || 0) >= 3;

// Strong signals that the phone belongs to the person doing the warehouse work
const SELF = /(انباردار|مسئول\s*انبار|انبار\s*من|رئیس\s*انبار)/;
const HAND = /(شماره|تماس|همراه|موبایل|tel|phone|mobile|contact)/;
const ACTION = /(تحویل|ارسال|دریافت|انبار|مرجوع|برگشت|اسنپ|فرستاد|تحریک|گرفت)/i;

const WAREHOUSE = ["1737503770","517632817","785878952","1729376405","1918042926","2061599862","1048230922","786128402","8339623","1206812704"];
const results = new Map(); // phone -> {phone, name, roles, chats, hits, sample}
const files = fs.readdirSync(MERGED).filter(f => f.endsWith(".json"));

for (const f of files) {
  const id = f.split("_")[0];
  if (!WAREHOUSE.includes(id)) continue;
  const chat = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"))
    .filter(m => m.x && m.x !== "[object Object]");
  for (let i = 0; i < msgs.length; i++) {
    const raw = msgs[i].x.replace(/\s+/g, " ").trim();
    if (!ACTION.test(raw)) continue;
    if (rosterLike(raw)) continue;             // team roster blocks
    const sender = users.get(String(msgs[i].u));
    const phones = (raw.match(phoneRe) || []).map(fmt).filter(p => /^09\d{9}$/.test(p));
    if (!phones.length) continue;

    // Which name goes with the phone? check the same message for "<name> <phone>" or "به <name> ... <phone>"
    let name = null;
    for (const [nn, uid] of nameToUid) {
      if (nn.length >= 4 && norm(raw).includes(nn)) { name = users.get(uid).name; break; }
    }
    if (!name && sender?.name && SELF.test(raw)) name = sender.name;
    // skip generic A/B/C codes and obviously non-person contexts
    if (/site\s?code|موقعیت|کد\s?سایت|UTM|GPS/i.test(raw) && !name) continue;

    const role = SELF.test(raw) ? "انباردار/مسئول انبار"
      : HAND.test(raw) ? "دارای شماره تماس در اقدام انباری"
      : (sender?.name && raw.includes(sender.name)) ? "مخاطب اقدام انباری" : "ذکرشده در پیام انباری";

    for (const p of phones) {
      const k = p + "|" + (name || "?");
      if (!results.has(k)) results.set(k, { phone: p, name, role, chats: new Set(), hits: 0, sample: "" });
      const r = results.get(k);
      r.hits++; r.chats.add(chat);
      if (!r.sample) r.sample = raw.slice(0, 200);
      // upgrade role if a stronger signal appears later
      if (role === "انباردار/مسئول انبار") r.role = role;
    }
  }
}

const list = [...results.values()].sort((a, b) => b.hits - a.hits);
console.log("=== PHONE ↔ WAREHOUSE PERSON ===");
for (const r of list) {
  console.log(`${r.phone} | ${r.name || "(نام نامشخص)"} | ${r.role} | hits=${r.hits} | ${[...r.chats].join(", ")}`);
}
console.log("total:", list.length);
fs.writeFileSync("C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_analysis\\29_warehouse_contacts.csv",
  "\uFEFF" + ["phone","name","role","hits","chats","sample"].map(x => `"${x}"`).join(",") + "\n" +
  list.map(r => [r.phone, r.name || "", r.role, r.hits, [...r.chats].join("|"), r.sample.replace(/[";\r\n]/g, " ")].map(v => `"${String(v).replace(/"/g, "'")}"`).join(",")).join("\n") + "\n", "utf8");