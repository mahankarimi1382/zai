// ===== آماری: Unit model stats + consumables + battery + planning report =====
// Builds countable, planning-ready tables from merged Bale chat data.
import fs from "node:fs";
import path from "node:path";

const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const OUT    = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_analysis";
fs.mkdirSync(OUT, { recursive: true });

const PRE = (s) => String(s)
  .replace(/[۰-۹]/g, d => String(d.charCodeAt(0) - 0x06F0))
  .replace(/[٠-٩]/g, d => String(d.charCodeAt(0) - 0x0660))
  .replace(/[يى]/g, "ی").replace(/[كک]/g, "ک").replace(/[أإآ]/g, "ا").replace(/[ۀة]/g, "ه")
  .replace(/[ً-ْ]/g, "").replace(/[-‏‎]/g, " ")
  .replace(/\s+/g, " ").toLowerCase().trim();

// --- site codes ---
const SITE_PREFIXES = new Set(["t","e","n","b","h","d","l","f","g","k","c","m","s","v","w","a","r","j","x","y",
  "dt","lt","lut","dl","dlut","dd","th","tu","tn","te","teb","ter","kr","tr","ha","haye","tw","pk"]);
const NOT_SITE = /(good|bad|fault|falt|down|add|rem|req|ok|new|old|noa|site|cell|unit|pack|esm|adu|batty|batt|battery|hub|mains|vol|amp)/;
const isSitePrefix = (p) => {
  const w = String(p).toLowerCase().replace(/\s|-/g, "");
  if (SITE_PREFIXES.has(w)) return true;
  if (NOT_SITE.test(w)) return false;
  return /^[a-z]{2,5}$/.test(w) && /[tlscbrd]$/.test(w);
};
const siteRe = /([a-z]{1,5})\s?-?\s?(\d{4})\b/g;
function findSites(t) {
  const out = new Set(); let m; siteRe.lastIndex = 0;
  while ((m = siteRe.exec(t))) {
    if (m[1] && (!isSitePrefix(m[1]) || UNIT_SET.has(m[1]))) continue;
    out.add((m[1] ? m[1].toUpperCase() : "") + m[2]);
  }
  return [...out];
}

// --- unit tokens ---
const UNIT_WORDS = ["ncr","cr","psu","vpsu","upsu","pbc","fpfc","rru","rrh","rrus","rus","rusb","mmu","dug","duw","dus","dub","ubbp","npu","ncu","bbu","fbba","rbs","bb","sfp","sfb","odu","epb","fsmfa","isv3","fiber","fibr","lan","jumper","cooler","koler","coler","fan","tcu","fcu","flatpack","smartpack","anten","antn","gps","fuse","fiuz","batt","batry","esm","ladder","switch","swich","sowiche","relay","umpt","pfu","scu"];
const UNIT_SET = new Set(UNIT_WORDS);
const UNIT_TOKENS = new RegExp("\\b(" + UNIT_WORDS.join("|") + ")\\b", "g");

const FAMILY = [
  ["رادیویی", /\b(rru|rrh|rrus|rus|rusb?|mmu|dug|duw|dus|dub|ubbp|npu|ncu|bbu|fbba|rbs|bb|scu)\b/],
  ["برق", /\b(ncr|psu|vpsu|upsu|pbc|fpfc)\b/],
  ["اپتیک", /\b(sfp|sfb|odu|epb|fsmfa|isv3|fiber|fibr|lan|jumper)\b/],
  ["مکانیکی", /\b(cooler|koler|coler|fan|tcu|fcu|flatpack|smartpack|anten|antn|gps)\b/],
  ["مصرفی", /\b(fuse|fiuz|batt|batry|esm|ladder)\b/],
  ["انتقال", /\b(umpt|relay|switch|swich|sowiche|pfu)\b/],
];
const fam = (u) => { for (const [n, re] of FAMILY) if (re.test(u)) return n; return "متفرقه"; };
const CONSUMABLE = /\b(fuse|fiuz|batt|batry|esm|ladder|jumper|fibr|fiber|lan)\b/;

// --- event detection ---
const EV = {
  FAULT: [/\b(fault|faulty|falte|fualt|falt|down|damage|damaged|burn|burnt|broken|trip|busted|bad)\b/,
    /(فالت|فالتی|خراب|خرابی|سوخته|شکسته|دمیج|آب خورده|قطع|پرید|تریپ|ایراد|معیوب)/],
  REQUEST: [/\b(request|need|required|order|shortage|pending|waiting)\b/,
    /(درخواست|نیاز|تقاضا|سفارش|کمبود|موجود نیست|نداریم|در انتظار|باید تهیه|تأمین|تامین)/],
  SUPPLY: [/\b(sent to site|supplied|dispatched|installed on|delivered)\b/,
    /(ارسال شد|ارسالی|فرستاد|فرستاده شد|تحویل سایت|رفت سایت|نصب شد|نصب روی سایت|دمیج شده|دمیج شد|تأمین شد|تامین شد)/],
  RETURN: [/\b(return|rma|returned|back to stock)\b/,
    /(برگشت|برگشتی|عودت|مرجوع|مرجوعی|رفت انبار|برگشت به انبار|تحویل انبار شد|به انبار)/],
  SWAP: [/\b(swap|replaced)\b/, /(تعویض|جایگزینی|جایگزین)/],
  RESTORE: [/\b(recovered|restored|cleared|resolved|fixed)\b/, /(رفع شد|راه ?انداز|بالا آمد|سالم|ریکاور|برطرف)/],
};
const detect = (t) => {
  const hits = Object.entries(EV).filter(([, pats]) => pats.some(p => p.test(t))).map(([k]) => k);
  if (hits.includes("SUPPLY") && hits.includes("RETURN") && /(تحویل انبار شد|برگشت|عودت|مرجوع|رفت انبار)/.test(t)) return hits.filter(h => h !== "SUPPLY");
  return hits;
};

// ================= pass 1: events =================
const events = [];  // {unit, family, site, ev, t, chat, text}
const nowMs = Date.now();
for (const f of fs.readdirSync(MERGED).filter(x => x.endsWith(".json"))) {
  const chat = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  for (const m of JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"))) {
    const raw = (m.x || "").replace(/\s+/g, " ").trim();
    if (!raw || raw === "[object Object]" || raw.length < 4) continue;
    const t = PRE(raw);
    const units = [...new Set((t.match(UNIT_TOKENS) || []))];
    const sites = findSites(t);
    if (!units.length && !sites.length) continue;
    const evs = detect(t);
    if (!evs.length) continue;
    if (t.length > 420) continue;  // snapshot/table rows
    for (const ev of evs) {
      if (units.length) {
        for (const u of units) events.push({ unit: u.toUpperCase(), family: fam(u), site: sites[0] || "", sites: sites.join("|"), ev, t: m.d, chat, text: raw.slice(0, 140) });
      } else if (sites.length) {
        for (const s of sites) events.push({ unit: "", family: "", site: s, sites: s, ev, t: m.d, chat, text: raw.slice(0, 140) });
      }
    }
  }
}
events.sort((a, b) => a.t - b.t);
console.log("events:", events.length);

// ================= pass 2: FIFO demand->supply per unit =================
const open = new Map();   // unit -> [demand]
const units = new Map();  // unit -> stats
function U(u, family) {
  if (!units.has(u)) units.set(u, { unit: u, family, faults: 0, requests: 0, dispatches: 0, swaps: 0, restores: 0, returns: 0, supplied: 0, restored: 0, unmet: 0, open30: 0, leadSum: 0, leadN: 0, leadMax: 0, first: Infinity, last: 0, sites: new Set(), consumable: CONSUMABLE.test(u.toLowerCase()), samples: [] });
  return units.get(u);
}
for (const e of events) {
  if (!e.unit) continue;
  const a = U(e.unit, e.family);
  a.first = Math.min(a.first, e.t); a.last = Math.max(a.last, e.t);
  if (e.site) a.sites.add(e.site);
  if (e.ev === "FAULT" || e.ev === "REQUEST") {
    if (e.ev === "FAULT") a.faults++; else a.requests++;
    if (!open.has(e.unit)) open.set(e.unit, []);
    open.get(e.unit).push({ unit: e.unit, family: e.family, site: e.site, ev: e.ev, t: e.t, text: e.text });
    if (a.samples.length < 2) a.samples.push(e.text);
  } else if (e.ev === "SUPPLY" || e.ev === "SWAP") {
    if (e.ev === "SUPPLY") a.dispatches++; else a.swaps++;
    const arr = open.get(e.unit);
    if (arr && arr.length) {
      let idx = arr.findIndex(d => d.site && d.site === e.site);
      if (idx < 0) idx = 0;
      const d = arr.splice(idx, 1)[0];
      a.supplied++;
      const lead = (e.t - d.t) / 86400000;
      if (lead >= 0) { a.leadSum += lead; a.leadN++; a.leadMax = Math.max(a.leadMax, lead); }
    }
  } else if (e.ev === "RESTORE") {
    a.restores++;
    const arr = open.get(e.unit);
    if (arr && arr.length && e.site) {
      const idx = arr.findIndex(d => d.site === e.site);
      if (idx >= 0) { arr.splice(idx, 1); a.restored++; }
    }
  } else if (e.ev === "RETURN") {
    a.returns++;
  }
}
// unmet = demands never supplied nor restored
for (const [unit, arr] of open) {
  const a = units.get(unit);
  for (const d of arr) {
    a.unmet++;
    if (d.ev === "FAULT" && (nowMs - d.t) < 30 * 86400000) a.open30++;
  }
}

const d2 = (ms) => new Date(ms + 3.5 * 3600000).toISOString().slice(0, 10);
const q = (v) => `"${String(v ?? "").replace(/"/g, "'").replace(/[\r\n]+/g, " ")}"`;
const B = "\uFEFF";
const writeCsv = (file, head, rows) => {
  fs.writeFileSync(path.join(OUT, file), B + head.map(q).join(",") + "\n" + rows.map(r => head.map(h => q(r[h])).join(",")).join("\n") + "\n", "utf8");
  console.log("wrote", file, rows.length);
};

// ================= output 10: all unit models =================
const allUnits = [...units.values()].sort((a, b) => b.faults - a.faults || b.dispatches - a.dispatches);
writeCsv("10_unit_model_stats.csv",
  ["unit","family","category","faults","requests","dispatches","swaps","restores","returns","supplied","restored","unmet","open_needs_30d","avg_lead_days","max_lead_days","sites_count","first_seen","last_seen","sample"],
  allUnits.map(a => ({
    unit: a.unit, family: a.family,
    category: a.consumable ? "مصرفی" : "تجهیز",
    faults: a.faults, requests: a.requests, dispatches: a.dispatches, swaps: a.swaps, restores: a.restores, returns: a.returns,
    supplied: a.supplied, restored: a.restored, unmet: a.unmet, open_needs_30d: a.open30,
    avg_lead_days: a.leadN ? (a.leadSum / a.leadN).toFixed(1) : "",
    max_lead_days: a.leadN ? a.leadMax.toFixed(0) : "",
    sites_count: a.sites.size, first_seen: isFinite(a.first) ? d2(a.first) : "", last_seen: a.last ? d2(a.last) : "",
    sample: a.samples.join(" || "),
  })));

// ================= output 11: consumables =================
const cons = allUnits.filter(a => a.consumable);
writeCsv("11_consumables_stats.csv",
  ["part","faults","requests","dispatches","swaps","returns","supplied","restored","unmet","open_needs_30d","avg_lead_days","max_lead_days","sites_count","first_seen","last_seen","sample"],
  cons.map(a => ({
    part: a.unit, faults: a.faults, requests: a.requests, dispatches: a.dispatches, swaps: a.swaps, returns: a.returns,
    supplied: a.supplied, restored: a.restored, unmet: a.unmet, open_needs_30d: a.open30,
    avg_lead_days: a.leadN ? (a.leadSum / a.leadN).toFixed(1) : "", max_lead_days: a.leadN ? a.leadMax.toFixed(0) : "",
    sites_count: a.sites.size, first_seen: isFinite(a.first) ? d2(a.first) : "", last_seen: a.last ? d2(a.last) : "",
    sample: a.samples.join(" || "),
  })));

// ================= output 12: battery =================
const BAT_KW = /(باطری|باتری|باتري|battery|batt\b|esm\b|سلول)/;
const BAT_MODEL = [
  ["ESM", /\besm\b/], ["48V", /48\s?v/], ["24V", /24\s?v/], ["12V", /12\s?v/], ["2V سلول", /2\s?v\s?(cell|سلول)/],
  ["100Ah", /100\s?ah/], ["150Ah", /150\s?ah/], ["200Ah", /200\s?ah/],
  ["صبا باتری", /صبا\s?باتری|saba/], ["FIAMM", /fiamm/], ["C&D", /c\s?&\s?d/], ["Sonnenschein", /sonnen/],
  ["Eltek", /eltek/], ["Huawei", /huawei|هوآوی/],
];
const batState = {
  "خراب": /(باطری|باتری|battery|batt|سلول|esm)[^.]{0,30}(خراب|فالت|معیوب|سوخته|failed|fault|dead)|(خراب|فالت|معیوب|سوخته)[^.]{0,20}(باطری|باتری|battery|batt|esm)/,
  "فاقد باطری": /(فاقد\s?ب?اطری|بدون\s?ب?اطری|باطری\s?ندار|باتری\s?ندار|no\s?battery|battery\s?missing|missing\s?battery)/,
  "تست": /(تست\s?ب?اطری|تست\s?باتری|battery\s?test|تست\s?شارژ)/,
  "تعویض": /(تعویض\s?ب?اطری|تعویض\s?باتری|swap\s?battery|add\s?battery)/,
  "سالم": /(باطری\s?سالم|باتری\s?سالم|healthy|در\s?مدار|ok\s?bood)/,
  "نیاز به باطری": /(نیاز\s?به\s?ب?اطری|باطری\s?نیاز|باتری\s?نیاز|باطری\s?بخوایم|نیاز\s?باطری)/,
  "قطع برق": /(قطع\s?ب?رق|برق\s?رفت|برق\s?قطع|power\s?cut|no\s?power)/,
  "روی باتری نرفت": /(روی\s?ب?اطری\s?نمی?ر|روی\s?باتری\s?نرفت|باتری\s?نمی?گیرد|خاموش\s?شد)/,
};
const batSites = new Map();
const batModels = new Map();
let batMsgCount = 0;
const seenKey = new Set();   // dedupe repeated alarm tickets: site|state|date|msg-head
for (const f of fs.readdirSync(MERGED).filter(x => x.endsWith(".json"))) {
  const chat = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  for (const m of JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"))) {
    const raw = (m.x || "").replace(/\s+/g, " ").trim();
    if (!raw || raw === "[object Object]") continue;
    const t = PRE(raw);
    if (!BAT_KW.test(t)) continue;
    batMsgCount++;
    const sites = findSites(t);
    const states = Object.entries(batState).filter(([, re]) => re.test(t)).map(([k]) => k);
    const models = BAT_MODEL.filter(([, re]) => re.test(t)).map(([k]) => k);
    const date = d2(m.d);
    for (const s of (sites.length ? sites : [""])) {
      if (!s) continue;
      // dedupe: same site+state+date+head => count once (alarm repeats)
      const dk = s + "|" + states.join(",") + "|" + date + "|" + t.slice(0, 60);
      if (states.length && seenKey.has(dk)) continue;
      if (states.length) seenKey.add(dk);
      if (!batSites.has(s)) batSites.set(s, { site: s, states: new Map(), models: new Set(), first: date, last: date, samples: [] });
      const a = batSites.get(s);
      for (const st of states) a.states.set(st, (a.states.get(st) || 0) + 1);
      for (const mo of models) a.models.add(mo);
      if (date < a.first) a.first = date;
      if (date > a.last) a.last = date;
      if (a.samples.length < 2) a.samples.push(raw.slice(0, 120));
    }
    for (const mo of models) {
      if (!batModels.has(mo)) batModels.set(mo, { model: mo, mentions: 0, sites: new Set() });
      const b = batModels.get(mo); b.mentions++; for (const s of sites) b.sites.add(s);
    }
  }
}
console.log("battery messages:", batMsgCount, "| sites:", batSites.size, "| models:", batModels.size);

writeCsv("12_battery_sites_stats.csv",
  ["site","status","faulty","missing","needs","test","swap","healthy","power_cut","not_on_bat","models","first","last","sample"],
  [...batSites.values()].map(a => ({
    site: a.site,
    status: a.states.get("خراب") ? "خراب" : a.states.get("فاقد باطری") ? "فاقد باطری" : a.states.get("نیاز به باطری") ? "نیاز به باطری" : a.states.get("قطع برق") ? "مشکل برق" : a.states.get("سالم") ? "سالم" : "سایر",
    faulty: a.states.get("خراب") || 0, missing: a.states.get("فاقد باطری") || 0, needs: a.states.get("نیاز به باطری") || 0,
    test: a.states.get("تست") || 0, swap: a.states.get("تعویض") || 0, healthy: a.states.get("سالم") || 0,
    power_cut: a.states.get("قطع برق") || 0, not_on_bat: a.states.get("روی باتری نرفت") || 0,
    models: [...a.models].join("|"), first: a.first, last: a.last, sample: a.samples.join(" || "),
  })).sort((x, y) => (y.faulty + y.missing + y.needs) - (x.faulty + x.missing + x.needs)));

writeCsv("13_battery_models_stats.csv",
  ["battery_model","mentions","sites_count","note"],
  [...batModels.values()].sort((a, b) => b.mentions - a.mentions).map(b => ({
    battery_model: b.model, mentions: b.mentions, sites_count: b.sites.size,
    note: b.model === "ESM" ? "سیستم مدیریت باتری (Eltek)" : b.model.includes("V") ? "ولتاژ سیستم" : b.model.includes("Ah") ? "ظرفیت" : "برند/مدل",
  })));

// ================= output 14: planning report (markdown) =================
const top = (arr, n, f) => arr.slice(0, n);
const rows10 = allUnits.filter(a => !a.consumable);
const md = [];
md.push(`# گزارش آماری و برنامه‌ریزی — یونیت‌های سایت‌های مخابراتی (منطقه R7)`);
md.push(`تاریخ تهیه: ${new Date(nowMs + 3.5 * 3600000).toISOString().slice(0, 10)} | منبع: ${batMsgCount ? "" : ""}چت‌های عملیاتی بله`);
md.push(`\n## خلاصه کلی`);
md.push(`- مجموع رویدادهای یونیت/انبار: **${events.length.toLocaleString("fa")}**`);
md.push(`- مدل‌های یونیت شناسایی‌شده: **${allUnits.length}** (شامل ${cons.length} قطعه مصرفی)`);
md.push(`- خرابی کل: **${allUnits.reduce((s, a) => s + a.faults, 0).toLocaleString("fa")}** | ارسال به سایت: **${allUnits.reduce((s, a) => s + a.dispatches, 0).toLocaleString("fa")}** | بازگشت به انبار: **${allUnits.reduce((s, a) => s + a.returns, 0).toLocaleString("fa")}**`);
md.push(`- خرابی تأمین‌نشده: **${allUnits.reduce((s, a) => s + a.unmet, 0).toLocaleString("fa")}** | نیاز فعال ۳۰ روز اخیر: **${allUnits.reduce((s, a) => s + a.open30, 0).toLocaleString("fa")}**`);
md.push(`\n## ۱) جدول یونیت‌های تجهیزاتی — برنامه‌ریزی تأمین`);
md.push(`ستون‌ها: خرابی | تامین‌شده | تامین‌نشده | نیاز فعال (۳۰ روز) | برگشت انبار | میانگین زمان تأمین (روز)`);
md.push(`\n| مدل | خانواده | خرابی | تامین‌شده | تامین‌نشده | نیاز فعال | برگشت انبار | میانگین تأمین | بیشترین |`);
md.push(`|---|---|---|---|---|---|---|---|---|`);
for (const a of top(rows10, 25)) {
  md.push(`| **${a.unit}** | ${a.family} | ${a.faults} | ${a.supplied} | ${a.unmet} | ${a.open30} | ${a.returns} | ${a.leadN ? (a.leadSum / a.leadN).toFixed(1) : "-"} | ${a.leadN ? a.leadMax.toFixed(0) : "-"} |`);
}

md.push(`\n## ۲) قطعات مصرفی پرنیاز`);
md.push(`\n| قطعه | خرابی | تامین‌شده | تامین‌نشده | نیاز فعال | میانگین تأمین | سایت‌های درگیر |`);
md.push(`|---|---|---|---|---|---|---|`);
for (const a of top(cons, 15)) {
  md.push(`| **${a.unit}** | ${a.faults} | ${a.supplied} | ${a.unmet} | ${a.open30} | ${a.leadN ? (a.leadSum / a.leadN).toFixed(1) : "-"} | ${a.sites.size} |`);
}

md.push(`\n## ۳) باتری سایت‌ها`);
const batSitesArr = [...batSites.values()];
const batFaulty = batSitesArr.filter(a => a.states.get("خراب"));
const batMissing = batSitesArr.filter(a => a.states.get("فاقد باطری"));
const batNeeds = batSitesArr.filter(a => a.states.get("نیاز به باطری"));
const batHealthy = batSitesArr.filter(a => a.states.get("سالم"));
md.push(`- سایت‌های دارای باطری خراب: **${batFaulty.length}**`);
md.push(`- سایت‌های فاقد باطری: **${batMissing.length}**`);
md.push(`- سایت‌های نیازمند باطری: **${batNeeds.length}**`);
md.push(`- سایت‌های با باطری سالم: **${batHealthy.length}**`);
md.push(`- پیام‌های باتری‌محور بررسی‌شده: **${batMsgCount.toLocaleString("fa")}**`);
md.push(`\n### بدترین سایت‌های باتری`);
md.push(`| سایت | خراب | فاقد | نیاز | قطع برق | آخرین رویداد |`);
md.push(`|---|---|---|---|---|---|`);
for (const a of batSitesArr.sort((x, y) => (y.states.get("خراب") || 0) + (y.states.get("فاقد باطری") || 0) - (x.states.get("خراب") || 0) - (x.states.get("فاقد باطری") || 0)).slice(0, 20)) {
  md.push(`| **${a.site}** | ${a.states.get("خراب") || 0} | ${a.states.get("فاقد باطری") || 0} | ${a.states.get("نیاز به باطری") || 0} | ${a.states.get("قطع برق") || 0} | ${a.last} |`);
}
md.push(`\n### مدل‌های باطری اشاره‌شده`);
md.push(`| مدل | تعداد اشاره | سایت‌ها |`);
md.push(`|---|---|---|`);
for (const b of [...batModels.values()].sort((a, b) => b.mentions - a.mentions).slice(0, 12)) {
  md.push(`| ${b.model} | ${b.mentions} | ${b.sites.size} |`);
}

md.push(`\n## ۴) راهنمای استفاده برای برنامه‌ریزی`);
md.push(`1. **فایل 10_unit_model_stats.csv**: برای هر مدل یونیت — تعداد خرابی، تامین‌شده/نشده و نیاز فعال. برای تخصیص موجودی انبار، مدل‌های با «تامین‌نشده» بالا و «نیاز فعال» بالا را در اولویت بگذارید.`);
md.push(`2. **فایل 11_consumables_stats.csv**: قطعات مصرفی (فیوز، باطری، کابل، فیبر) — برای سفارش دوره‌ای انبار.`);
md.push(`3. **فایل 12_battery_sites_stats.csv**: هر سایت با وضعیت باطری (خراب/فاقد/نیاز) — برای برنامه تیم باطری.`);
md.push(`4. **فایل 13_battery_models_stats.csv**: مدل‌های باطری در گردش — برای برنامه خرید/تست.`);
md.push(`5. «تامین‌نشده» = خرابی‌ای که هیچ ارسال/تعویضی بعدش ثبت نشده؛ «نیاز فعال» = خرابی ۳۰ روز اخیر بدون تأمین — این دو ستون اولویت عملیاتی هستند.`);

fs.writeFileSync(path.join(OUT, "14_planning_report.md"), md.join("\n"), "utf8");
console.log("wrote 14_planning_report.md");
console.log("\nDONE.");