import fs from "node:fs";
import path from "node:path";
const MERGED = "C:\\Users\\someBody\\.zcode\\workspace\\default\\bale_report\\merged";
const files = fs.readdirSync(MERGED).filter(f => f.endsWith(".json"));

const FA = 0x06F0;
const norm = s => (s || "")
  .replace(/[۰-۹]/g, d => String(d.charCodeAt(0) - FA))
  .replace(/[٠-٩]/g, d => String(d.charCodeAt(0) - 0x0660))
  .replace(/[يى]/g, 'ی').replace(/ك/g, 'ک')
  .replace(/\u200c|\u200f|\u200e/g, '')
  .replace(/\s+/g, ' ').trim();

// ---- دسته‌ها ----
const CATS = {
  "کولر (هر شکلی)": /کولر|cooler|coler|kooler|coolr/i,
  "کولر نیان": /کولر\s*نیان|cooler\s*nian|nian\s*cooler|کولر\s*نیان۹۰|cooler\s*nian\s*90|nian\s*90/i,
  "کولر فالت/خراب": /(?:کولر|cooler|coler|کوالر)\s*(?:فالت|فالتی|فولت|fa?u?lt|fualt|خراب|سوخته|خوابیده|گیر\s*می)|(?:cooler|coler)\s*(?:fa?u?lt|faulty)|فالت\s*(?:کولر|cooler)|cooler\s*fualt|کولر\s*خرابه/i,
  "تمپ بالا": /تمپ\s*(?:شدید|دان|اور|بالا|میاره|داره)|high\s*temp|temp\s*(?:on|over|high)|hightemp|high\s*temp|دمای\s*(?:رک|بالا)|temp\s*miyare|با\s*تمپ/i,
  "نصب کولر": /(?:کولر|cooler|coler|کوالر)\s*(?:جدید\s*)?(?:نصب|nasb)|(?:نصب|nasb)\s*(?:کولر|cooler|coler)|cooler\s*nasb|coler\s*nasb|nasb\s*she.*cool|ACU\s*nasb|acu\s*nasb/i,
  "تعویض کولر": /(?:تعویض|change|chenge|chng|عوض)\s*(?:ی|و)?\s*(?:کولر|cooler|coler|ACU|acu)|(?:کولر|cooler|coler)\s*(?:تعویض|change|chenge|عوض)|cooler\s*(?:change|chenge)|coler\s*chenge|change\s*cooler|کولر\s*جدید\s*نصب/i,
  "فن فالت/نویز": /(?:فن|fan)\s*(?:فالت|فولت|fault|fualt|خراب|نویز|noise|سوخت)|(?:فالت|fualt|fault|خراب|نویز|noise)\s*(?:فن|fan)|fan\s*noise|fan\s*fault|فنش?\s*(?:خراب|فالت)|فن\s*اکسترنال|fan\s*external|fan\s*internal|external\s*fan|فن\s*external|فن\s*internal/i,
  "هیتکس": /هیتکس|هیت\s*اکس|hitex|heat\s*ex|heatex|هتکس|هیتکس/i,
  "کولر کنسل": /کولر\s*کنسل|cooler\s*cansel|cooler\s*cancel|کنسل\s*کولر|کولرها\s*کنسل|cooler\s*cansl/i,
  "ریست/رفع کولر": /(?:کولر|cooler|coler)\s*(?:ریست|reset)|(?:ریست|reset)\s*(?:کولر|cooler)|کولر\s*ریست\s*کردم|ارمش\s*برطرف|الارمش\s*برطرف/i,
  "کولر سالم/اوکی": /(?:کولر|cooler|coler)\s*(?:سالم|اوکی|ok|okay|salem|okeye|جواب\s*می)|cooler\s*salem|coler\s*saleme|کولر\s*خنک/i,
  "کولر نداره/موجود نیست": /(?:کولر|cooler|coler)\s*(?:ندارد|نداره|نبود|نیست|nist|nadare|nadarad)|cooler\s*nist|cooler\s*nadare|cooler\s*nadare|کولر\s*موجود\s*نیست/i,
  "در رک باز (کولر فالت)": /در\s*(?:رک|سایت|باز)|daro?\s*baz|door\s*open|rack\s*baz|در\s*باز|درش\s*باز/i,
  "شستشو کولر/هیتکس": /(?:شسته|شستشو|شستم|شستی|شوردن|beshor|shostam|shoste|clean|clear)\s*(?:شد|شو)?.*(?:کولر|هیتکس|cooler|hitex)|(?:کولر|هیتکس|cooler|hitex|heat\s*ex).*(?:شسته|شستشو|شستم|shoste|shostam|clean)/i,
  "کولر خاموش": /(?:کولر|cooler|coler)\s*(?:خاموش|off|khamosh)|(?:خاموش|off)\s*(?:کولر|cooler)|cooler\s*off|cooler\s*khamosh|کولرو?\s*خاموش/i,
  "NAC (مدل نیان)": /\bNAC\s?\d{3,4}|\bNAC\b/i,
  "NCR48U": /NCR48U|NCR\s*48U/i,
  "Cooling Failure (آلارم نیان)": /Cooling\s*(?:System\s*)?Failure|cooling\s*fault|cooling\s*fa?u?lt|کولینگ/i,
  "AEC (پیمانکار)": /\bAEC\b|نفر\s*aec|aecجهت|aec\s*جهت/i,
  "ACU": /\bACU\b|acu\s*\d{4}|ACU\s*\d{4}/,
  "کمپرسور/گاز": /کمپرسور|compressor|گاز\s*(?:کولر|نداره|تموم|نمیگیره)|گازش/i,
};

const perCat = {}; for (const k of Object.keys(CATS)) perCat[k] = { n: 0, chats: new Set(), samples: [] };
const allCoolerSites = new Map(); // site -> count

// استخراج سایت
const PREFIX = new Set(['t','e','n','b','h','d','dt','th','dl','lu','l','k','m','p','c','s','r','f','g','w','a','j','x','v','y','z','q','i','o','u']);
const SITE_TOK = /\b([A-Za-z]{1,3})-?\s?(\d{3,5})\b/g;
const SITE_MBTS = /MBTS[_-]?([A-Z]{1,3}\d{3,5})X?/i;

for (const f of files) {
  const name = f.replace(/^\d+_/, "").replace(/\.json$/, "");
  const msgs = JSON.parse(fs.readFileSync(path.join(MERGED, f), "utf8"));
  for (const m of msgs) {
    const raw = (m.x || "");
    if (!raw.trim() || raw === "[object Object]") continue;
    const x = norm(raw);
    const isCooler = /کولر|cooler|coler|kooler|coolr|نیان|nian|هیتکس|hitex|heat\s*ex|\bNAC\b|\bACU\b|کولینگ|cooling/i.test(x);
    if (isCooler) {
      // site extraction
      for (const mm of x.matchAll(SITE_TOK)) {
        if (PREFIX.has(mm[1].toLowerCase()) && mm[2] !== '1400' && mm[2].length >= 3)
          allCoolerSites.set(mm[1].toUpperCase() + mm[2], (allCoolerSites.get(mm[1].toUpperCase() + mm[2]) || 0) + 1);
      }
      const mb = x.match(SITE_MBTS);
      if (mb) allCoolerSites.set(mb[1].toUpperCase(), (allCoolerSites.get(mb[1].toUpperCase()) || 0) + 1);
    }
    for (const [k, re] of Object.entries(CATS)) {
      if (re.test(x)) {
        perCat[k].n++; perCat[k].chats.add(name);
        if (perCat[k].samples.length < 3 && isCooler) perCat[k].samples.push(`[${name}] ${x.slice(0, 150)}`);
      }
    }
  }
}

console.log("=== شمارش دسته‌ها (کل corpus) ===");
for (const [k, v] of Object.entries(perCat)) {
  console.log(String(v.n).padStart(5), "|", String(v.chats.size).padStart(2), "چت |", k);
}
console.log("\n=== نمونه‌ها ===");
for (const [k, v] of Object.entries(perCat)) {
  console.log(`\n## ${k}`);
  for (const s of v.samples) console.log("   ", s);
}

console.log("\n=== سایت‌های دارای پیام کولر (top 40) ===");
for (const [s, n] of [...allCoolerSites.entries()].sort((a, b) => b[1] - a[1]).slice(0, 40))
  console.log(String(n).padStart(4), s);
console.log("تعداد کل سایت‌های دارای پیام کولر:", allCoolerSites.size);
